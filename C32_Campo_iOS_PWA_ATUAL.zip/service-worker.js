"use strict";

const CACHE_NAME = "c32-campo-v2.1.2-r1";
const APP_SHELL = [
  "./",
  "./manifest.webmanifest",
  "./css/styles.css",
  "./images/app_icon.png",
  "./images/bode_verde.png",
  "./images/brasao_ssn9.png",
  "./images/marca_mb.png",
  "./js/vendor/jszip.min.js",
  "./js/vendor/tesseract/tesseract.min.js",
  "./js/vendor/tesseract/worker.min.js",
  "./js/vendor/tesseract-core/tesseract-core-lstm.wasm.js",
  "./js/vendor/tesseract-core/tesseract-core-lstm.wasm",
  "./js/vendor/pdfjs/pdf.min.mjs",
  "./js/vendor/pdfjs/pdf.worker.min.mjs",
  "./js/pdf-loader.mjs",
  "./js/template-data.js",
  "./js/polyfills.js",
  "./js/model.js",
  "./js/calc.js",
  "./js/storage.js",
  "./js/native.js",
  "./js/station-db.js",
  "./js/c32base.js",
  "./js/f43-parser.js",
  "./js/f43-pdf.js",
  "./js/ods.js",
  "./js/scheme-image.js",
  "./js/ui.js",
  "./js/v2-ui.js",
  "./js/pwa.js",
  "./tessdata/eng.traineddata",
  "./tessdata/por.traineddata",
  "./licenses/PDFJS_LICENSE.txt",
  "./licenses/TESSERACT_JS_LICENSE.md",
  "./licenses/TESSERACT_CORE_LICENSE.txt",
  "./standard_fonts/FoxitDingbats.pfb",
  "./standard_fonts/FoxitFixed.pfb",
  "./standard_fonts/FoxitFixedBold.pfb",
  "./standard_fonts/FoxitFixedBoldItalic.pfb",
  "./standard_fonts/FoxitFixedItalic.pfb",
  "./standard_fonts/FoxitSerif.pfb",
  "./standard_fonts/FoxitSerifBold.pfb",
  "./standard_fonts/FoxitSerifBoldItalic.pfb",
  "./standard_fonts/FoxitSerifItalic.pfb",
  "./standard_fonts/FoxitSymbol.pfb",
  "./standard_fonts/LICENSE_FOXIT",
  "./standard_fonts/LICENSE_LIBERATION",
  "./standard_fonts/LiberationSans-Bold.ttf",
  "./standard_fonts/LiberationSans-BoldItalic.ttf",
  "./standard_fonts/LiberationSans-Italic.ttf",
  "./standard_fonts/LiberationSans-Regular.ttf",
  "./templates/c32_template.ods"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put("./", copy));
          return response;
        })
        .catch(() => caches.match("./"))
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((cached) => cached || fetch(request).then((response) => {
      if (response.ok) {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
      }
      return response;
    }))
  );
});
