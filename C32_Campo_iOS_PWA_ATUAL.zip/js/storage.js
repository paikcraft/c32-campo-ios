(function (root) {
  "use strict";

  const DRAFT_KEY = "c32.campo.draft.v1";
  const SETTINGS_KEY = "c32.campo.settings.v1";

  function storageAvailable() {
    try {
      const key = "__c32_test__";
      localStorage.setItem(key, "1");
      localStorage.removeItem(key);
      return true;
    } catch (_) {
      return false;
    }
  }

  function saveDraft(project) {
    if (!storageAvailable() || !project) return false;
    const snapshot = JSON.parse(JSON.stringify(project));
    snapshot.updatedAt = new Date().toISOString();
    localStorage.setItem(DRAFT_KEY, JSON.stringify(snapshot));
    return true;
  }

  function loadDraft() {
    if (!storageAvailable()) return null;
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    try {
      return root.C32Model.migrateProject(JSON.parse(raw));
    } catch (_) {
      return null;
    }
  }

  function hasDraft() {
    return Boolean(loadDraft());
  }

  function discardDraft() {
    if (storageAvailable()) localStorage.removeItem(DRAFT_KEY);
  }

  function exportProject(project) {
    const snapshot = JSON.parse(JSON.stringify(project));
    snapshot.updatedAt = new Date().toISOString();
    snapshot.appVersion = root.C32Model.APP_VERSION;
    snapshot.formatVersion = root.C32Model.FORMAT_VERSION;
    return JSON.stringify(snapshot, null, 2);
  }

  function firstJsonObject(text) {
    const source = String(text == null ? "" : text);
    let start = -1;
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let index = 0; index < source.length; index += 1) {
      const char = source[index];
      if (start < 0) {
        if (/\s/.test(char)) continue;
        if (char !== "{") return null;
        start = index;
        depth = 1;
        continue;
      }
      if (inString) {
        if (escaped) escaped = false;
        else if (char === "\\") escaped = true;
        else if (char === '"') inString = false;
        continue;
      }
      if (char === '"') { inString = true; continue; }
      if (char === "{") depth += 1;
      else if (char === "}") {
        depth -= 1;
        if (depth === 0) return source.slice(start, index + 1);
      }
    }
    return null;
  }

  function importProject(text) {
    let raw;
    try {
      raw = JSON.parse(text);
    } catch (_) {
      // Recuperação defensiva para arquivos antigos salvos sobre um destino maior,
      // nos quais alguns provedores Android deixaram bytes residuais após o JSON.
      const recovered = firstJsonObject(text);
      if (!recovered) throw new Error("O arquivo .project não contém JSON válido.");
      try { raw = JSON.parse(recovered); }
      catch (_) { throw new Error("O arquivo .project não contém JSON válido."); }
    }
    return root.C32Model.migrateProject(raw);
  }

  function saveSettings(settings) {
    if (!storageAvailable()) return;
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings || {}));
  }

  function loadSettings() {
    if (!storageAvailable()) return {};
    try {
      return JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
    } catch (_) {
      return {};
    }
  }

  const api = {
    DRAFT_KEY,
    SETTINGS_KEY,
    storageAvailable,
    saveDraft,
    loadDraft,
    hasDraft,
    discardDraft,
    exportProject,
    importProject,
    saveSettings,
    loadSettings
  };

  root.C32Storage = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
