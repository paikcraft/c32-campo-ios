(function (root) {
  "use strict";

  function clean(value) {
    return String(value == null ? "" : value).replace(/\u00a0/g, " ").replace(/[ \t]+/g, " ").trim();
  }

  function normalize(value) {
    return clean(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase();
  }

  function decimal(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    const text = clean(value).replace(/\s/g, "");
    if (!text) return null;
    const normalized = text.includes(",") && text.includes(".")
      ? (text.lastIndexOf(",") > text.lastIndexOf(".") ? text.replace(/\./g, "").replace(",", ".") : text.replace(/,/g, ""))
      : text.replace(",", ".");
    const number = Number(normalized);
    return Number.isFinite(number) ? number : null;
  }

  function valueField(value, essential, confidence, source) {
    const present = value !== null && value !== undefined && clean(value) !== "";
    return {
      value: present ? value : "",
      essential: Boolean(essential),
      confidence: confidence || (present ? "green" : (essential ? "red" : "yellow")),
      source: source || "document"
    };
  }

  function normalizeLine(line, index, fallbackPage) {
    const source = line && typeof line === "object" ? line : { text: line };
    return {
      text: clean(source.text || line),
      page: source.page || fallbackPage || 1,
      y: source.y == null ? index : Number(source.y),
      x: Number(source.x) || 0,
      width: Math.abs(Number(source.width) || 0),
      height: Math.abs(Number(source.height) || 0),
      mode: source.mode || "text",
      parts: Array.isArray(source.parts) ? source.parts.map((part) => ({
        text: clean(part.text || ""), x: Number(part.x) || 0, y: part.y == null ? (source.y == null ? index : Number(source.y)) : Number(part.y),
        width: Math.abs(Number(part.width) || 0), height: Math.abs(Number(part.height) || 0)
      })).filter((part) => part.text) : []
    };
  }

  function linesFrom(input) {
    if (Array.isArray(input && input.lines)) return input.lines.map((line, index) => normalizeLine(line, index, 1));
    if (Array.isArray(input && input.pages)) {
      return input.pages.flatMap((page, pageIndex) => (page.lines || []).map((line, index) => normalizeLine(line, index, page.page || pageIndex + 1)));
    }
    let page = 1;
    return String(input && input.text || input || "").split(/\r?\n/).map((text, index) => {
      if (String(text).includes("\f")) page += 1;
      return normalizeLine({ text: String(text).replace(/\f/g, ""), page, y: index, x: 0, mode: "text" }, index, page);
    });
  }

  function combinedText(lines) {
    return lines.map((line) => line.text).filter(Boolean).join("\n");
  }

  function labelValue(text, label, nextLabels) {
    const normalizedNext = (nextLabels || []).join("|");
    const expression = new RegExp(`${label}\\s*:?\\s*(.+?)${normalizedNext ? `(?=\\s+(?:${normalizedNext})\\s*:?)` : "$"}`, "i");
    const match = String(text).match(expression);
    return match ? clean(match[1]) : "";
  }

  function firstMatch(text, expressions, group) {
    for (const expression of expressions) {
      const match = String(text).match(expression);
      if (match) return clean(match[group == null ? 1 : group]);
    }
    return "";
  }

  function nameToken(value) {
    return clean(value)
      .replace(/[.,;:]$/, "")
      .replace(/\s*-\s*/g, "-")
      .replace(/-C\s*P\s*R\s*M$/i, "-CPRM")
      .replace(/-D\s*H\s*N$/i, "-DHN")
      .replace(/^RN0+(\d)/i, "RN$1");
  }

  const RN_PATTERN = /\b(?:RN[ \t]*(?:DHN(?:-[A-Z0-9]+)+|\d+[A-Z0-9]*(?:-[A-Z0-9]+)*(?:[ \t]*\([A-Z0-9-]+\))?)|RN(?:-[A-ZÀ-Ü0-9]+)+(?:[ \t]*\([^)]+\))?(?:[ \t]+\d+)?|MT(?:-[A-Z0-9]+)+(?:[ \t]+[A-Z0-9]+(?:-[A-Z0-9]+)+)*)\b/gi;

  function namesIn(text) {
    const found = [];
    const reconstructed = String(text)
      .replace(/\bRN\s*((?:\d\s*)+)\s*-\s*(D\s*H\s*N|C\s*P\s*R\s*M)\b/gi, (_match, digits, suffix) => `RN${digits.replace(/\s/g, "")}-${suffix.replace(/\s/g, "")}`)
      .replace(/\bRN\s*((?:\d\s*)+)\b/gi, (_match, digits) => `RN${digits.replace(/\s/g, "")}`);
    reconstructed.replace(RN_PATTERN, (match) => {
      const name = nameToken(match);
      if (name && !found.some((item) => normalize(item) === normalize(name))) found.push(name);
      return match;
    });
    return found;
  }

  function isDiagramTitle(value) {
    return /\b(?:DIA\s*GRAMA|ESQUEMA[_ ]DE[_ ]COTAS)\b/i.test(clean(value));
  }

  function findDiagramStart(lines) {
    const diagramPage = lines.find((line) => isDiagramTitle(line.text));
    if (diagramPage) {
      const layoutPage = lines.findIndex((line) => line.mode === "layout" && Number(line.page) === Number(diagramPage.page));
      if (layoutPage >= 0) return layoutPage;
    }
    const index = lines.findIndex((line) => isDiagramTitle(line.text));
    if (index >= 0) return index;
    const pageTwo = lines.findIndex((line) => Number(line.page) > 1);
    return pageTwo >= 0 ? pageTwo : Math.floor(lines.length / 2);
  }

  function rnDescriptions(lines, diagramStart) {
    const descriptions = new Map();
    let current = null;
    for (let index = 0; index < diagramStart; index += 1) {
      const line = lines[index].text;
      if (!line) continue;
      const tokens = namesIn(line);
      const dash = line.search(/[–—-]\s*/);
      if (tokens.length && dash >= 0) {
        current = tokens[0];
        const after = clean(line.slice(dash + 1));
        descriptions.set(current, after);
      } else if (current && !/^(ARQUIVO|PESSOAL|EQUIPE|CHEFE|DHN-6069)/i.test(line) && namesIn(line).length === 0) {
        const previous = descriptions.get(current) || "";
        if (previous.length < 1200) descriptions.set(current, clean(`${previous} ${line}`));
      }
    }
    return descriptions;
  }

  function cmValuesInText(text) {
    return [...String(text || "").matchAll(/(-?\d{1,5}\s*(?:[.,]\s*\d(?:\s*\d){0,3})?)\s*cm\b/gi)]
      .map((match) => decimal(match[1])).filter((value) => value !== null);
  }

  function spatialTokens(line) {
    const parts = Array.isArray(line && line.parts) && line.parts.length ? line.parts : [{
      text: line && line.text, x: line && line.x, y: line && line.y, width: line && line.width, height: line && line.height
    }];
    const tokens = [];
    for (let index = 0; index < parts.length; index += 1) {
      const part = parts[index];
      const names = namesIn(part.text);
      names.forEach((name) => tokens.push({ type: "rn", name, page: line.page, x: Number(part.x) || 0, y: Number(part.y == null ? line.y : part.y) || 0, width: Number(part.width) || 0, height: Number(part.height) || 0 }));
      const direct = cmValuesInText(part.text);
      direct.forEach((value) => tokens.push({ type: "cm", value, page: line.page, x: Number(part.x) || 0, y: Number(part.y == null ? line.y : part.y) || 0, width: Number(part.width) || 0, height: Number(part.height) || 0 }));
      if (!direct.length && /^[-+]?\d{1,5}\s*(?:[.,]\s*\d(?:\s*\d){0,3})?$/.test(clean(part.text))) {
        const next = parts[index + 1];
        if (next && /^cm\b/i.test(clean(next.text))) {
          const value = decimal(part.text);
          if (value !== null) tokens.push({ type: "cm", value, page: line.page, x: Number(part.x) || 0, y: Number(part.y == null ? line.y : part.y) || 0, width: Math.max(0, (Number(next.x) || 0) + (Number(next.width) || 0) - (Number(part.x) || 0)), height: Math.max(Number(part.height) || 0, Number(next.height) || 0) });
        }
      }
    }
    if (!tokens.some((item) => item.type === "cm")) {
      const values = cmValuesInText(line && line.text);
      values.forEach((value) => tokens.push({ type: "cm", value, page: line.page, x: Number(line.x) || 0, y: Number(line.y) || 0, width: Number(line.width) || 0, height: Number(line.height) || 0 }));
    }
    return tokens;
  }

  function spatialRelationshipData(lines, start) {
    const startLine = lines[start] || {};
    const page = Number(startLine.page) || 1;
    const candidates = lines.slice(start).filter((line) => Number(line.page) === page && /layout/i.test(String(line.mode || "")));
    if (!candidates.length) return { relationships: [], suggestions: [], anchors: [] };
    const tokens = candidates.flatMap(spatialTokens);
    const rnTokens = [];
    for (const token of tokens.filter((item) => item.type === "rn")) {
      const key = normalize(token.name);
      if (!key || rnTokens.some((item) => normalize(item.name) === key)) continue;
      rnTokens.push(token);
    }
    const cmTokens = tokens.filter((item) => item.type === "cm" && item.value > 0 && item.value < 500);
    if (rnTokens.length < 2 || !cmTokens.length) return { relationships: [], suggestions: [], anchors: rnTokens };
    rnTokens.sort((a, b) => Number(b.y) - Number(a.y) || Number(a.x) - Number(b.x));
    const relationships = [];
    const suggestions = [];
    const used = new Set();
    for (let index = 0; index < rnTokens.length - 1; index += 1) {
      const high = rnTokens[index];
      const low = rnTokens[index + 1];
      const maxY = Math.max(high.y, low.y); const minY = Math.min(high.y, low.y);
      const ySpan = Math.max(8, maxY - minY);
      const midY = (high.y + low.y) / 2;
      const midX = ((high.x + high.width / 2) + (low.x + low.width / 2)) / 2;
      const ranked = cmTokens.map((valueToken, tokenIndex) => {
        const vy = Number(valueToken.y) || 0;
        const vx = (Number(valueToken.x) || 0) + (Number(valueToken.width) || 0) / 2;
        const between = vy <= maxY + ySpan * 0.18 && vy >= minY - ySpan * 0.18;
        if (!between) return null;
        const vertical = Math.abs(vy - midY) / ySpan;
        const horizontal = Math.abs(vx - midX) / 600;
        const reused = used.has(tokenIndex) ? 3 : 0;
        return { tokenIndex, token: valueToken, score: vertical + horizontal + reused };
      }).filter(Boolean).sort((a, b) => a.score - b.score);
      if (!ranked.length) continue;
      const first = ranked[0]; const second = ranked[1];
      const confidence = first.score <= 0.82 && (!second || second.score - first.score >= 0.16) ? "high" : "review";
      const item = { high: high.name, low: low.name, differenceCm: first.token.value, source: "spatial-layout", confidence };
      if (confidence === "high") { relationships.push(item); used.add(first.tokenIndex); }
      else suggestions.push(item);
    }
    return { relationships, suggestions, anchors: rnTokens };
  }

  function diagramData(lines, start) {
    const diagramLines = lines.slice(start);
    const vertical = [];
    const relationCandidates = [];
    let pending = null;
    for (let index = 0; index < diagramLines.length; index += 1) {
      const lineData = diagramLines[index];
      const line = lineData.text;
      const tokens = namesIn(line);
      const compactRnLine = tokens.length > 0 && (
        clean(line).length <= Math.max(70, tokens.reduce((sum, item) => sum + item.length, 0) + tokens.length * 5)
        || (lineData.mode === "layout" && tokens.length > 1)
      );
      if (compactRnLine) {
        for (const rn of tokens) {
          if (!vertical.some((item) => normalize(item.name) === normalize(rn))) {
            if (pending) pending.nextName = rn;
            pending = { name: rn, lineIndex: index, differenceToNextCm: null, nextName: "" };
            vertical.push(pending);
          }
        }
      }
      const cmMatches = [...line.matchAll(/(-?\d{1,5}\s*(?:[.,]\s*\d(?:\s*\d){0,3})?)\s*cm\b/gi)];
      for (const match of cmMatches) {
        const value = decimal(match[1]);
        if (value === null) continue;
        relationCandidates.push({ value, lineIndex: index, text: line });
        if (pending && pending.differenceToNextCm === null && value > 0 && value < 500) pending.differenceToNextCm = value;
      }
    }
    const relationships = [];
    vertical.forEach((item, index) => {
      const next = vertical[index + 1];
      if (next && item.differenceToNextCm !== null) {
        relationships.push({ high: item.name, low: next.name, differenceCm: item.differenceToNextCm, source: "vertical-order" });
      }
    });

    const values = relationCandidates.map((item) => item.value).filter((value) => value > 0);
    let triple = null;
    for (const principalToNr of values) {
      if (principalToNr < 100) continue;
      for (const nrToZero of values) {
        if (nrToZero < 5 || nrToZero === principalToNr) continue;
        for (const principalToZero of values) {
          if (principalToZero <= principalToNr || principalToZero === nrToZero) continue;
          const error = Math.abs(principalToNr + nrToZero - principalToZero);
          if (error <= 0.35) {
            const score = error + (principalToZero < 500 ? 10 : 0);
            if (!triple || score < triple.score) triple = { principalToNr, nrToZero, principalToZero, error, score };
          }
        }
      }
    }
    return { vertical, relationships, numericCandidates: relationCandidates, triple };
  }

  function rulerTopFromText(text) {
    const source = clean(String(text).replace(/\r?\n/g, " "));
    const mark = source.match(/mira\s+foi\s+colocada[\s\S]{0,80}?marca\s+de\s+(\d{1,2}\s*(?:[.,]\s*\d{1,3})?)\s*metros?\s+da\s+r[eé]gua/i);
    if (mark) return decimal(mark[1]);
    const top = source.match(/topo\s+da\s+r[eé]gua[^\d]{0,50}(\d{1,2}\s*(?:[.,]\s*\d{1,3})?)\s*m(?:etros?)?\b/i);
    return top ? decimal(top[1]) : null;
  }

  function stationSchemeData(lines, start, text) {
    const startLine = lines[start] || {};
    const page = Number(startLine.page) || 1;
    const allOnPage = lines.slice(start).filter((line) => Number(line.page) === page);
    const layout = allOnPage.filter((line) => line.mode === "layout");
    const candidates = layout.length ? layout : allOnPage;
    const events = [];
    const seenNames = new Set();
    scanLines: for (const lineData of candidates) {
      const line = clean(lineData.text);
      if (/O\s*BSERVA(?:Ç|C)[OÕ]ES/i.test(line)) break;
      const names = Number(lineData.x || 0) < 360 ? namesIn(line) : [];
      if (names.length && line.length <= Math.max(80, names.reduce((sum, name) => sum + name.length, 0) + 18)) {
        for (const name of names) {
          const key = normalize(name);
          if (seenNames.has(key)) break scanLines;
          seenNames.add(key);
          events.push({ type: "rn", name });
        }
      }
      for (const match of line.matchAll(/(-?\d{1,5}\s*(?:[.,]\s*\d(?:\s*\d){0,3})?)\s*cm\b/gi)) {
        const value = decimal(match[1]);
        if (value !== null && value > 0 && value < 100) events.push({ type: "gap", differenceCm: value });
      }
    }

    const rulerTopM = rulerTopFromText(text);
    const nodes = [];
    const links = [];
    let gaps = [];
    let rulerInserted = false;
    const pushNode = (node, differenceCm) => {
      const previous = nodes[nodes.length - 1];
      nodes.push(node);
      if (previous && differenceCm !== null && differenceCm !== undefined) {
        links.push({ from: previous.key, to: node.key, differenceCm: Math.round(differenceCm * 10000) / 10000 });
      }
    };
    for (const event of events) {
      if (event.type === "gap") {
        gaps.push(event.differenceCm);
        continue;
      }
      const node = { key: `rn:${normalize(event.name)}`, type: "rn", name: event.name };
      if (!nodes.length) {
        pushNode(node, null);
      } else if (gaps.length >= 2 && rulerTopM !== null && !rulerInserted) {
        pushNode({ key: "ruler-top", type: "ruler", name: "Topo da régua", rulerTopM }, gaps[0]);
        pushNode(node, gaps[1]);
        rulerInserted = true;
      } else {
        pushNode(node, gaps.length ? gaps.reduce((sum, value) => sum + value, 0) : null);
      }
      gaps = [];
    }
    if (nodes.length && gaps.length && rulerTopM !== null && !rulerInserted) {
      pushNode({ key: "ruler-top", type: "ruler", name: "Topo da régua", rulerTopM }, gaps[0]);
      rulerInserted = true;
    }
    if (nodes.length && rulerTopM !== null && !rulerInserted) {
      nodes.push({ key: "ruler-top", type: "ruler", name: "Topo da régua", rulerTopM });
    }

    const relationships = [];
    for (let index = 0; index < nodes.length; index += 1) {
      if (nodes[index].type !== "rn") continue;
      let differenceCm = 0;
      let hasDifference = false;
      for (let next = index + 1; next < nodes.length; next += 1) {
        const link = links.find((item) => item.from === nodes[next - 1].key && item.to === nodes[next].key);
        if (link && decimal(link.differenceCm) !== null) {
          differenceCm += Number(link.differenceCm);
          hasDifference = true;
        }
        if (nodes[next].type === "rn") {
          if (hasDifference) relationships.push({
            high: nodes[index].name,
            low: nodes[next].name,
            differenceCm: Math.round(differenceCm * 10000) / 10000,
            source: "station-scheme"
          });
          break;
        }
      }
    }
    const complete = nodes.length >= 2 && links.length === nodes.length - 1
      && links.every((link, index) => link.from === nodes[index].key && link.to === nodes[index + 1].key);
    return { nodes, links, relationships, rulerTopM, complete };
  }

  function extractStation(lineText, fullText) {
    const relevantIndex = lineText.findIndex((line) => /Esta(?:ç|c)[aã]o\s*:?/i.test(line.text)
      && /\bRio\s*:?/i.test(line.text)
      && /\b(?:Estado|Localidade)\s*:?/i.test(line.text));
    const fallbackIndex = relevantIndex >= 0 ? relevantIndex : lineText.findIndex((line) => /Esta(?:ç|c)[aã]o\s*:/i.test(line.text) && /\bRio\s*:?/i.test(line.text));
    let source = fallbackIndex >= 0 ? lineText[fallbackIndex].text : fullText;
    const next = fallbackIndex >= 0 ? lineText[fallbackIndex + 1] : null;
    if (next && next.page === lineText[fallbackIndex].page && next.mode === lineText[fallbackIndex].mode
      && /Localidade\s*:\s*\S{1,20}$/i.test(source)
      && !/^(?:LH|Carta|Navio|Ano|F-43|Descri|RN|MT-)/i.test(next.text)) source = `${source} ${next.text}`;
    const row = source.match(/Esta(?:ç|c)[aã]o\s*:?\s*(.+)\s+Rio\s*:?\s*(.+?)\s+Estado\s*:?\s*(.+?)\s+Localidade\s*:?\s*(.+?)(?=\s+Munic[ií]pio\s*:|$)/i);
    const name = row ? clean(row[1]) : labelValue(source, "Esta(?:ç|c)[aã]o", ["Rio"]);
    const river = row ? clean(row[2]) : labelValue(source, "Rio", ["Estado"]);
    const state = row ? clean(row[3]) : labelValue(source, "Estado", ["Localidade"]);
    const locality = row ? clean(row[4]) : labelValue(source, "Localidade", ["Munic[ií]pio"]);
    const municipality = firstMatch(`${source}\n${fullText}`, [
      /Munic[ií]pio\s*:?\s*([^\n]+?)(?=\n|\s{2,}|\s+(?:Estado|UF|Localidade|Esta(?:ç|c)[aã]o|Rio)\s*:|$)/i
    ]);
    return { name, river, state: state.replace(/^[:\s]+/, ""), locality, municipality };
  }

  function extractAdministrative(text) {
    return {
      lh: firstMatch(text, [/\bLH\s*:?\s*(.+?)(?=\s{2,}|\s+Carta\b)/i]),
      chart: firstMatch(text, [/Carta\s*N[º°.]?\s*:?\s*(.+?)(?=\s{2,}|\s+(?:Comiss[aã]o|Navio)\b)/i]),
      vesselCommission: firstMatch(text, [/(?:Comiss[aã]o\s+Navio|Comiss[aã]o|Navio)\s*:?\s*(.+?)(?=\s{2,}|\s+Ano\b)/i]),
      year: firstMatch(text, [/\bAno\s*:?\s*((?:19|20)\d{2})/i]),
      team: firstMatch(text, [/(?:Pessoal que tomou parte[^\n]*|Equipe[^:]*):\s*([^\n]+)/i]),
      chief: firstMatch(text, [/Chefe (?:da comiss[aã]o|da equipe|de Equipe)\s*:?\s*([^\n]+)/i]),
      references: firstMatch(text, [/Documentos? de [Rr]efer[eê]ncia\s*:?\s*([^\n]+)/i])
    };
  }

  function extractCoordinates(text) {
    return {
      latitude: firstMatch(text, [/\bLat(?:itude)?\s*:?\s*([^\n]+?)(?=\s{2,}|\s+Fonte\b|$)/i]),
      longitude: firstMatch(text, [/\bLong(?:itude)?\s*:?\s*([^\n]+?)(?=\s{2,}|$)/i]),
      datum: firstMatch(text, [/\bDatum\s*:?\s*([^\n]+?)(?=\s{2,}|\s+Tipo\b|$)/i]),
      zone: firstMatch(text, [/\bFuso\s*:?\s*([^\n]+?)(?=\s{2,}|\s+Zero\b|$)/i])
    };
  }

  function extractOther(text) {
    return {
      nrPeriod: firstMatch(text, [/Per[ií]odo[^:]*NR\s*:?\s*([^\n]+)/i, /Per[ií]odo de observa(?:ç|c)[aã]o[^:]*:\s*([^\n]+)/i]),
      nrSource: firstMatch(text, [/Fonte de informa(?:ç|c)[aã]o\s*:?\s*([^\n]+)/i]),
      riverRegime: firstMatch(text, [/Regime do [Rr]io\s*:?\s*([^\n]+)/i]),
      bottomNature: firstMatch(text, [/Natureza do fundo[^:]*:\s*([^\n]+)/i]),
      responsible: firstMatch(text, [/Nome[^\n]*Respons[aá]vel[^:]*:\s*([^\n]+)/i]),
      anaCode: firstMatch(text, [/(?:N[uú]mero da esta(?:ç|c)[aã]o (?:na|da) ANA|Ag[eê]ncia Nacional de [ÁA]guas)\s*:?\s*(\d{6,12})/i]),
      rulerDescription: firstMatch(text, [/Descri(?:ç|c)[aã]o das r[eé]guas[^\n]*\n([^\n]+)/i]),
      observations: firstMatch(text, [/Outras informa(?:ç|c)[oõ]es\s*:?\s*([^\n]+)/i])
    };
  }

  function classify(text, fileName) {
    const sample = `${fileName || ""}\n${text.slice(0, 500)}`;
    if (/(?:^|[^A-Z0-9])PADR[AÃ]O(?:$|[^A-Z0-9])/i.test(sample)) return { value: "standard", confidence: "green", reason: "Texto explícito Padrão" };
    if (/ATUALIZAD|PROPOSTA|F\s*[-–]?\s*43\s+DE\s+LH|FICHA\s+DE\s+LH/i.test(sample)) return { value: "proposal", confidence: "yellow", reason: "Ficha de LH/atualização; confirme a classificação" };
    if (/\bLH\s*:?\s*\d/i.test(text) && /\b(?:NAVIO|COMISS[AÃ]O)\s*:/i.test(text) && /\bF\s*[-–]?\s*43\s*[-–]?\s*\d/i.test(text) && /\bconfeccionad[ao]\s+em\b/i.test(text)) {
      return { value: "proposal", confidence: "yellow", reason: "F-43 de LH sem indicação de Padrão; confirme a classificação" };
    }
    return { value: "unknown", confidence: "red", reason: "Classificação não reconhecida" };
  }

  function parse(input) {
    const lines = linesFrom(input);
    const text = combinedText(lines);
    const fileName = clean(input && input.sourceFileName || "F-43.pdf");
    const diagramStart = findDiagramStart(lines);
    const station = extractStation(lines, text);
    const administrative = extractAdministrative(text);
    const coordinates = extractCoordinates(text);
    const other = extractOther(text);
    const classification = classify(text, fileName);
    const descriptions = rnDescriptions(lines, diagramStart);
    const diagram = diagramData(lines, diagramStart);
    const stationScheme = stationSchemeData(lines, diagramStart, text);
    const spatial = spatialRelationshipData(lines, diagramStart);
    if (stationScheme.complete && stationScheme.relationships.length) diagram.relationships = stationScheme.relationships;
    else if (spatial.relationships.length) {
      const byPair = new Map(diagram.relationships.map((item) => [`${normalize(item.high)}|${normalize(item.low)}`, item]));
      spatial.relationships.forEach((item) => byPair.set(`${normalize(item.high)}|${normalize(item.low)}`, item));
      diagram.relationships = Array.from(byPair.values());
    }
    diagram.relationshipSuggestions = spatial.suggestions;
    diagram.stationScheme = stationScheme;
    diagram.rulerTopM = stationScheme.rulerTopM;
    const allNames = namesIn(text);
    const explicitPrincipal = text.match(/n[ií]vel de redu(?:ç|c)[aã]o\s+est[aá]\s*([\d.,]+)\s*cent[ií]metros\s+abaixo\s+da\s+([^\s.,;]+(?:\s*\([^)]*\))?)/i);
    const placeholderPrincipal = explicitPrincipal ? null : text.match(/n[ií]vel de redu(?:ç|c)[aã]o\s+est[aá]\s*_+\s*cent[ií]metros\s+abaixo\s+da\s+([^\s.,;]+)/i);
    let writtenPrincipalToNr = explicitPrincipal ? decimal(explicitPrincipal[1]) : null;
    const principalName = explicitPrincipal ? nameToken(explicitPrincipal[2]) : (placeholderPrincipal ? nameToken(placeholderPrincipal[1]) : "");
    if (writtenPrincipalToNr === null && placeholderPrincipal) {
      const sentence = lines.find((line) => /n[ií]vel de redu(?:ç|c)[aã]o\s+est[aá]\s*_+\s*cent[ií]metros/i.test(line.text));
      const numericLines = lines.slice(0, diagramStart).map((line, index) => ({
        index,
        line,
        value: /^[-+]?\d{1,5}\s*(?:[.,]\s*\d(?:\s*\d){0,3})?$/.test(clean(line.text)) ? decimal(line.text) : null
      })).filter((item) => item.value !== null && item.value >= 100 && !(Number.isInteger(item.value) && item.value >= 1900 && item.value <= 2100));
      const nearby = sentence ? numericLines.filter((item) => Number(item.line.page) === Number(sentence.page)
        && Math.abs(Number(item.line.y) - Number(sentence.y)) <= 12) : [];
      const selected = nearby.sort((a, b) => Math.abs(Number(a.line.y) - Number(sentence.y)) - Math.abs(Number(b.line.y) - Number(sentence.y)))[0]
        || numericLines.sort((a, b) => Math.abs(a.index - lines.indexOf(sentence)) - Math.abs(b.index - lines.indexOf(sentence)))[0];
      if (selected) writtenPrincipalToNr = selected.value;
    }
    let selectedTriple = diagram.triple;
    if (writtenPrincipalToNr !== null) {
      const values = diagram.numericCandidates.map((item) => item.value).filter((value) => value > 0);
      let preferred = null;
      for (const principalToNr of values) {
        if (principalToNr < 100) continue;
        for (const nrToZeroCandidate of values) {
          if (nrToZeroCandidate < 5 || nrToZeroCandidate === principalToNr) continue;
          for (const principalToZero of values) {
            if (principalToZero <= principalToNr || principalToZero === nrToZeroCandidate) continue;
            const error = Math.abs(principalToNr + nrToZeroCandidate - principalToZero);
            if (error > 0.35) continue;
            const score = error + Math.abs(principalToNr - writtenPrincipalToNr) / 1000 + (principalToZero < 500 ? 10 : 0);
            if (!preferred || score < preferred.score) preferred = { principalToNr, nrToZero: nrToZeroCandidate, principalToZero, error, score };
          }
        }
      }
      if (preferred) selectedTriple = preferred;
    }
    diagram.triple = selectedTriple;
    const diagramPrincipalToNr = selectedTriple ? selectedTriple.principalToNr : null;
    const nrToZero = selectedTriple ? selectedTriple.nrToZero : null;
    const calculatedPrincipalToZero = diagramPrincipalToNr !== null && nrToZero !== null ? Math.round((diagramPrincipalToNr + nrToZero) * 10000) / 10000 : null;
    const writtenPrincipalToZero = selectedTriple ? selectedTriple.principalToZero : null;
    const references = [];
    const ordered = stationScheme.nodes.filter((item) => item.type === "rn").map((item) => item.name);
    if (!ordered.length) diagram.vertical.forEach((item) => ordered.push(item.name));
    for (const name of allNames) {
      const existing = references.find((item) => normalize(item.name) === normalize(name));
      if (existing) continue;
      const order = ordered.findIndex((item) => normalize(item) === normalize(name));
      references.push({
        id: root.C32Model && root.C32Model.id ? root.C32Model.id("rn") : `rn-${references.length + 1}`,
        name,
        description: descriptions.get(name) || "",
        verticalOrder: order >= 0 ? order : null,
        isPrincipal: principalName ? normalize(name) === normalize(principalName) : false,
        status: "normal",
        confidence: order >= 0 || descriptions.has(name) ? "green" : "yellow"
      });
    }
    references.sort((a, b) => {
      if (a.verticalOrder !== null && b.verticalOrder !== null) return a.verticalOrder - b.verticalOrder;
      if (a.verticalOrder !== null) return -1;
      if (b.verticalOrder !== null) return 1;
      return 0;
    });
    references.forEach((item, index) => { if (item.verticalOrder === null) item.verticalOrder = index; });

    const code = firstMatch(text.slice(0, 1800), [/(?:F\s*[-–]\s*43)\s*[-–]\s*([A-Z0-9][A-Z0-9_/-]*(?:19|20)\d{2})/i, /(F-43-[A-Z0-9_/-]+)/i]);
    const version = firstMatch(text.slice(0, 800), [/Vers[aã]o\s*([0-9]+\s*\/\s*(?:19|20)\d{2})/i]);
    const confectionDate = firstMatch(text, [/confeccionad[ao]\s+em\s+(\d{1,2}\/\d{1,2}\/\d{4})/i]);
    const updateDate = firstMatch(text, [/atualizad[ao]\s+em\s+(\d{1,2}\/\d{1,2}\/\d{4})/i]) || confectionDate;
    const inconsistencies = [];
    if (writtenPrincipalToNr !== null && diagramPrincipalToNr !== null && Math.abs(writtenPrincipalToNr - diagramPrincipalToNr) > 0.049) {
      inconsistencies.push({
        id: "principal-to-nr-document-conflict",
        essential: true,
        status: "unresolved",
        title: "Divergência encontrada",
        values: [writtenPrincipalToNr, diagramPrincipalToNr],
        labels: ["Cabeçalho", "Diagrama"]
      });
    }
    if (selectedTriple && Math.abs(calculatedPrincipalToZero - writtenPrincipalToZero) > 0.049) {
      inconsistencies.push({
        id: "principal-to-zero-math-conflict",
        essential: true,
        status: "unresolved",
        title: "Inconsistência matemática nas cotas",
        values: [writtenPrincipalToZero, calculatedPrincipalToZero],
        labels: ["Escrito", "Calculado"]
      });
    }

    const result = {
      format: "c32-f43-interpretation",
      parserVersion: "2.1.2",
      sourceFileName: fileName,
      extraction: {
        mode: clean(input && input.extractionMode || "text"),
        pages: Math.max(1, ...lines.map((line) => Number(line.page) || 1)),
        characterCount: text.length,
        averageConfidence: input && input.averageConfidence != null ? Number(input.averageConfidence) : null
      },
      classification,
      station: {
        name: valueField(station.name, true),
        river: valueField(station.river, false),
        locality: valueField(station.locality, false),
        municipality: valueField(station.municipality || "", false),
        state: valueField(station.state, false),
        stationCode: valueField(code, false),
        anaCode: valueField(other.anaCode, false)
      },
      identification: {
        code: valueField(code, false),
        version: valueField(version, false),
        lh: valueField(administrative.lh, false),
        chart: valueField(administrative.chart, false),
        vesselCommission: valueField(administrative.vesselCommission, false),
        year: valueField(administrative.year, false),
        confectionDate: valueField(confectionDate, false),
        updateDate: valueField(updateDate, false)
      },
      administrative: {
        team: valueField(administrative.team, false),
        chief: valueField(administrative.chief, false),
        referenceDocuments: valueField(administrative.references, false)
      },
      geographic: {
        latitude: valueField(coordinates.latitude, false),
        longitude: valueField(coordinates.longitude, false),
        datum: valueField(coordinates.datum, false),
        zone: valueField(coordinates.zone, false)
      },
      references,
      principalRn: valueField(principalName, true, principalName ? "green" : "red", "explicit-sentence"),
      diagram: {
        verticalOrder: references.map((item) => item.name),
        relationships: diagram.relationships,
        stationScheme,
        rulerTopM: stationScheme.rulerTopM,
        principalToNrWrittenCm: writtenPrincipalToNr,
        principalToNrDiagramCm: diagramPrincipalToNr,
        nrToZeroCm: nrToZero,
        principalToZeroWrittenCm: writtenPrincipalToZero,
        principalToZeroCalculatedCm: calculatedPrincipalToZero,
        principalToZeroConfirmedCm: inconsistencies.length ? null : writtenPrincipalToZero,
        principalToNrConfirmedCm: inconsistencies.some((item) => item.id === "principal-to-nr-document-conflict") ? null : (writtenPrincipalToNr !== null ? writtenPrincipalToNr : diagramPrincipalToNr)
      },
      nr: {
        period: valueField(other.nrPeriod, false),
        methodSource: valueField(other.nrSource, false),
        percentile: valueField(firstMatch(`${other.nrPeriod}\n${other.nrSource}`, [/percentil\s*(\d+(?:[.,]\d+)?)/i, /(\d+(?:[.,]\d+)?)\s*%/]), false)
      },
      descriptions: {
        ruler: valueField(other.rulerDescription, false),
        riverRegime: valueField(other.riverRegime, false),
        bottomNature: valueField(other.bottomNature, false),
        responsible: valueField(other.responsible, false),
        observations: valueField(other.observations, false)
      },
      inconsistencies,
      corrections: [],
      rawTextPreview: text.slice(0, 1200)
    };
    return validate(result);
  }

  function relationshipKey(high, low) {
    return `${normalize(high)}\u0000${normalize(low)}`;
  }

  function ensureRelationshipDrafts(result) {
    if (!result || !result.diagram) return [];
    const existingDrafts = Array.isArray(result.diagram.relationshipDrafts) ? result.diagram.relationshipDrafts : [];
    const source = [];
    for (const item of existingDrafts.concat(result.diagram.relationships || []).concat(result.diagram.relationshipSuggestions || [])) {
      if (!item || !clean(item.high) || !clean(item.low)) continue;
      const key = relationshipKey(item.high, item.low);
      if (!source.some((entry) => relationshipKey(entry.high, entry.low) === key)) source.push(item);
    }
    const drafts = [];
    const refs = Array.isArray(result.references) ? result.references : [];
    for (let index = 0; index < refs.length - 1; index += 1) {
      const high = refs[index].name; const low = refs[index + 1].name;
      const direct = source.find((item) => relationshipKey(item.high, item.low) === relationshipKey(high, low));
      const reverse = direct ? null : source.find((item) => relationshipKey(item.low, item.high) === relationshipKey(high, low));
      const found = direct || reverse;
      drafts.push({
        high, low,
        differenceCm: found && decimal(found.differenceCm) !== null ? decimal(found.differenceCm) : null,
        source: found ? (found.source || "recognized") : "manual",
        confidence: found ? (found.confidence || (found.source === "spatial-layout" ? "high" : "recognized")) : "missing"
      });
    }
    result.diagram.relationshipDrafts = drafts;
    result.diagram.relationships = drafts.filter((item) => decimal(item.differenceCm) !== null).map((item) => ({
      high: item.high, low: item.low, differenceCm: decimal(item.differenceCm), source: item.source || "manual", confidence: item.confidence || "manual"
    }));
    const scheme = result.diagram.stationScheme;
    if (!scheme || !Array.isArray(scheme.nodes) || !scheme.nodes.length || scheme.complete === false) {
      const nodes = refs.map((item, index) => ({ key: `rn:${normalize(item.name)}:${index}`, type: "rn", name: item.name }));
      const links = [];
      result.diagram.relationships.forEach((relation) => {
        const hi = refs.findIndex((item) => normalize(item.name) === normalize(relation.high));
        const lo = refs.findIndex((item) => normalize(item.name) === normalize(relation.low));
        if (hi >= 0 && lo === hi + 1) links.push({ from: nodes[hi].key, to: nodes[lo].key, differenceCm: relation.differenceCm });
      });
      result.diagram.stationScheme = {
        nodes, links, relationships: JSON.parse(JSON.stringify(result.diagram.relationships)),
        rulerTopM: result.diagram.rulerTopM == null ? null : result.diagram.rulerTopM,
        complete: nodes.length >= 2 && links.length === nodes.length - 1
      };
    } else {
      scheme.relationships = JSON.parse(JSON.stringify(result.diagram.relationships));
    }
    return drafts;
  }

  function recalculate(result) {
    const output = result;
    output.references.forEach((item, index) => { item.verticalOrder = index; item.isPrincipal = normalize(item.name) === normalize(output.principalRn.value); });
    output.diagram.verticalOrder = output.references.map((item) => item.name);
    ensureRelationshipDrafts(output);
    const scheme = output.diagram.stationScheme;
    if (scheme && Array.isArray(scheme.nodes)) {
      const rnNodes = scheme.nodes.filter((item) => item.type === "rn");
      if (rnNodes.length <= output.references.length) {
        const keyMap = new Map();
        rnNodes.forEach((node, index) => {
          const oldKey = node.key;
          node.name = output.references[index].name;
          node.key = `rn:${normalize(node.name)}:${index}`;
          keyMap.set(oldKey, node.key);
        });
        (scheme.links || []).forEach((link) => {
          link.from = keyMap.get(link.from) || link.from;
          link.to = keyMap.get(link.to) || link.to;
        });
      } else {
        scheme.nodes = [];
        scheme.links = [];
      }
    }
    const p = decimal(output.diagram.principalToNrConfirmedCm);
    const n = decimal(output.diagram.nrToZeroCm);
    output.diagram.principalToZeroCalculatedCm = p !== null && n !== null ? Math.round((p + n) * 10000) / 10000 : null;
    return validate(output);
  }

  function validate(result) {
    const blocking = [];
    const review = [];
    if (!clean(result.classification.value) || result.classification.value === "unknown") blocking.push("Classifique a F-43 como Padrão ou Atualização.");
    if (!clean(result.station.name.value)) review.push("Nome da estação não informado.");
    if (!clean(result.station.municipality.value)) review.push("Município não informado.");
    if (!Array.isArray(result.references) || !result.references.length) review.push("Nenhuma RN informada.");
    if (!clean(result.principalRn.value)) review.push("RN Principal não informada.");
    if (decimal(result.diagram.principalToNrConfirmedCm) === null) review.push("RN Principal → NR não confirmado.");
    ensureRelationshipDrafts(result);
    const missingRelations = (result.diagram.relationshipDrafts || []).filter((item) => decimal(item.differenceCm) === null).length;
    if (missingRelations) review.push(`${missingRelations} cota(s) entre referências não informada(s).`);
    result.inconsistencies.filter((item) => item.essential && item.status !== "resolved").forEach((item) => review.push(item.title));
    result.essentialPending = [...new Set(blocking)];
    result.reviewPending = [...new Set(review)];
    result.canImport = result.essentialPending.length === 0;
    return result;
  }

  function resolveInconsistency(result, id, value) {
    const item = result.inconsistencies.find((entry) => entry.id === id);
    if (!item) throw new Error("Inconsistência não encontrada.");
    const numeric = decimal(value);
    if (numeric === null) throw new Error("Informe um valor numérico válido.");
    item.status = "resolved";
    item.resolvedValue = numeric;
    result.corrections.push({ field: id, value: numeric, at: new Date().toISOString() });
    if (id === "principal-to-nr-document-conflict") result.diagram.principalToNrConfirmedCm = numeric;
    if (id === "principal-to-zero-math-conflict") result.diagram.principalToZeroConfirmedCm = numeric;
    return recalculate(result);
  }

  function toRecords(result) {
    validate(result);
    if (!result.canImport) throw new Error(`Informe a classificação da ficha: ${result.essentialPending.join(" ")}`);
    ensureRelationshipDrafts(result);
    const station = {
      name: clean(result.station.name.value),
      river: clean(result.station.river.value),
      locality: clean(result.station.locality.value),
      municipality: clean(result.station.municipality.value),
      state: clean(result.station.state.value),
      stationCode: clean(result.station.stationCode.value),
      anaCode: clean(result.station.anaCode.value)
    };
    const f43 = {
      kind: result.classification.value === "standard" ? "standard" : "proposal-source",
      current: result.classification.value === "standard",
      sourceFileName: result.sourceFileName,
      code: clean(result.identification.code.value),
      version: clean(result.identification.version.value),
      lh: clean(result.identification.lh.value),
      chart: clean(result.identification.chart.value),
      vesselCommission: clean(result.identification.vesselCommission.value),
      year: clean(result.identification.year.value),
      confectionDate: clean(result.identification.confectionDate.value),
      updateDate: clean(result.identification.updateDate.value),
      station: cloneStation(station),
      administrative: Object.fromEntries(Object.entries(result.administrative).map(([key, field]) => [key, clean(field.value)])),
      geographic: Object.fromEntries(Object.entries(result.geographic).map(([key, field]) => [key, clean(field.value)])),
      references: result.references.map((item) => ({ name: item.name, description: item.description || "", verticalOrder: item.verticalOrder, isPrincipal: item.isPrincipal })),
      principalRn: clean(result.principalRn.value),
      diagram: JSON.parse(JSON.stringify(result.diagram)),
      relationships: JSON.parse(JSON.stringify(result.diagram.relationships || [])),
      stationScheme: JSON.parse(JSON.stringify(result.diagram.stationScheme || {})),
      nr: Object.fromEntries(Object.entries(result.nr).map(([key, field]) => [key, clean(field.value)])),
      descriptions: Object.fromEntries(Object.entries(result.descriptions).map(([key, field]) => [key, clean(field.value)])),
      extraction: JSON.parse(JSON.stringify(result.extraction)),
      correctionCount: result.corrections.length,
      importedAt: new Date().toISOString()
    };
    delete f43.diagram.verticalOrder;
    return { station, f43 };
  }

  function fromRecord(record) {
    const source = JSON.parse(JSON.stringify(record || {}));
    const station = source.station || {};
    const diagram = source.diagram || {};
    const fieldMap = (object) => Object.fromEntries(Object.entries(object || {}).map(([key, value]) => [key, valueField(value, false, value === "" || value == null ? "yellow" : "green", "stored")]));
    const classification = source.kind === "standard" ? "standard" : "proposal";
    const output = {
      format: "c32-f43-interpretation",
      parserVersion: "2.1.2",
      sourceFileName: source.sourceFileName || "F-43 cadastrada",
      extraction: JSON.parse(JSON.stringify(source.extraction || { mode: "stored-record", pages: 0, characterCount: 0, averageConfidence: null })),
      classification: { value: classification, confidence: "green", reason: "Classificação do registro armazenado" },
      station: {
        name: valueField(station.name || "", false, station.name ? "green" : "yellow", "stored"),
        river: valueField(station.river || "", false, station.river ? "green" : "yellow", "stored"),
        locality: valueField(station.locality || "", false, station.locality ? "green" : "yellow", "stored"),
        municipality: valueField(station.municipality || "", false, station.municipality ? "green" : "yellow", "stored"),
        state: valueField(station.state || "", false, station.state ? "green" : "yellow", "stored"),
        stationCode: valueField(station.stationCode || source.code || "", false, "green", "stored"),
        anaCode: valueField(station.anaCode || "", false, station.anaCode ? "green" : "yellow", "stored")
      },
      identification: {
        code: valueField(source.code || "", false, "green", "stored"), version: valueField(source.version || "", false, "green", "stored"),
        lh: valueField(source.lh || (source.metadata && source.metadata.lh) || "", false, "green", "stored"),
        chart: valueField(source.chart || (source.metadata && source.metadata.chart) || "", false, "green", "stored"),
        vesselCommission: valueField(source.vesselCommission || (source.metadata && source.metadata.vesselCommission) || "", false, "green", "stored"),
        year: valueField(source.year || "", false, "green", "stored"), confectionDate: valueField(source.confectionDate || "", false, "green", "stored"), updateDate: valueField(source.updateDate || source.date || source.dateKey || "", false, "green", "stored")
      },
      administrative: fieldMap(source.administrative || {}), geographic: fieldMap(source.geographic || {}),
      references: (source.references || []).map((item, index) => ({ id: item.id || `rn-${index+1}`, name: item.name || "", description: item.description || "", verticalOrder: item.verticalOrder == null ? index : item.verticalOrder, isPrincipal: Boolean(item.isPrincipal) || normalize(item.name) === normalize(source.principalRn), status: item.status || "normal", confidence: "green" })),
      principalRn: valueField(source.principalRn || "", false, source.principalRn ? "green" : "yellow", "stored"),
      diagram: Object.assign({ relationships: source.relationships || [], stationScheme: source.stationScheme || {}, rulerTopM: source.rulerTopM == null ? null : source.rulerTopM, principalToNrWrittenCm: null, principalToNrDiagramCm: null, nrToZeroCm: source.nrToZeroCm == null ? null : source.nrToZeroCm, principalToZeroWrittenCm: source.principalToZeroCm == null ? null : source.principalToZeroCm, principalToZeroCalculatedCm: source.principalToZeroCm == null ? null : source.principalToZeroCm, principalToZeroConfirmedCm: source.principalToZeroCm == null ? null : source.principalToZeroCm, principalToNrConfirmedCm: source.principalToNrCm == null ? null : source.principalToNrCm }, diagram),
      nr: fieldMap(source.nr || {}), descriptions: fieldMap(source.descriptions || { ruler: source.rulerDescription || "", observations: source.observations || "" }),
      inconsistencies: [], corrections: [], rawTextPreview: ""
    };
    if (!output.administrative.team) output.administrative.team = valueField("", false, "yellow", "stored");
    if (!output.administrative.chief) output.administrative.chief = valueField("", false, "yellow", "stored");
    if (!output.administrative.referenceDocuments) output.administrative.referenceDocuments = valueField("", false, "yellow", "stored");
    for (const key of ["latitude","longitude","datum","zone"]) if (!output.geographic[key]) output.geographic[key] = valueField("", false, "yellow", "stored");
    for (const key of ["period","methodSource","percentile"]) if (!output.nr[key]) output.nr[key] = valueField("", false, "yellow", "stored");
    for (const key of ["ruler","riverRegime","bottomNature","responsible","observations"]) if (!output.descriptions[key]) output.descriptions[key] = valueField("", false, "yellow", "stored");
    return recalculate(output);
  }

  function cloneStation(station) {
    return JSON.parse(JSON.stringify(station));
  }

  const api = {
    clean,
    normalize,
    decimal,
    valueField,
    namesIn,
    parse,
    validate,
    recalculate,
    resolveInconsistency,
    toRecords,
    fromRecord,
    ensureRelationshipDrafts,
    spatialRelationshipData,
    diagramData,
    stationSchemeData
  };

  root.C32F43Parser = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
