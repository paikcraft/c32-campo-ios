(function (root) {
  "use strict";

  const DEFAULT_CRITERIA = Object.freeze({
    vrfToleranceMm: 2,
    maxSightDistanceM: 50,
    closureUpTo1KmMm: 8,
    closureAbove1KmCoefficientMm: 8,
    standardToleranceMm: 2
  });
  const LIMITS = Object.freeze(Object.assign({ maxReadingMm: 9999 }, DEFAULT_CRITERIA));

  function cleanName(value) {
    return String(value == null ? "" : value).trim().replace(/\s+/g, " ");
  }

  function normName(value) {
    return cleanName(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toUpperCase();
  }

  function sameName(a, b) {
    return normName(a) !== "" && normName(a) === normName(b);
  }

  function isTemporaryPoint(name) {
    // Em campo, a grafia mais comum é PT1/PT2 (sem espaço). O teste anterior
    // tratava apenas "PT 1" e "PT-1", fazendo PT1 parecer uma RN permanente.
    return /^PT(?:\d+|\b|[-_\s])/i.test(normName(name));
  }

  function isRulerPoint(name) {
    return normName(name).includes("REGUA");
  }

  function parseNumber(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    const text = String(value == null ? "" : value).trim();
    if (!text) return null;
    const normalized = text.includes(",") && text.includes(".")
      ? text.replace(/\./g, "").replace(",", ".")
      : text.replace(",", ".");
    const result = Number(normalized);
    return Number.isFinite(result) ? result : null;
  }

  function round(value, digits = 6) {
    const factor = 10 ** digits;
    return Math.round((value + Number.EPSILON) * factor) / factor;
  }

  function resolveCriteria(source) {
    const input = source && source.criteria ? source.criteria : (source || {});
    const output = Object.assign({}, DEFAULT_CRITERIA);
    for (const key of Object.keys(DEFAULT_CRITERIA)) {
      const numeric = parseNumber(input[key]);
      if (numeric !== null && numeric > 0) output[key] = numeric;
    }
    return output;
  }

  function calculateReading(reading, label, criteria) {
    const rules = resolveCriteria(criteria);
    const sup = parseNumber(reading && reading.sup);
    const cen = parseNumber(reading && reading.cen);
    const inf = parseNumber(reading && reading.inf);
    const values = [sup, cen, inf];
    const complete = values.every((v) => v !== null);
    const issues = [];
    const warnings = [];
    if (!complete) {
      return { complete: false, valid: false, issues: [`${label}: leitura incompleta`], warnings, sup, cen, inf, vrfMm: null, distanceM: null, meanMm: null };
    }
    if (values.some((v) => v < 0)) issues.push(`${label}: valor negativo`);
    if (values.some((v) => v > LIMITS.maxReadingMm)) issues.push(`${label}: leitura com mais de 4 dígitos`);
    const meanMm = (sup + inf) / 2;
    const vrfMm = Math.abs(cen - meanMm);
    const distanceM = Math.abs(sup - inf) / 10;
    if (vrfMm > rules.vrfToleranceMm + 1e-7) {
      issues.push(`${label}: VRF ${vrfMm.toFixed(2)} mm (limite ${rules.vrfToleranceMm.toFixed(2)} mm)`);
    }
    if (distanceM > rules.maxSightDistanceM + 1e-7) {
      warnings.push(`${label}: visada ${distanceM.toFixed(2)} m (recomendado até ${rules.maxSightDistanceM.toFixed(2)} m)`);
    }
    if (sup < cen - 1e-7 || cen < inf - 1e-7) {
      issues.push(`${label}: ordem inválida; use SUP ≥ CEN ≥ INF`);
    }
    return {
      complete: true,
      valid: issues.length === 0,
      issues,
      warnings,
      sup,
      cen,
      inf,
      meanMm,
      vrfMm,
      distanceM
    };
  }

  function calculateLance(lance, index, criteria) {
    const from = cleanName(lance && lance.from);
    const to = cleanName(lance && lance.to);
    const ar = calculateReading(lance && lance.ar, "AR", criteria);
    const av = calculateReading(lance && lance.av, "AV", criteria);
    const issues = [];
    const warnings = [];
    if (!from) issues.push("Ponto AR não informado");
    if (!to) issues.push("Ponto AV não informado");
    if (from && to && sameName(from, to)) issues.push("Os pontos AR e AV são iguais");
    issues.push(...ar.issues, ...av.issues);
    warnings.push(...ar.warnings, ...av.warnings);
    const complete = Boolean(from && to && ar.complete && av.complete);
    const valid = complete && issues.length === 0;
    return {
      id: lance && lance.id,
      index,
      from,
      to,
      ar,
      av,
      complete,
      valid,
      issues,
      warnings,
      deltaMm: valid ? round(ar.cen - av.cen) : null,
      distanceM: ar.complete && av.complete ? round(ar.distanceM + av.distanceM) : null
    };
  }

  function canAutoAdvanceAfterVanteCentral(row) {
    return Boolean(row && row.valid && (!row.warnings || row.warnings.length === 0));
  }

  function calculateRun(lances, criteria) {
    const rows = (lances || []).map((lance, index) => calculateLance(lance, index, criteria));
    const issues = [];
    const warnings = [];
    let continuous = true;
    for (let i = 1; i < rows.length; i += 1) {
      if (rows[i - 1].to && rows[i].from && !sameName(rows[i - 1].to, rows[i].from)) {
        continuous = false;
        issues.push(`Sequência descontínua entre os lances ${i} e ${i + 1}`);
      }
    }
    rows.forEach((row) => row.issues.forEach((issue) => issues.push(`Lance ${row.index + 1}: ${issue}`)));
    rows.forEach((row) => row.warnings.forEach((warning) => warnings.push(`Lance ${row.index + 1}: ${warning}`)));
    const complete = rows.length > 0 && rows.every((row) => row.complete) && continuous;
    const valid = rows.length > 0 && rows.every((row) => row.valid) && continuous;
    return {
      rows,
      issues,
      warnings,
      continuous,
      complete,
      valid,
      start: rows.length ? rows[0].from : "",
      end: rows.length ? rows[rows.length - 1].to : "",
      deltaMm: valid ? round(rows.reduce((sum, row) => sum + row.deltaMm, 0)) : null,
      distanceM: rows.every((row) => row.distanceM !== null)
        ? round(rows.reduce((sum, row) => sum + row.distanceM, 0))
        : null
    };
  }

  function buildPathsEndingAt(rows, endIndex) {
    const paths = [];
    for (let startIndex = endIndex; startIndex >= 0; startIndex -= 1) {
      let continuous = true;
      for (let i = startIndex + 1; i <= endIndex; i += 1) {
        if (!sameName(rows[i - 1].to, rows[i].from)) continuous = false;
      }
      if (!continuous) break;
      const part = rows.slice(startIndex, endIndex + 1);
      const complete = part.every((row) => row.complete);
      const valid = part.every((row) => row.valid);
      paths.push({
        startIndex,
        endIndex,
        start: part[0].from,
        end: part[part.length - 1].to,
        complete,
        valid,
        deltaMm: valid ? round(part.reduce((sum, row) => sum + row.deltaMm, 0)) : null,
        distanceM: part.every((row) => row.distanceM !== null)
          ? round(part.reduce((sum, row) => sum + row.distanceM, 0))
          : null
      });
    }
    return paths;
  }

  function allPaths(rows) {
    const paths = [];
    for (let i = 0; i < rows.length; i += 1) paths.push(...buildPathsEndingAt(rows, i));
    return paths;
  }

  function findPath(runOrRows, start, end) {
    const rows = Array.isArray(runOrRows) ? runOrRows : runOrRows.rows;
    const candidates = allPaths(rows)
      .filter((path) => sameName(path.start, start) && sameName(path.end, end))
      .sort((a, b) => (a.endIndex - a.startIndex) - (b.endIndex - b.startIndex));
    if (candidates.length) return Object.assign({ reversed: false }, candidates[0]);
    const reversed = allPaths(rows)
      .filter((path) => sameName(path.start, end) && sameName(path.end, start))
      .sort((a, b) => (a.endIndex - a.startIndex) - (b.endIndex - b.startIndex));
    if (!reversed.length) return null;
    const path = reversed[0];
    return Object.assign({}, path, {
      start,
      end,
      deltaMm: path.deltaMm === null ? null : -path.deltaMm,
      reversed: true
    });
  }

  function expectedForReference(reference, start, end) {
    const differenceCm = parseNumber(reference && reference.differenceCm);
    const differenceM = parseNumber(reference && reference.differenceM);
    const differenceMm = differenceCm !== null ? differenceCm * 10 : (differenceM !== null ? differenceM * 1000 : null);
    if (differenceMm === null || differenceMm < 0) return null;
    if (sameName(reference.high, start) && sameName(reference.low, end)) return -differenceMm;
    if (sameName(reference.low, start) && sameName(reference.high, end)) return differenceMm;
    return null;
  }

  function toleranceForDistance(distanceM, criteria) {
    const rules = resolveCriteria(criteria);
    if (distanceM === null || !Number.isFinite(distanceM) || distanceM <= 1000) return rules.closureUpTo1KmMm;
    return rules.closureAbove1KmCoefficientMm * Math.sqrt(distanceM / 1000);
  }

  function withinStrictTolerance(errorMm, toleranceMm) {
    if (!Number.isFinite(errorMm) || !Number.isFinite(toleranceMm) || toleranceMm <= 0) return false;
    return Math.abs(errorMm) + 1e-7 < toleranceMm;
  }

  function indicator(status, details) {
    return Object.assign({ status }, details || {});
  }

  function findPermanentSegmentPair(idaRun, voltaSegment) {
    const segments = permanentSegments(idaRun);
    const reversed = segments.find((segment) => sameName(segment.start, voltaSegment.end) && sameName(segment.end, voltaSegment.start));
    if (reversed) return { segment: reversed, reversed: true };
    const same = segments.find((segment) => sameName(segment.start, voltaSegment.start) && sameName(segment.end, voltaSegment.end));
    return same ? { segment: same, reversed: false } : null;
  }

  function comparePermanentSegment(idaRun, voltaSegment, criteria) {
    const pair = findPermanentSegmentPair(idaRun, voltaSegment);
    if (!pair) return null;
    const idaSegment = pair.segment;
    if (!idaSegment.complete || !voltaSegment.complete) return { status: "—", reason: "Trecho ainda incompleto", idaPath: idaSegment, path: voltaSegment };
    if (!idaSegment.valid || !voltaSegment.valid) return { status: "ERRO", reason: "Leitura inválida no trecho", idaPath: idaSegment, path: voltaSegment };
    // O sinal operacional é sempre expresso no sentido da IDA.
    const voltaNormalizedMm = pair.reversed ? -voltaSegment.deltaMm : voltaSegment.deltaMm;
    const differenceMm = idaSegment.deltaMm - voltaNormalizedMm;
    const meanDistance = ((idaSegment.distanceM || 0) + (voltaSegment.distanceM || 0)) / 2;
    const toleranceMm = toleranceForDistance(meanDistance, criteria);
    return {
      status: withinStrictTolerance(differenceMm, toleranceMm) ? "OK" : "ERRO",
      differenceMm: round(differenceMm),
      toleranceMm: round(toleranceMm),
      idaMm: idaSegment.deltaMm,
      voltaMm: voltaSegment.deltaMm,
      voltaNormalizedMm,
      path: voltaSegment,
      idaPath: idaSegment,
      reversed: pair.reversed
    };
  }

  function segmentPointSequence(run, segment) {
    if (!run || !segment || segment.startIndex == null || segment.endIndex == null) return [];
    const rows = run.rows.slice(segment.startIndex, segment.endIndex + 1);
    if (!rows.length) return [];
    return [rows[0].from, ...rows.map((row) => row.to)];
  }

  function hasUniquePointSequence(points) {
    const normalized = (points || []).map(normName).filter(Boolean);
    return normalized.length > 1 && new Set(normalized).size === normalized.length;
  }

  function mirroredSegmentRows(idaRun, voltaRun, voltaSegment) {
    const pair = findPermanentSegmentPair(idaRun, voltaSegment);
    if (!pair) return null;
    const idaSegment = pair.segment;
    const idaPoints = segmentPointSequence(idaRun, idaSegment);
    const voltaPoints = segmentPointSequence(voltaRun, voltaSegment);
    if (idaPoints.length !== voltaPoints.length || idaPoints.length < 2) return null;
    // Para considerar a correspondência dos PTs inequívoca, todos os nomes do bloco
    // precisam ser únicos e a sequência deve coincidir exatamente (direta ou invertida).
    if (!hasUniquePointSequence(idaPoints) || !hasUniquePointSequence(voltaPoints)) return null;
    const target = pair.reversed ? idaPoints.slice().reverse() : idaPoints.slice();
    if (!target.every((point, index) => sameName(point, voltaPoints[index]))) return null;

    const matches = [];
    const count = voltaSegment.endIndex - voltaSegment.startIndex + 1;
    for (let offset = 0; offset < count; offset += 1) {
      const voltaIndex = voltaSegment.startIndex + offset;
      const idaIndex = pair.reversed ? idaSegment.endIndex - offset : idaSegment.startIndex + offset;
      matches.push({ idaIndex, voltaIndex, reversed: pair.reversed });
    }
    return { pair, matches };
  }

  function annotateVolta(idaRun, voltaRun, references, criteria) {
    const rules = resolveCriteria(criteria);
    const output = voltaRun.rows.map(() => ({ ida: indicator("—"), standard: indicator("—") }));
    const voltaSegmentsByEnd = new Map(permanentSegments(voltaRun).map((segment) => [segment.endIndex, segment]));
    for (let i = 0; i < voltaRun.rows.length; i += 1) {
      const candidates = buildPathsEndingAt(voltaRun.rows, i).filter((path) => {
        return path.start && path.end && !sameName(path.start, path.end) && !isTemporaryPoint(path.start) && !isTemporaryPoint(path.end);
      });
      let standardCandidate = null;
      let standardReference = null;
      let standardExpected = null;
      for (const candidate of candidates) {
        for (const ref of references || []) {
          const expected = expectedForReference(ref, candidate.start, candidate.end);
          if (expected !== null) {
            standardCandidate = candidate;
            standardReference = ref;
            standardExpected = expected;
            break;
          }
        }
        if (standardCandidate) break;
      }
      if (standardCandidate) {
        const idaCandidate = findPath(idaRun, standardCandidate.start, standardCandidate.end);
        if (!idaCandidate || !idaCandidate.complete || !standardCandidate.complete) {
          output[i].standard = indicator("—", {
            reason: "Aguardando IDA e VOLTA completas para calcular a média",
            path: standardCandidate,
            idaPath: idaCandidate,
            reference: standardReference
          });
        } else if (!idaCandidate.valid || !standardCandidate.valid) {
          output[i].standard = indicator("ERRO", {
            reason: "Leitura inválida no trecho",
            path: standardCandidate,
            idaPath: idaCandidate,
            reference: standardReference
          });
        } else {
          // PADRÃO v0.1.15: comparar a relação conhecida com a média dos módulos
          // dos desníveis obtidos na IDA e na VOLTA, independentemente do sentido.
          const idaAbsMm = Math.abs(idaCandidate.deltaMm);
          const voltaAbsMm = Math.abs(standardCandidate.deltaMm);
          const measuredMeanMm = round((idaAbsMm + voltaAbsMm) / 2);
          const expectedAbsMm = Math.abs(standardExpected);
          const signedDifferenceMm = round(measuredMeanMm - expectedAbsMm);
          const differenceMm = round(Math.abs(signedDifferenceMm));
          output[i].standard = indicator(differenceMm <= rules.standardToleranceMm + 1e-7 ? "OK" : "ERRO", {
            differenceMm,
            signedDifferenceMm,
            measuredMm: measuredMeanMm,
            idaMeasuredMm: round(idaAbsMm),
            voltaMeasuredMm: round(voltaAbsMm),
            expectedMm: round(expectedAbsMm),
            reference: standardReference,
            path: standardCandidate,
            idaPath: idaCandidate
          });
        }
      }

      // IDA × VOLTA continua sendo fechada por blocos entre referências permanentes.
      // A exibição progressiva dos PTs, quando inequívoca, é tratada separadamente.
      const voltaSegment = voltaSegmentsByEnd.get(i);
      if (voltaSegment) {
        const comparison = comparePermanentSegment(idaRun, voltaSegment, rules);
        if (comparison) output[i].ida = indicator(comparison.status, comparison);
      }
    }
    return output;
  }

  function progressiveVolta(idaRun, voltaRun, voltaIndicators, criteria) {
    const output = voltaRun.rows.map(() => ({ idaDifferenceMm: null, accumulatedMm: null, toleranceMm: null, status: "—" }));
    let accumulatedMm = 0;
    let accumulatedKnown = true;
    for (const voltaSegment of permanentSegments(voltaRun)) {
      const mirrored = mirroredSegmentRows(idaRun, voltaRun, voltaSegment);
      if (mirrored) {
        for (const match of mirrored.matches) {
          const idaRow = idaRun.rows[match.idaIndex];
          const voltaRow = voltaRun.rows[match.voltaIndex];
          if (!idaRow || !voltaRow || !idaRow.complete || !voltaRow.complete || !idaRow.valid || !voltaRow.valid) {
            accumulatedKnown = false;
            continue;
          }
          const voltaNormalizedMm = match.reversed ? -voltaRow.deltaMm : voltaRow.deltaMm;
          const differenceMm = round(idaRow.deltaMm - voltaNormalizedMm);
          const meanDistance = ((idaRow.distanceM || 0) + (voltaRow.distanceM || 0)) / 2;
          const toleranceMm = toleranceForDistance(meanDistance, criteria);
          if (accumulatedKnown) accumulatedMm = round(accumulatedMm + differenceMm);
          output[match.voltaIndex] = {
            idaDifferenceMm: differenceMm,
            accumulatedMm: accumulatedKnown ? accumulatedMm : null,
            toleranceMm: round(toleranceMm),
            status: withinStrictTolerance(differenceMm, toleranceMm) ? "OK" : "ERRO",
            progressivePointMatch: true,
            idaIndex: match.idaIndex
          };
        }
        continue;
      }

      const comparison = comparePermanentSegment(idaRun, voltaSegment, criteria);
      if (!comparison || !Number.isFinite(comparison.differenceMm)) {
        accumulatedKnown = false;
        continue;
      }
      if (accumulatedKnown) accumulatedMm = round(accumulatedMm + comparison.differenceMm);
      output[voltaSegment.endIndex] = {
        idaDifferenceMm: comparison.differenceMm,
        accumulatedMm: accumulatedKnown ? accumulatedMm : null,
        toleranceMm: comparison.toleranceMm,
        status: comparison.status,
        progressivePointMatch: false
      };
    }
    return output;
  }

  function closure(idaRun, voltaRun, criteria) {
    if (!idaRun.rows.length || !voltaRun.rows.length) return { status: "—", reason: "IDA ou VOLTA vazia" };
    if (!idaRun.complete || !voltaRun.complete) return { status: "—", reason: "IDA ou VOLTA incompleta" };
    if (!idaRun.valid || !voltaRun.valid) return { status: "ERRO", reason: "Há leituras inválidas" };
    const sameEndpoints = sameName(idaRun.start, voltaRun.end) && sameName(idaRun.end, voltaRun.start);
    if (!sameEndpoints) return { status: "ERRO", reason: "Os extremos da IDA e da VOLTA não são inversos" };
    const errorMm = idaRun.deltaMm + voltaRun.deltaMm;
    const meanDistanceM = (idaRun.distanceM + voltaRun.distanceM) / 2;
    const toleranceMm = toleranceForDistance(meanDistanceM, criteria);
    return {
      status: withinStrictTolerance(errorMm, toleranceMm) ? "OK" : "ERRO",
      errorMm: round(errorMm),
      toleranceMm: round(toleranceMm),
      meanDistanceM: round(meanDistanceM),
      idaDeltaMm: idaRun.deltaMm,
      voltaDeltaMm: voltaRun.deltaMm
    };
  }

  function permanentSegments(run) {
    const paths = [];
    let startIndex = null;
    for (let i = 0; i < run.rows.length; i += 1) {
      const row = run.rows[i];
      if (startIndex === null && row.from && !isTemporaryPoint(row.from)) startIndex = i;
      if (startIndex !== null && row.to && !isTemporaryPoint(row.to)) {
        const parts = run.rows.slice(startIndex, i + 1);
        const continuous = parts.slice(1).every((item, offset) => sameName(parts[offset].to, item.from));
        paths.push({
          start: parts[0].from,
          end: parts[parts.length - 1].to,
          startIndex,
          endIndex: i,
          complete: continuous && parts.every((item) => item.complete),
          valid: continuous && parts.every((item) => item.valid),
          deltaMm: continuous && parts.every((item) => item.valid) ? round(parts.reduce((sum, item) => sum + item.deltaMm, 0)) : null,
          distanceM: parts.every((item) => item.distanceM !== null) ? round(parts.reduce((sum, item) => sum + item.distanceM, 0)) : null
        });
        startIndex = i + 1 < run.rows.length && sameName(row.to, run.rows[i + 1].from) ? i + 1 : null;
      }
    }
    return paths;
  }

  function buildScheme(project, idaRun, voltaRun) {
    const result = { valid: false, errors: [], warnings: [], points: [], levels: [], relationships: [] };
    const principal = cleanName(project && project.scheme && project.scheme.principalPoint);
    const rulerTopM = parseNumber(project && project.scheme && project.scheme.rulerTopM);
    const inputMode = project && project.scheme ? project.scheme.inputMode : "principalElevation";
    let principalElevationM = parseNumber(project && project.scheme && project.scheme.principalElevationM);
    const stationNrCmInput = parseNumber(project && project.scheme && project.scheme.stationNrCm);
    let stationNrM = stationNrCmInput === null ? null : stationNrCmInput / 100;
    if (!principal) result.errors.push("Selecione a RN principal.");
    if (rulerTopM === null || rulerTopM < 0) result.errors.push("Informe o topo da régua adotado.");
    if (inputMode === "stationNr") {
      if (stationNrM === null || stationNrM < 0) result.errors.push("Informe o NR da estação.");
    } else if (principalElevationM === null) {
      result.errors.push("Informe a cota da RN principal em relação ao NR.");
    }
    if (!idaRun.rows.length || !idaRun.continuous) result.errors.push("A IDA precisa formar um caminhamento contínuo para gerar o esquema.");
    const idaSegments = permanentSegments(idaRun);
    if (!idaSegments.length) result.errors.push("Não há relações completas entre pontos permanentes na IDA.");
    const corrected = [];
    for (const segment of idaSegments) {
      if (!segment.valid) {
        result.errors.push(`Trecho ${segment.start} → ${segment.end} inválido.`);
        continue;
      }
      const back = findPath(voltaRun, segment.start, segment.end);
      let deltaMm = segment.deltaMm;
      if (back && back.valid) deltaMm = (segment.deltaMm + back.deltaMm) / 2;
      else result.warnings.push(`Trecho ${segment.start} → ${segment.end} sem contranivelamento válido; foi usado o valor da IDA.`);
      corrected.push(Object.assign({}, segment, { correctedDeltaMm: round(deltaMm), voltaPath: back }));
    }
    if (result.errors.length) return result;

    const relative = new Map();
    const labels = new Map();
    const order = [];
    const firstKey = normName(corrected[0].start);
    relative.set(firstKey, 0);
    labels.set(firstKey, corrected[0].start);
    order.push(firstKey);
    for (const segment of corrected) {
      const a = normName(segment.start);
      const b = normName(segment.end);
      if (!relative.has(a)) {
        result.errors.push(`Não foi possível encadear o ponto ${segment.start}.`);
        break;
      }
      const next = relative.get(a) + segment.correctedDeltaMm / 1000;
      if (relative.has(b) && Math.abs(relative.get(b) - next) > 0.0005) {
        result.errors.push(`O ponto ${segment.end} recebeu cotas incompatíveis.`);
        break;
      }
      relative.set(b, next);
      labels.set(b, segment.end);
      if (!order.includes(b)) order.push(b);
    }
    const principalKey = normName(principal);
    const rulerKeys = order.filter((key) => isRulerPoint(labels.get(key)));
    const rulerKey = rulerKeys[0];
    if (!relative.has(principalKey)) result.errors.push("A RN principal não aparece no caminhamento da IDA.");
    if (!rulerKey) result.errors.push("Nenhum ponto identificado como Régua aparece no caminhamento.");
    if (rulerKeys.length > 1) result.errors.push("Há mais de um ponto identificado como Régua no caminhamento.");
    if (result.errors.length) return result;

    const deltaPrincipalRulerM = relative.get(rulerKey) - relative.get(principalKey);
    if (inputMode === "stationNr") {
      principalElevationM = rulerTopM - stationNrM - deltaPrincipalRulerM;
    } else {
      stationNrM = rulerTopM - principalElevationM - deltaPrincipalRulerM;
      if (stationNrM < -1e-6) result.errors.push("O NR calculado ficou negativo. Confira os dados do esquema.");
      else if (stationNrM < 0) stationNrM = 0;
    }
    if (result.errors.length) return result;

    const shift = principalElevationM - relative.get(principalKey);
    result.points = order
      .filter((key) => !isTemporaryPoint(labels.get(key)))
      .map((key, index) => ({
        name: labels.get(key),
        elevationM: round(relative.get(key) + shift, 6),
        relativeM: round(relative.get(key) - relative.get(principalKey), 6),
        order: index,
        isPrincipal: key === principalKey,
        isRuler: key === rulerKey
      }));
    result.levels = result.points.slice().sort((a, b) => b.elevationM - a.elevationM || a.name.localeCompare(b.name, "pt-BR"));
    for (let i = 0; i < result.levels.length - 1; i += 1) {
      result.relationships.push({
        high: result.levels[i].name,
        low: result.levels[i + 1].name,
        differenceCm: round(Math.abs(result.levels[i].elevationM - result.levels[i + 1].elevationM) * 100, 2)
      });
    }
    result.valid = true;
    result.principal = principal;
    result.principalElevationM = round(principalElevationM, 6);
    result.stationNrM = round(stationNrM, 6);
    result.stationNrCm = round(stationNrM * 100, 4);
    result.rulerTopM = rulerTopM;
    result.deltaPrincipalRulerM = round(deltaPrincipalRulerM, 6);
    result.principalToRulerCm = round(Math.abs(deltaPrincipalRulerM) * 100, 2);
    result.principalToNrCm = round(Math.abs(principalElevationM) * 100, 2);
    result.principalToZeroCm = round(Math.abs(stationNrM + principalElevationM) * 100, 2);
    result.nrToZeroCm = round(Math.abs(stationNrM) * 100, 2);
    return result;
  }

  function calculateProject(project) {
    const criteria = resolveCriteria(project);
    const ida = calculateRun(project && project.ida ? project.ida.lances : [], criteria);
    const volta = calculateRun(project && project.volta ? project.volta.lances : [], criteria);
    const station = project && project.station ? project.station : {};
    const checkReferences = Array.isArray(station.checkReferences) ? station.checkReferences : station.references;
    const voltaIndicators = annotateVolta(ida, volta, checkReferences || [], criteria);
    const voltaProgress = progressiveVolta(ida, volta, voltaIndicators, criteria);
    const closing = closure(ida, volta, criteria);
    const scheme = buildScheme(project || {}, ida, volta);
    const patternStates = voltaIndicators.map((item) => item.standard.status).filter((status) => status !== "—");
    return {
      ida,
      volta,
      voltaIndicators,
      voltaProgress,
      closure: closing,
      scheme,
      criteria,
      patternOk: patternStates.filter((status) => status === "OK").length,
      patternErrors: patternStates.filter((status) => status === "ERRO").length
    };
  }

  const api = {
    LIMITS,
    DEFAULT_CRITERIA,
    cleanName,
    normName,
    sameName,
    isTemporaryPoint,
    isRulerPoint,
    parseNumber,
    round,
    resolveCriteria,
    calculateReading,
    calculateLance,
    canAutoAdvanceAfterVanteCentral,
    calculateRun,
    buildPathsEndingAt,
    allPaths,
    findPath,
    expectedForReference,
    toleranceForDistance,
    withinStrictTolerance,
    findPermanentSegmentPair,
    comparePermanentSegment,
    annotateVolta,
    progressiveVolta,
    closure,
    permanentSegments,
    buildScheme,
    calculateProject
  };

  root.C32Calc = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
