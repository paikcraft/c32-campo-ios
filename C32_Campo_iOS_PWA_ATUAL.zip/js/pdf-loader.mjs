import * as pdfjsLib from "./vendor/pdfjs/pdf.min.mjs";

const workerUrl = new URL("./vendor/pdfjs/pdf.worker.min.mjs", import.meta.url);
pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl.href;
window.pdfjsLib = pdfjsLib;
window.C32PdfWorkerUrl = workerUrl.href;
window.dispatchEvent(new CustomEvent("c32-pdf-ready"));
