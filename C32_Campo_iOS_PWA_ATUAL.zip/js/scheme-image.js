(function (root) {
  "use strict";

  const WIDTH = 2048;
  const HEIGHT = 1299;
  const BASE_LEVEL_COUNT = 5;
  const EXTRA_LEVEL_HEIGHT = 130;
  const EPSILON = 1e-7;

  function xml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }

  function decimal(value, digits) {
    const number = Number(value);
    if (!Number.isFinite(number)) return "—";
    const parts = number.toFixed(digits == null ? 2 : digits).split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return parts.length > 1 ? `${parts[0]},${parts[1]}` : parts[0];
  }

  function sameName(a, b) {
    if (root.C32Calc && typeof root.C32Calc.sameName === "function") return root.C32Calc.sameName(a, b);
    const normalized = (value) => String(value == null ? "" : value).trim().toUpperCase();
    return normalized(a) !== "" && normalized(a) === normalized(b);
  }

  function observationLines(text, maxLength) {
    const words = String(text || "").trim().split(/\s+/).filter(Boolean);
    const lines = [];
    let line = "";
    for (const word of words) {
      const candidate = line ? `${line} ${word}` : word;
      if (candidate.length > maxLength && line) {
        lines.push(line);
        line = word;
      } else line = candidate;
    }
    if (line) lines.push(line);
    return lines.slice(0, 4);
  }

  function fitFontSize(text, preferred, threshold, minimum) {
    const extra = Math.max(0, String(text || "").length - threshold);
    return Math.max(minimum, preferred - (extra * 0.7));
  }

  function pointElevation(point) {
    const value = Number(point && point.elevationM);
    return Number.isFinite(value) ? value : null;
  }

  function differenceCm(first, second) {
    const firstElevation = pointElevation(first);
    const secondElevation = pointElevation(second);
    if (firstElevation === null || secondElevation === null) return null;
    return Math.abs(firstElevation - secondElevation) * 100;
  }

  function buildSchemeLayout(project, scheme) {
    if (!scheme || !scheme.valid) throw new Error("O esquema precisa estar válido para gerar a imagem.");
    const inputLevels = Array.isArray(scheme.levels) ? scheme.levels : [];
    const orderedLevels = inputLevels
      .map((point, index) => ({ point, index, elevationM: pointElevation(point) }))
      .filter((item) => item.elevationM !== null)
      .sort((a, b) => b.elevationM - a.elevationM || a.index - b.index)
      .map((item) => item.point);
    const rnLevels = orderedLevels.filter((point) => !point.isRuler);
    const ruler = orderedLevels.find((point) => point.isRuler);
    if (!rnLevels.length || !ruler) throw new Error("O esquema precisa conter RN e topo da régua.");

    const principal = rnLevels.find((point) => point.isPrincipal || sameName(point.name, scheme.principal));
    if (!principal) throw new Error("A RN principal não foi encontrada no esquema.");

    const stationName = project && project.station && project.station.name
      ? String(project.station.name).trim().toLocaleUpperCase("pt-BR")
      : "ESTAÇÃO";
    const title = `ESQUEMA DE COTAS (${stationName})`;
    const canvasHeight = HEIGHT + (Math.max(0, orderedLevels.length - BASE_LEVEL_COUNT) * EXTRA_LEVEL_HEIGHT);
    const topLimit = 220;
    const bottomLimit = canvasHeight - 469;
    const preferredStep = 190;
    const step = orderedLevels.length > 1
      ? Math.min(preferredStep, (bottomLimit - topLimit) / (orderedLevels.length - 1))
      : 0;
    const usedHeight = step * Math.max(0, orderedLevels.length - 1);
    const startY = topLimit + ((bottomLimit - topLimit - usedHeight) / 2);
    const placedLevels = orderedLevels.map((point, index) => ({
      point,
      y: startY + (index * step),
      elevationM: pointElevation(point)
    }));
    const rnPlaced = placedLevels.filter((item) => !item.point.isRuler);
    const rulerPlaced = placedLevels.find((item) => item.point.isRuler);
    const principalPlaced = rnPlaced.find((item) => item.point === principal);
    const mainRelations = [];
    for (let index = 0; index < rnPlaced.length - 1; index += 1) {
      const high = rnPlaced[index];
      const low = rnPlaced[index + 1];
      const rulerBetween = rulerPlaced.y > high.y + EPSILON && rulerPlaced.y < low.y - EPSILON;
      mainRelations.push({ high, low, differenceCm: differenceCm(high.point, low.point), rulerBetween });
    }

    const rulerIndex = placedLevels.indexOf(rulerPlaced);
    const upperRn = placedLevels.slice(0, rulerIndex).filter((item) => !item.point.isRuler).pop() || null;
    const lowerRn = placedLevels.slice(rulerIndex + 1).find((item) => !item.point.isRuler) || null;
    const rulerRelations = [];
    if (upperRn) rulerRelations.push({ other: upperRn, differenceCm: differenceCm(upperRn.point, ruler) });
    if (lowerRn) rulerRelations.push({ other: lowerRn, differenceCm: differenceCm(ruler, lowerRn.point) });

    return {
      width: WIDTH,
      height: canvasHeight,
      stationName,
      title,
      orderedLevels: placedLevels,
      rnLevels: rnPlaced,
      ruler: rulerPlaced,
      principal: principalPlaced,
      mainRelations,
      rulerRelations,
      zeroY: canvasHeight - 159,
      nrY: canvasHeight - 244
    };
  }

  function buildSvg(project, scheme) {
    const layout = buildSchemeLayout(project, scheme);
    const schemeInput = project && project.scheme ? project.scheme : {};
    const observation = schemeInput.rulerObservation
      || `A mira foi colocada no topo da régua fluviométrica de ${decimal(scheme.rulerTopM, 2)} m.`;
    const rotatedLines = observationLines(observation, 37);
    const frameRight = WIDTH - 76;
    const rnLineStart = 90;
    const rnLineEnd = 545;
    const rnChainX = 440;
    const principalLineEnd = frameRight;
    const rulerBracketX = 640;
    const rulerTopX = 725;
    const rulerBendX = 1068;
    const rulerVerticalX = 985;
    const rulerBoxX = 1075;
    const rulerBoxWidth = 165;
    const principalZeroX = 1340;
    const principalNrX = 1600;
    const nrLineStart = 1410;
    const zeroLineStart = rulerBoxX + rulerBoxWidth;

    const rnParts = layout.rnLevels.map((item) => {
      const name = String(item.point.name || "");
      const lineEnd = item.point === layout.principal.point ? principalLineEnd : rnLineEnd;
      return [
        `<text x="${rnLineStart + 3}" y="${item.y - 18}" font-size="${fitFontSize(name, 32, 20, 22)}" font-weight="700">${xml(name)}</text>`,
        `<line x1="${rnLineStart}" y1="${item.y}" x2="${lineEnd}" y2="${item.y}" stroke="#111820" stroke-width="3"/>`
      ].join("\n  ");
    }).join("\n  ");

    const chainParts = [];
    if (layout.rnLevels.length > 1) {
      chainParts.push(`<line x1="${rnChainX}" y1="${layout.rnLevels[0].y}" x2="${rnChainX}" y2="${layout.rnLevels[layout.rnLevels.length - 1].y}" stroke="#111820" stroke-width="2.5"/>`);
    }
    for (const relation of layout.mainRelations) {
      const labelX = relation.rulerBetween ? 300 : 505;
      const labelY = (relation.high.y + relation.low.y) / 2 + 9;
      chainParts.push(`<text x="${labelX}" y="${labelY}" text-anchor="middle" font-size="27">${xml(`${decimal(relation.differenceCm, 2)} cm`)}</text>`);
    }

    const rulerRelationParts = [];
    if (layout.rulerRelations.length) {
      const endpoints = [layout.ruler.y, ...layout.rulerRelations.map((relation) => relation.other.y)];
      const topY = Math.min(...endpoints);
      const bottomY = Math.max(...endpoints);
      rulerRelationParts.push(`<line x1="${rulerBracketX}" y1="${topY}" x2="${rulerBracketX}" y2="${bottomY}" stroke="#111820" stroke-width="2.5"/>`);
      for (const y of Array.from(new Set(endpoints.map((value) => String(value)))).map(Number)) {
        rulerRelationParts.push(`<line x1="${rulerBracketX - 13}" y1="${y}" x2="${rulerBracketX + 13}" y2="${y}" stroke="#111820" stroke-width="2.5"/>`);
      }
      for (const relation of layout.rulerRelations) {
        const labelY = (layout.ruler.y + relation.other.y) / 2 + 9;
        rulerRelationParts.push(`<text x="${rulerBracketX + 28}" y="${labelY}" font-size="26">${xml(`${decimal(relation.differenceCm, 2)} cm`)}</text>`);
      }
    }

    const rotatedText = rotatedLines.map((line, index) => {
      const start = -((rotatedLines.length - 1) * 12);
      return `<text x="0" y="${start + (index * 24)}" text-anchor="middle" font-size="18" font-weight="600">${xml(line)}</text>`;
    }).join("");
    const titleSize = fitFontSize(layout.title, 49, 42, 34);
    const canvasHeight = layout.height;
    const principalY = layout.principal.y;
    const rulerY = layout.ruler.y;
    const zeroY = layout.zeroY;
    const nrY = layout.nrY;

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${WIDTH}" height="${canvasHeight}" viewBox="0 0 ${WIDTH} ${canvasHeight}" font-family="Arial, Liberation Sans, sans-serif" shape-rendering="geometricPrecision">
  <rect width="${WIDTH}" height="${canvasHeight}" fill="#ffffff"/>
  <rect x="1.5" y="1.5" width="${WIDTH - 3}" height="${canvasHeight - 3}" fill="none" stroke="#111820" stroke-width="3"/>
  <text x="${WIDTH / 2}" y="101" text-anchor="middle" font-size="${titleSize}" font-weight="700">${xml(layout.title)}</text>
  ${rnParts}
  ${chainParts.join("\n  ")}
  ${rulerRelationParts.join("\n  ")}
  <text x="${rulerTopX}" y="${rulerY - 42}" font-size="29" font-weight="700">Topo da régua</text>
  <rect x="${rulerTopX}" y="${rulerY - 22}" width="${rulerBendX - rulerTopX}" height="45" fill="#929292"/>
  <rect x="${rulerVerticalX}" y="${rulerY - 22}" width="${rulerBendX - rulerVerticalX}" height="${zeroY - rulerY + 22}" fill="#929292"/>
  <rect x="${rulerBoxX}" y="${rulerY}" width="${rulerBoxWidth}" height="${zeroY - rulerY}" fill="#ffffff" stroke="#111820" stroke-width="2.5"/>
  <g transform="translate(${rulerBoxX + (rulerBoxWidth / 2)} ${(rulerY + zeroY) / 2}) rotate(-90)">${rotatedText}</g>
  <text x="${rulerBoxX + (rulerBoxWidth / 2)}" y="${zeroY - 17}" text-anchor="middle" font-size="40">0</text>
  <line x1="${principalZeroX}" y1="${principalY}" x2="${principalZeroX}" y2="${zeroY}" stroke="#111820" stroke-width="2.5"/>
  <text x="${principalZeroX + 30}" y="${(principalY + zeroY) / 2 + 9}" font-size="29">${xml(`${decimal(scheme.principalToZeroCm, 2)} cm`)}</text>
  <line x1="${principalNrX}" y1="${principalY}" x2="${principalNrX}" y2="${nrY}" stroke="#111820" stroke-width="2.5"/>
  <text x="${principalNrX + 30}" y="${(principalY + nrY) / 2 + 9}" font-size="29">${xml(`${decimal(scheme.principalToNrCm, 2)} cm`)}</text>
  <line x1="${nrLineStart}" y1="${nrY}" x2="${frameRight}" y2="${nrY}" stroke="#111820" stroke-width="3"/>
  <text x="${frameRight - 18}" y="${nrY - 20}" text-anchor="end" font-size="31" font-weight="700">NR</text>
  <line x1="1795" y1="${nrY}" x2="1795" y2="${zeroY}" stroke="#111820" stroke-width="2.5"/>
  <text x="1824" y="${(nrY + zeroY) / 2 + 9}" font-size="27">${xml(`${decimal(scheme.nrToZeroCm, 2)} cm`)}</text>
  <line x1="${zeroLineStart}" y1="${zeroY}" x2="${frameRight}" y2="${zeroY}" stroke="#111820" stroke-width="3"/>
  <text x="${frameRight - 18}" y="${zeroY + 44}" text-anchor="end" font-size="31" font-weight="700">Zero da régua</text>
  <text x="${WIDTH / 2}" y="${canvasHeight - 33}" text-anchor="middle" font-size="23" fill="#506171">2ºSG-HN Soares · CHN-9 / 2026</text>
</svg>`;
    return { svg, width: WIDTH, height: canvasHeight, layout };
  }

  function decodePngDataUrl(dataUrl) {
    const base64 = String(dataUrl || "").split(",")[1];
    if (!base64) throw new Error("O Android não conseguiu rasterizar o esquema.");
    if (root.C32Native && typeof root.C32Native.base64ToBytes === "function") {
      return root.C32Native.base64ToBytes(base64);
    }
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function svgDataUrl(svg) {
    if (root.C32Native && typeof root.C32Native.textToBase64 === "function") {
      return `data:image/svg+xml;base64,${root.C32Native.textToBase64(svg)}`;
    }
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  }

  function generatePng(project, scheme, options) {
    const documentData = buildSvg(project, scheme);
    const targetWidth = options && Number.isFinite(Number(options.width)) ? Math.max(1, Math.round(Number(options.width))) : documentData.width;
    const targetHeight = options && Number.isFinite(Number(options.height)) ? Math.max(1, Math.round(Number(options.height))) : documentData.height;
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        try {
          const canvas = document.createElement("canvas");
          canvas.width = targetWidth;
          canvas.height = targetHeight;
          const context = canvas.getContext("2d");
          if (!context) throw new Error("O dispositivo não disponibilizou a área de desenho.");
          context.fillStyle = "#ffffff";
          context.fillRect(0, 0, canvas.width, canvas.height);
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          resolve(decodePngDataUrl(canvas.toDataURL("image/png")));
        } catch (error) {
          reject(error);
        }
      };
      image.onerror = () => reject(new Error("Não foi possível montar a imagem do esquema."));
      image.src = svgDataUrl(documentData.svg);
    });
  }

  const api = { WIDTH, HEIGHT, decimal, buildSchemeLayout, buildSvg, generatePng };
  root.C32SchemeImage = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
