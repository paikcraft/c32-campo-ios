(function (root) {
  "use strict";

  const db = root.C32StationDb;
  const overlay = document.getElementById("v2-overlay");
  const fileInput = document.getElementById("v2-file-input");
  const activeStatuses = new Set(["normal", "new"]);
  const state = {
    view: "menu",
    back: "menu",
    busy: false,
    progress: null,
    stations: [],
    searchMode: "name",
    query: "",
    station: null,
    f43: [],
    levelings: [],
    stationViewSelection: null,
    interpretation: null,
    editingF43Id: null,
    editingF43RecordType: null,
    editingStationId: null,
    pendingF43Records: null,
    pendingFilePurpose: "",
    basePlan: null,
    baseResolutions: null,
    preparation: null,
    pendingCurrentRecord: null
  };

  function esc(value) {
    return String(value == null ? "" : value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }

  function normal(value) {
    return db.normalize(value);
  }

  function formatDate(value) {
    if (!value) return "Data não informada";
    const text = String(value);
    const iso = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) return `${iso[3]}/${iso[2]}/${iso[1]}`;
    return text;
  }

  function numberValue(value) {
    if (root.C32F43Parser && root.C32F43Parser.decimal) return root.C32F43Parser.decimal(value);
    const number = Number(String(value == null ? "" : value).replace(",", "."));
    return Number.isFinite(number) ? number : null;
  }

  function formatMeasure(value, unit) {
    const number = numberValue(value);
    if (number === null) return "--";
    return `${number.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${unit}`;
  }

  function stationViewRecord(current, historical, levelings, proposals, requested) {
    const choice = (record, recordType, category, label) => record ? { record, recordType, category, label } : null;
    const currentChoice = choice(current, "f43", "current", current && `F-43 Padrão vigente · ${current.sourceFileName || current.code || "registro atual"}`);
    const historicalChoices = historical.map((record) => choice(record, "f43", "historical", `F-43 Padrão anterior · ${record.sourceFileName || record.code || "registro histórico"}`));
    const levelingChoices = levelings.map((record) => choice(record, "leveling", "leveling", `Nivelamento · ${record.sourceFileName || formatDate(record.dateKey || record.date)}`));
    const proposalChoices = proposals.map((record) => choice(record, "leveling", "proposal", `Ficha / proposta de atualização · ${record.sourceFileName || formatDate(record.dateKey || record.date)}`));
    const choices = [currentChoice, ...historicalChoices, ...levelingChoices, ...proposalChoices].filter(Boolean);
    const selected = requested && choices.find((item) => item.recordType === requested.recordType && String(item.record.id) === String(requested.id));
    return selected || currentChoice || proposalChoices[0] || levelingChoices[0] || historicalChoices[0] || null;
  }

  function stationSchemeFromRecord(record) {
    if (!record) return null;
    const stored = record.stationScheme || (record.diagram && record.diagram.stationScheme);
    if (stored && Array.isArray(stored.nodes) && stored.nodes.length) return stored;
    const references = Array.isArray(record.references) ? record.references.slice() : [];
    if (!references.length) return null;
    const allElevations = references.every((item) => numberValue(item.elevationM) !== null);
    references.sort((a, b) => allElevations
      ? numberValue(b.elevationM) - numberValue(a.elevationM)
      : Number(a.verticalOrder == null ? a.order == null ? 9999 : a.order : a.verticalOrder) - Number(b.verticalOrder == null ? b.order == null ? 9999 : b.order : b.verticalOrder));
    const nodes = references.map((item, index) => ({ key: `rn:${normal(item.name)}:${index}`, type: "rn", name: item.name, elevationM: item.elevationM }));
    const relationships = record.relationships || (record.diagram && record.diagram.relationships) || [];
    const links = [];
    for (let index = 0; index < nodes.length - 1; index += 1) {
      const high = nodes[index]; const low = nodes[index + 1];
      const relation = relationships.find((item) => (normal(item.high) === normal(high.name) && normal(item.low) === normal(low.name))
        || (normal(item.low) === normal(high.name) && normal(item.high) === normal(low.name)));
      if (relation) {
        const differenceCm = numberValue(relation.differenceCm);
        const differenceM = numberValue(relation.differenceM);
        if (differenceCm !== null || differenceM !== null) links.push({ from: high.key, to: low.key, differenceCm: differenceCm !== null ? differenceCm : differenceM * 100 });
      }
    }
    const rulerTopM = numberValue(record.rulerTopM != null ? record.rulerTopM : record.diagram && record.diagram.rulerTopM);
    if (rulerTopM !== null) nodes.push({ key: "ruler-top", type: "ruler", name: "Topo da régua", rulerTopM });
    return { nodes, links, rulerTopM };
  }

  function stationSchemeCard(selection) {
    if (!selection) return `<details class="card v2-station-view" open><summary>VISÃO RÁPIDA DA ESTAÇÃO</summary><div class="v2-details-body notice"><strong>Ainda não há esquema disponível.</strong><p class="subtle">Importe uma F-43 ou salve um nivelamento para visualizar as RNs e cotas.</p></div></details>`;
    const record = selection.record;
    const scheme = stationSchemeFromRecord(record);
    const principal = record.principalRn || (record.diagram && record.diagram.principalRn) || ((record.references || []).find((item) => item.isPrincipal) || {}).name || "";
    const linksByPair = new Map((scheme && scheme.links || []).map((item) => [`${item.from}|${item.to}`, item]));
    const graph = scheme && scheme.nodes.length ? scheme.nodes.map((node, index) => {
      const isPrincipal = node.type === "rn" && normal(node.name) === normal(principal);
      const next = scheme.nodes[index + 1];
      const link = next ? linksByPair.get(`${node.key}|${next.key}`) : null;
      const nodeLabel = node.type === "ruler"
        ? `<strong>Topo da régua</strong><small>Altura adotada: ${formatMeasure(node.rulerTopM != null ? node.rulerTopM : scheme.rulerTopM, "m")}</small>`
        : `<strong>${esc(node.name)}</strong>${isPrincipal ? `<span>RN Principal</span>` : ""}${numberValue(node.elevationM) !== null ? `<small>Cota: ${formatMeasure(node.elevationM, "m")}</small>` : ""}`;
      const connector = next ? `<div class="v2-scheme-link"><i></i><strong>${link && numberValue(link.differenceCm) !== null ? formatMeasure(link.differenceCm, "cm") : "cota não informada"}</strong><small>entre os pontos</small></div>` : "";
      return `<div class="v2-scheme-node ${node.type === "ruler" ? "ruler" : ""} ${isPrincipal ? "principal" : ""}">${nodeLabel}</div>${connector}`;
    }).join("") : `<p class="subtle">As referências estão cadastradas, mas este registro não possui ordem gráfica suficiente.</p>`;
    const diagram = record.diagram || record;
    const rulerDescription = record.rulerDescription || (record.descriptions && record.descriptions.ruler) || record.rulerObservation || "";
    return `<details class="card v2-station-view" open><summary>VISÃO RÁPIDA DA ESTAÇÃO</summary><div class="v2-details-body"><p class="v2-view-source"><strong>Exibindo:</strong> ${esc(selection.label)}</p><p class="subtle">Cada valor aparece entre os dois pontos que ele liga. Para trocar esta visualização, toque em <strong>VER</strong> no registro desejado nas listas abaixo.</p><div class="v2-station-scheme">${graph}</div><dl class="v2-defs v2-station-values"><dt>RN Principal</dt><dd>${esc(principal || "--")}</dd><dt>RN Principal → NR</dt><dd>${formatMeasure(record.principalToNrCm != null ? record.principalToNrCm : diagram.principalToNrConfirmedCm, "cm")}</dd><dt>NR → Zero da régua</dt><dd>${formatMeasure(record.nrToZeroCm != null ? record.nrToZeroCm : diagram.nrToZeroCm, "cm")}</dd><dt>RN Principal → Zero</dt><dd>${formatMeasure(record.principalToZeroCm != null ? record.principalToZeroCm : (diagram.principalToZeroConfirmedCm != null ? diagram.principalToZeroConfirmedCm : diagram.principalToZeroCalculatedCm), "cm")}</dd><dt>Topo da régua</dt><dd>${formatMeasure(record.rulerTopM != null ? record.rulerTopM : diagram.rulerTopM, "m")}</dd>${rulerDescription ? `<dt>Régua</dt><dd>${esc(rulerDescription)}</dd>` : ""}</dl></div></details>`;
  }

  function toast(message, type) {
    if (root.C32App && root.C32App.showToast) return root.C32App.showToast(message, type);
    root.alert(message);
  }

  function getPath(object, path) {
    return String(path).split(".").reduce((value, key) => value == null ? undefined : value[key], object);
  }

  function setPath(object, path, value) {
    const parts = String(path).split(".");
    const last = parts.pop();
    const target = parts.reduce((current, key) => current[key], object);
    target[last] = value;
  }

  function open(view, back, options) {
    const config = options || {};
    state.view = view || "menu";
    state.back = back || (view === "menu" ? "" : "menu");
    overlay.hidden = false;
    document.body.classList.add("v2-open");
    if (root.C32Native && typeof root.C32Native.setLevelingActive === "function") root.C32Native.setLevelingActive(false);
    if (!config.fromHistory && root.history && typeof root.history.pushState === "function") {
      root.history.pushState({ c32: true, screen: root.C32App?.state?.screen || "home", c32Overlay: true, view: state.view, back: state.back, depth: Number(root.history.state?.depth || 0) + 1 }, "");
    }
    render();
  }

  function close(options) {
    const config = options || {};
    const wasOpen = !overlay.hidden;
    overlay.hidden = true;
    document.body.classList.remove("v2-open");
    if (wasOpen && !config.fromHistory && root.history && root.history.state && root.history.state.c32Overlay) root.history.back();
    if (root.C32App && typeof root.C32App.syncLevelingScreenState === "function") root.C32App.syncLevelingScreenState();
  }

  function handleBack() {
    if (overlay.hidden) return false;
    if (root.history && root.history.state && root.history.state.c32Overlay) root.history.back();
    else if (state.back) open(state.back, state.back === "menu" ? "" : "menu", { fromHistory: true });
    else close({ fromHistory: true });
    return true;
  }

  function applyHistoryState(snapshot) {
    if (snapshot && snapshot.c32Overlay) {
      open(snapshot.view || "menu", snapshot.back || "", { fromHistory: true });
      return true;
    }
    if (!overlay.hidden) {
      close({ fromHistory: true });
      return false;
    }
    return false;
  }

  function header(title, subtitle) {
    return `<header class="v2-header"><button class="v2-icon" data-v2-action="${state.back ? "back" : "close"}" aria-label="${state.back ? "Voltar" : "Fechar"}">${state.back ? "‹" : "×"}</button><div><strong>${esc(title)}</strong><small>${esc(subtitle || "C32 - Campo 2.1")}</small></div><button class="v2-icon" data-v2-action="close" aria-label="Fechar">×</button></header>`;
  }

  function frame(title, body, subtitle) {
    overlay.innerHTML = `<div class="v2-screen">${header(title, subtitle)}<main class="v2-content">${body}</main></div>`;
  }

  function menu() {
    frame("Menu", `<section class="card v2-intro"><h2>Banco e intercâmbio</h2><p class="subtle">As funções abaixo trabalham offline e não alteram o projeto C32 atual sem uma ação explícita.</p></section>
      <div class="v2-menu-grid">
        <button data-v2-action="bank"><strong>Banco de Estações</strong><small>Consultar por estação, rio ou localidade</small></button>
        <button data-v2-action="import-f43"><strong>Importar F-43</strong><small>PDF textual ou escaneado, com OCR local</small></button>
        <button data-v2-action="import-base"><strong>Importar Base .c32base</strong><small>Conferir integridade, duplicidades e conflitos</small></button>
        <button data-v2-action="export-base"><strong>Exportar Base</strong><small>Base inteira, estação ou nivelamento</small></button>
        <button data-v2-action="manual"><strong>Manual</strong><small>Uso do Banco, F-43, checks e backup</small></button>
        <button data-v2-action="backup-info"><strong>Backup e informações</strong><small>Orientações antes de atualizar ou desinstalar</small></button>
      </div>`);
  }

  async function loadStations() {
    state.stations = await db.searchStations(state.query, state.searchMode);
  }

  async function bank() {
    await loadStations();
    frame("Banco de Estações", `<section class="card v2-search"><div class="field"><label>Pesquisar</label><input id="v2-station-query" value="${esc(state.query)}" placeholder="Digite para localizar"></div><div class="v2-segmented">
        ${[["name", "Estação"], ["river", "Rio"], ["locality", "Localidade"]].map(([value, label]) => `<button data-v2-action="search-mode" data-mode="${value}" class="${state.searchMode === value ? "active" : ""}">${label}</button>`).join("")}
      </div><button class="secondary wide" data-v2-action="new-station">+ CADASTRAR ESTAÇÃO</button></section>
      <div class="stack">${state.stations.length ? state.stations.map((station) => `<button class="card v2-result" data-v2-action="station" data-id="${esc(station.id)}"><strong>${esc(station.name || "Estação sem nome")}</strong><span>${esc([station.river, station.locality, station.state].filter(Boolean).join(" · ") || "Sem dados complementares")}</span></button>`).join("") : `<section class="card notice"><strong>Banco vazio ou nenhum resultado</strong><p class="subtle">Importe uma F-43, uma base .c32base ou cadastre uma estação.</p></section>`}</div>`, "Consulta offline");
  }

  function stationForm() {
    frame("Cadastrar estação", `<section class="card form-grid">
      ${stationInput("Nome da estação", "name", true)}${stationInput("Rio", "river")}${stationInput("Localidade", "locality")}${stationInput("Município", "municipality")}${stationInput("UF/Estado", "state")}${stationInput("Código da estação", "stationCode")}${stationInput("Código ANA", "anaCode")}
      </section><button class="primary wide" data-v2-action="save-new-station">SALVAR ESTAÇÃO</button>`);
  }

  function stationInput(label, name, required) {
    return `<div class="field ${required ? "span-2" : ""}"><label>${esc(label)}</label><input data-new-station="${name}" ${required ? "required" : ""}></div>`;
  }

  async function loadStation(id) {
    if (!state.station || String(state.station.id) !== String(id)) state.stationViewSelection = null;
    state.station = await db.getStation(id);
    if (!state.station) throw new Error("Estação não encontrada.");
    state.f43 = (await db.listF43(id)).sort((a, b) => String(b.updateDate || b.year || "").localeCompare(String(a.updateDate || a.year || "")));
    state.levelings = (await db.listLevelings(id)).sort((a, b) => String(b.dateKey || b.date || "").localeCompare(String(a.dateKey || a.date || "")));
  }

  async function stationDetail(id) {
    if (id) await loadStation(id);
    const current = state.f43.find((item) => item.kind === "standard" && item.current === true);
    const historical = state.f43.filter((item) => item.kind === "standard" && item.current !== true);
    const levelings = state.levelings.filter((item) => item.kind !== "proposal");
    const proposals = state.levelings.filter((item) => item.kind === "proposal");
    const stationView = stationViewRecord(current, historical, levelings, proposals, state.stationViewSelection);
    state.stationViewSelection = stationView ? { recordType: stationView.recordType, id: stationView.record.id } : null;
    frame(state.station.name || "Estação", `<section class="card"><h2>Dados da estação</h2><dl class="v2-defs"><dt>Rio</dt><dd>${esc(state.station.river || "--")}</dd><dt>Localidade</dt><dd>${esc(state.station.locality || "--")}</dd><dt>Município</dt><dd>${esc(state.station.municipality || "--")}</dd><dt>UF</dt><dd>${esc(state.station.state || "--")}</dd></dl><div class="button-row"><button class="primary" data-v2-action="prepare-leveling">NOVO NIVELAMENTO</button><button class="secondary" data-v2-action="export-station" data-id="${esc(state.station.id)}">EXPORTAR ESTAÇÃO</button></div></section>
      ${stationSchemeCard(stationView)}
      ${bankGroup("F-43 PADRÃO VIGENTE", current ? [current] : [], "f43", stationView)}
      ${bankGroup("F-43 PADRÃO ANTERIORES", historical, "f43", stationView)}
      ${bankGroup("NIVELAMENTOS", levelings, "leveling", stationView)}
      ${bankGroup("FICHAS / PROPOSTAS DE ATUALIZAÇÃO", proposals, "leveling", stationView)}
      <button class="danger wide" data-v2-action="delete-station" data-id="${esc(state.station.id)}">EXCLUIR ESTAÇÃO E HISTÓRICO</button>`, "Consulta - não reabre o projeto operacional");
  }

  function bankGroup(title, items, type, stationView) {
    return `<details class="card v2-group" open><summary>${esc(title)} <span>${items.length}</span></summary><div class="stack">${items.length ? items.map((item) => {
      const dateLabel = `${formatDate(item.dateKey || item.date)}${item.displaySuffix ? ` ${item.displaySuffix}` : ""}`;
      const label = type === "f43" ? (item.sourceFileName || item.code || "F-43") : (item.sourceFileName || dateLabel);
      const detail = type === "f43" ? [item.year, item.lh].filter(Boolean).join(" · ") : `${item.kind === "proposal" ? "Ficha / Proposta de Atualização" : "Nivelamento"}${item.sourceFileName ? ` · ${dateLabel}` : ""}`;
      const viewing = stationView && stationView.recordType === type && String(stationView.record.id) === String(item.id);
      return `<article class="v2-bank-item ${viewing ? "viewing" : ""}" ${viewing ? `aria-current="true"` : ""}><div><strong>${esc(label)}</strong><small>${esc(detail)}</small></div><div class="v2-row-actions"><button class="mini-btn v2-view-btn ${viewing ? "active" : ""}" data-v2-action="view-bank-record" data-record-type="${esc(type)}" data-id="${esc(item.id)}" aria-pressed="${viewing ? "true" : "false"}" title="${viewing ? "Registro exibido na visão rápida" : "Ver este registro na visão rápida"}">${viewing ? "VENDO" : "VER"}</button>${type === "f43" ? `<button class="mini-btn" data-v2-action="start-reference-f43" data-id="${esc(item.id)}" title="Usar como referência">▶</button><button class="mini-btn" data-v2-action="edit-f43-record" data-record-type="f43" data-id="${esc(item.id)}" title="Editar F-43">✎</button>` : `${item.kind === "proposal" ? `<button class="mini-btn" data-v2-action="edit-f43-record" data-record-type="leveling" data-id="${esc(item.id)}" title="Editar ficha de atualização">✎</button>` : ""}<button class="mini-btn" data-v2-action="export-leveling" data-id="${esc(item.id)}" title="Exportar">⇩</button>`}<button class="mini-btn" data-v2-action="delete-${type}" data-id="${esc(item.id)}" title="Excluir">×</button></div></article>`;
    }).join("") : `<p class="subtle">Nenhum registro.</p>`}</div></details>`;
  }

  function chooseFile(purpose) {
    state.pendingFilePurpose = purpose;
    root.C32Native.openFile(handleNativeFile);
  }

  async function handleNativeFile(error, text, name, bytes) {
    if (error) return toast(error.message || "Não foi possível abrir o arquivo.", "error");
    try {
      const payload = bytes || new TextEncoder().encode(text || "");
      if (state.pendingFilePurpose === "f43") await importF43(payload, name);
      else if (state.pendingFilePurpose === "base") await importBase(payload);
    } catch (failure) {
      state.busy = false;
      toast(failure.message || "Falha na importação.", "error");
      open("menu");
    } finally {
      state.pendingFilePurpose = "";
    }
  }

  async function importF43(bytes, name) {
    state.busy = true;
    state.progress = { stage: "Lendo PDF…", detail: name, percent: 0 };
    open("progress", "menu");
    const interpretation = await root.C32F43Pdf.interpret(bytes, name, (value) => {
      state.progress = value;
      if (state.view === "progress") render();
    });
    state.busy = false;
    // v2.1.2: quando a ficha não traz município, reaproveitar somente um cadastro
    // inequivocamente correspondente já existente. O valor permanece editável.
    if (!String(interpretation.station.municipality.value || "").trim()) {
      const candidateStation = {
        name: interpretation.station.name.value || "", river: interpretation.station.river.value || "",
        locality: interpretation.station.locality.value || "", municipality: "", state: interpretation.station.state.value || "",
        stationCode: interpretation.station.stationCode.value || "", anaCode: interpretation.station.anaCode.value || ""
      };
      const known = await db.identifyStation(candidateStation);
      if (known.status === "exact" && known.candidates[0] && String(known.candidates[0].municipality || "").trim()) {
        interpretation.station.municipality.value = String(known.candidates[0].municipality).trim();
        interpretation.station.municipality.confidence = "green";
        interpretation.station.municipality.source = "station-bank";
        root.C32F43Parser.validate(interpretation);
      }
    }
    state.interpretation = interpretation;
    state.editingF43Id = null;
    state.editingF43RecordType = null;
    state.editingStationId = null;
    open("f43-review", "menu");
  }

  function progressView() {
    const info = state.progress || { stage: "Processando…", detail: "", percent: null };
    frame("Importar F-43", `<section class="card v2-progress"><span class="loading"></span><h2>${esc(info.stage)}</h2><p>${esc(info.detail || "Processamento totalmente offline")}</p>${info.percent == null ? "" : `<progress max="100" value="${Number(info.percent)}"></progress><small>${Number(info.percent)}%</small>`}</section>`, "Não feche o aplicativo");
  }

  function confidenceClass(field) {
    return `confidence-${field && field.confidence || "yellow"}`;
  }

  function reviewField(label, path, options) {
    const field = getPath(state.interpretation, path);
    const config = options || {};
    return `<div class="field v2-confidence ${confidenceClass(field)}"><label>${esc(label)}${field && field.essential ? " *" : ""}</label><input data-f43-field="${esc(path)}" value="${esc(field && field.value)}" ${config.inputmode ? `inputmode="${config.inputmode}"` : ""}></div>`;
  }

  function relationshipEditor(item, index) {
    const value = item && numberValue(item.differenceCm) !== null ? String(numberValue(item.differenceCm)).replace(".", ",") : "";
    const origin = item && item.source === "spatial-layout" ? (item.confidence === "high" ? "Reconhecida pela posição no croqui" : "Sugestão — confira") : item && item.source && item.source !== "manual" ? "Reconhecida automaticamente" : (value ? "Informada manualmente" : "Não reconhecida — preenchimento opcional");
    const confidence = value ? (item && item.confidence === "review" ? "yellow" : "green") : "yellow";
    return `<div class="field v2-confidence confidence-${confidence} v2-relationship-field"><label>${esc(item.high || "?")} → ${esc(item.low || "?")}</label><input data-f43-relationship="${index}" inputmode="decimal" value="${esc(value)}" placeholder="cm"><small>${esc(origin)}</small></div>`;
  }

  function f43Review() {
    const item = state.interpretation;
    root.C32F43Parser.validate(item);
    const editing = Boolean(state.editingF43Id);
    const summary = {
      station: item.station.name.value || "--",
      type: item.classification.value === "standard" ? "F-43 Padrão" : item.classification.value === "proposal" ? "F-43 de LH / Atualização" : "Não classificada",
      rns: item.references.length,
      corrections: item.corrections.length,
      pending: (item.reviewPending || []).length
    };
    const drafts = item.diagram.relationshipDrafts || [];
    const incomplete = (item.reviewPending || []).length > 0;
    frame(editing ? "Editar F-43" : "Conferir F-43", `<section class="card v2-legend"><span class="confidence-green">Verde: leitura clara/conferida</span><span class="confidence-yellow">Amarelo: revisar ou preencher se desejar</span><span class="confidence-red">Vermelho: classificação obrigatória</span></section>
      <details class="card" open><summary>IDENTIFICAÇÃO</summary><div class="form-grid v2-details-body"><div class="field v2-confidence confidence-${item.classification.confidence}"><label>Classificação *</label><select data-f43-classification ${editing ? "disabled" : ""}><option value="unknown" ${item.classification.value === "unknown" ? "selected" : ""}>Selecione</option><option value="standard" ${item.classification.value === "standard" ? "selected" : ""}>F-43 Padrão</option><option value="proposal" ${item.classification.value === "proposal" ? "selected" : ""}>F-43 de LH / Atualização</option></select><small>${esc(item.classification.reason)}</small></div>${reviewField("Estação", "station.name")}${reviewField("Rio", "station.river")}${reviewField("Localidade", "station.locality")}${reviewField("Município", "station.municipality")}${reviewField("UF", "station.state")}${reviewField("Código F-43", "identification.code")}${reviewField("LH", "identification.lh")}${reviewField("Carta", "identification.chart")}${reviewField("Ano", "identification.year")}${reviewField("Atualização", "identification.updateDate")}</div></details>
      <details class="card" open><summary>REFERÊNCIAS DE NÍVEL</summary><div class="v2-details-body"><div class="stack">${item.references.map((reference, index) => referenceEditor(reference, index)).join("") || `<p class="subtle">Nenhuma RN reconhecida. A ficha ainda pode ser salva para teste e completada depois.</p>`}</div><button class="secondary wide" data-v2-action="add-rn">+ ADICIONAR RN</button></div></details>
      <details class="card" open><summary>COTAS ENTRE REFERÊNCIAS</summary><div class="v2-details-body"><p class="subtle">Os campos seguem a ordem superior → inferior. Valores reconhecidos podem ser corrigidos; campos vazios não impedem salvar.</p><div class="form-grid v2-relationship-grid">${drafts.map(relationshipEditor).join("") || `<p class="subtle">Adicione/ordene pelo menos duas referências para cadastrar relações.</p>`}</div></div></details>
      <details class="card" open><summary>COTAS DA ESTAÇÃO</summary><div class="v2-details-body form-grid">${numericInput("RN Principal → NR (cabeçalho)", "diagram.principalToNrWrittenCm", item.diagram.principalToNrWrittenCm)}${numericInput("RN Principal → NR (diagrama)", "diagram.principalToNrDiagramCm", item.diagram.principalToNrDiagramCm)}${numericInput("RN Principal → NR confirmado", "diagram.principalToNrConfirmedCm", item.diagram.principalToNrConfirmedCm)}${numericInput("NR → Zero da Régua", "diagram.nrToZeroCm", item.diagram.nrToZeroCm)}${numericInput("RN Principal → Zero escrito", "diagram.principalToZeroWrittenCm", item.diagram.principalToZeroWrittenCm)}${numericInput("RN Principal → Zero calculado", "diagram.principalToZeroCalculatedCm", item.diagram.principalToZeroCalculatedCm, false, true)}</div>${item.inconsistencies.map(inconsistencyCard).join("")}</details>
      <details class="card"><summary>DADOS COMPLEMENTARES</summary><div class="v2-details-body form-grid">${reviewField("Latitude", "geographic.latitude")}${reviewField("Longitude", "geographic.longitude")}${reviewField("Datum", "geographic.datum")}${reviewField("Fuso", "geographic.zone")}${reviewField("Equipe", "administrative.team")}${reviewField("Chefe", "administrative.chief")}${reviewField("Fonte/método do NR", "nr.methodSource")}${reviewField("Período do NR", "nr.period")}</div></details>
      <section class="card v2-import-summary"><h3>${editing ? "Resumo antes de salvar" : "Resumo antes de importar"}</h3><dl class="v2-defs"><dt>Estação</dt><dd>${esc(summary.station)}</dd><dt>Tipo</dt><dd>${esc(summary.type)}</dd><dt>RN identificadas</dt><dd>${summary.rns}</dd><dt>Campos corrigidos</dt><dd>${summary.corrections}</dd><dt>Pendências informativas</dt><dd>${summary.pending}</dd></dl>${incomplete ? `<div class="notice warning"><strong>A ficha possui campos pendentes.</strong><ul>${(item.reviewPending || []).map((value) => `<li>${esc(value)}</li>`).join("")}</ul><p class="subtle">Isso não impede salvar. Você poderá editar a ficha posteriormente.</p></div>` : ""}${item.essentialPending.length ? `<div class="notice error"><strong>Para salvar, falta apenas:</strong><ul>${item.essentialPending.map((value) => `<li>${esc(value)}</li>`).join("")}</ul></div>` : ""}</section>
      <div class="v2-final-actions"><button class="secondary" data-v2-action="cancel-f43">CANCELAR</button><button class="primary" data-v2-action="confirm-f43" ${item.canImport ? "" : "disabled"}>${editing ? "SALVAR ALTERAÇÕES" : "CONFIRMAR E IMPORTAR"}</button></div>`, `${esc(item.sourceFileName)} · ${item.extraction.mode}`);
  }

  function numericInput(label, path, value, required, readonly) {
    return `<div class="field v2-confidence ${required && root.C32F43Parser.decimal(value) === null ? "confidence-red" : "confidence-green"}"><label>${esc(label)}${required ? " *" : ""}</label><input data-f43-number="${esc(path)}" inputmode="decimal" value="${value == null ? "" : esc(String(value).replace(".", ","))}" ${readonly ? "readonly" : ""}></div>`;
  }

  function referenceEditor(reference, index) {
    return `<article class="v2-rn confidence-${reference.confidence || "yellow"}"><label class="v2-principal"><input type="radio" name="principal-rn" data-v2-action="principal-rn" data-index="${index}" ${reference.isPrincipal ? "checked" : ""}> RN Principal</label><div class="field"><label>Nome exato</label><input data-rn-name="${index}" value="${esc(reference.name)}"></div><div class="field"><label>Descrição</label><textarea data-rn-description="${index}">${esc(reference.description || "")}</textarea></div><div class="v2-row-actions"><button class="mini-btn" data-v2-action="move-rn" data-index="${index}" data-direction="-1">↑</button><button class="mini-btn" data-v2-action="move-rn" data-index="${index}" data-direction="1">↓</button><button class="mini-btn" data-v2-action="delete-rn" data-index="${index}">×</button></div></article>`;
  }

  function inconsistencyCard(item) {
    return `<section class="notice error v2-conflict"><strong>${esc(item.title)}</strong><p>${item.labels.map((label, index) => `${esc(label)}: <b>${esc(String(item.values[index]).replace(".", ","))} cm</b>`).join(" · ")}</p><div class="button-row">${item.values.map((value, index) => `<button class="secondary" data-v2-action="resolve-inconsistency" data-id="${esc(item.id)}" data-value="${value}">Usar ${esc(String(value).replace(".", ","))}</button>`).join("")}</div><div class="field"><label>Ou digite outro valor</label><div class="v2-inline"><input data-inconsistency-custom="${esc(item.id)}" inputmode="decimal"><button class="secondary" data-v2-action="resolve-custom" data-id="${esc(item.id)}">APLICAR</button></div></div></section>`;
  }

  async function syncStationFromF43(station, incoming, options) {
    const config = options || {};
    const merged = Object.assign({}, station || {});
    for (const key of ["name","river","locality","municipality","state","stationCode","anaCode"]) {
      const value = String(incoming && incoming[key] != null ? incoming[key] : "").trim();
      if (value) merged[key] = value;
      // Município vazio vindo do PDF não apaga um município já confirmado no Banco.
      // Se o usuário editou explicitamente a ficha e limpou o campo, a edição é respeitada.
      else if (key === "municipality" && config.allowBlankMunicipality) merged[key] = "";
    }
    return db.putStation(merged);
  }

  async function confirmF43() {
    const records = root.C32F43Parser.toRecords(state.interpretation);
    if (state.editingF43Id) return saveEditedF43(records);
    const match = await db.identifyStation(records.station);
    state.pendingF43Records = records;
    if (match.status === "exact") return saveF43ToStation(match.candidates[0]);
    if (match.status === "ambiguous") {
      state.pendingF43Records.candidates = match.candidates;
      return open("f43-station-match", "f43-review");
    }
    const station = await db.putStation(records.station);
    return saveF43ToStation(station);
  }

  async function saveEditedF43(records) {
    let station = await db.getStation(state.editingStationId);
    if (!station) station = await db.putStation(records.station);
    else station = await syncStationFromF43(station, records.station, { allowBlankMunicipality: true });
    records.f43.station = Object.assign({}, records.f43.station, {
      name: station.name || "", river: station.river || "", locality: station.locality || "", municipality: station.municipality || "", state: station.state || "", stationCode: station.stationCode || "", anaCode: station.anaCode || ""
    });
    if (state.editingF43RecordType === "leveling") {
      const old = await db.getLeveling(state.editingF43Id);
      const updated = Object.assign({}, old || {}, proposalFromF43(records.f43, station.id), { id: state.editingF43Id, stationId: station.id });
      updated.f43Source = records.f43;
      updated.fingerprint = root.C32Base.fingerprint("leveling", Object.assign({}, updated, { fingerprint: undefined }));
      await db.putLeveling(updated);
    } else {
      const old = await db.getF43(state.editingF43Id);
      const updated = Object.assign({}, old || {}, records.f43, { id: state.editingF43Id, stationId: station.id });
      updated.current = old ? Boolean(old.current) : updated.current;
      updated.station = records.f43.station;
      updated.fingerprint = root.C32Base.fingerprint("f43", Object.assign({}, updated, { fingerprint: undefined }));
      await db.putF43(updated);
    }
    state.interpretation = null; state.editingF43Id = null; state.editingF43RecordType = null; state.editingStationId = null;
    toast("Alterações da ficha salvas no Banco de Estações.");
    state.back = "bank";
    await stationDetail(station.id);
  }

  function f43StationMatch() {
    const records = state.pendingF43Records;
    frame("Identificar estação", `<section class="card notice warning"><strong>Possível estação já existente</strong><p class="subtle">A identificação não depende apenas do nome. Confirme tecnicamente se a ficha pertence a uma estação cadastrada.</p></section><div class="stack">${records.candidates.map((candidate) => `<button class="card v2-result" data-v2-action="match-station" data-id="${esc(candidate.id)}"><strong>${esc(candidate.name)}</strong><span>${esc([candidate.river, candidate.locality, candidate.state].filter(Boolean).join(" · "))}</span></button>`).join("")}<button class="secondary wide" data-v2-action="match-new-station">CADASTRAR COMO NOVA ESTAÇÃO</button></div>`);
  }

  async function saveF43ToStation(station) {
    const records = state.pendingF43Records;
    station = await syncStationFromF43(station, records.station);
    records.f43.station = Object.assign({}, records.f43.station, {
      name: station.name || "", river: station.river || "", locality: station.locality || "", municipality: station.municipality || "", state: station.state || "", stationCode: station.stationCode || "", anaCode: station.anaCode || ""
    });
    if (state.interpretation.classification.value !== "standard") {
      const proposal = proposalFromF43(records.f43, station.id);
      proposal.f43Source = JSON.parse(JSON.stringify(records.f43));
      const duplicates = await db.findLevelingByFingerprint(proposal.fingerprint);
      if (duplicates.length) {
        toast("Esta proposta já existe no Banco de Estações.");
      } else await db.putLeveling(proposal);
    } else {
      const incoming = records.f43;
      incoming.stationId = station.id;
      incoming.fingerprint = root.C32Base.fingerprint("f43", incoming);
      const duplicates = await db.findF43ByFingerprint(incoming.fingerprint);
      if (duplicates.length) {
        toast("Esta F-43 já existe no Banco de Estações.");
      } else {
        const existing = await db.listF43(station.id);
        const current = existing.find((item) => item.kind === "standard" && item.current === true);
        if (current) {
          const newer = root.C32Base.dateRank(incoming.updateDate || incoming.year || "") > root.C32Base.dateRank(current.updateDate || current.year || "");
          if (newer && root.confirm(`Existe uma F-43 Padrão vigente. Tornar ${incoming.sourceFileName} a nova Padrão vigente?`)) {
            current.current = false;
            await db.putF43(current);
            incoming.current = true;
          } else incoming.current = false;
        } else incoming.current = true;
        await db.putF43(incoming);
      }
    }
    state.interpretation = null;
    state.pendingF43Records = null;
    toast("F-43 importada e estruturada no Banco de Estações.");
    state.back = "bank";
    await stationDetail(station.id);
  }

  function proposalFromF43(f43, stationId) {
    const record = {
      id: root.C32Model.id("proposal"), stationId, kind: "proposal", date: f43.updateDate || f43.confectionDate || "", dateKey: f43.updateDate || f43.year || "",
      sourceFileName: f43.sourceFileName, references: f43.references, relationships: f43.relationships || f43.diagram.relationships,
      stationScheme: f43.stationScheme || f43.diagram.stationScheme, rulerTopM: f43.diagram.rulerTopM,
      principalRn: f43.principalRn, principalToNrCm: f43.diagram.principalToNrConfirmedCm,
      nrToZeroCm: f43.diagram.nrToZeroCm, principalToZeroCm: f43.diagram.principalToZeroConfirmedCm || f43.diagram.principalToZeroCalculatedCm,
      metadata: { lh: f43.lh, chart: f43.chart, vesselCommission: f43.vesselCommission },
      rulerDescription: f43.descriptions && f43.descriptions.ruler,
      observations: f43.descriptions && f43.descriptions.observations
    };
    record.fingerprint = root.C32Base.fingerprint("leveling", record);
    return record;
  }

  async function importBase(bytes) {
    const parsed = root.C32Base.parse(bytes);
    const plan = await root.C32Base.planImport(parsed);
    state.basePlan = plan;
    state.baseResolutions = { stations: {}, f43: {}, levelings: {} };
    plan.stationPlans.filter((item) => item.status === "ambiguous").forEach((item) => { state.baseResolutions.stations[item.sourceId] = ""; });
    plan.f43Plans.filter((item) => item.status === "newer-standard").forEach((item) => { state.baseResolutions.f43[item.source.id] = { makeCurrent: false }; });
    plan.levelingPlans.filter((item) => item.status === "conflict").forEach((item) => { state.baseResolutions.levelings[item.source.id] = { action: "", corrected: JSON.parse(JSON.stringify(item.source)) }; });
    open("base-review", "menu");
  }

  function baseReview() {
    const plan = state.basePlan;
    const counts = plan.parsed.summary;
    const conflicts = plan.levelingPlans.filter((item) => item.status === "conflict");
    frame("Importar Base .c32base", `<section class="card notice"><strong>Integridade da base: OK</strong><p class="subtle">SHA-256 conferido antes da mesclagem.</p></section><section class="card"><h3>Resumo</h3><dl class="v2-defs"><dt>Estações</dt><dd>${counts.stations}</dd><dt>F-43 Padrão</dt><dd>${counts.currentStandards}</dd><dt>Padrões anteriores</dt><dd>${counts.historicalStandards}</dd><dt>Nivelamentos</dt><dd>${counts.levelings}</dd><dt>Propostas</dt><dd>${counts.proposals}</dd></dl></section>
      ${plan.stationPlans.filter((item) => item.status === "ambiguous").map((item) => `<section class="card notice warning"><strong>Confirme a estação: ${esc(item.source.name)}</strong><select data-base-station="${esc(item.sourceId)}"><option value="">Selecione</option>${item.candidates.map((candidate) => `<option value="${esc(candidate.id)}">${esc(candidate.name)} · ${esc(candidate.river || "")}</option>`).join("")}</select></section>`).join("")}
      ${plan.f43Plans.filter((item) => item.status === "newer-standard").map((item) => `<section class="card notice warning"><strong>Nova F-43 Padrão mais recente</strong><p>${esc(item.source.sourceFileName || item.source.code)}</p><details><summary>Diferenças (${item.differences.length})</summary>${diffList(item.differences)}</details><label class="radio-option"><input type="checkbox" data-base-current-f43="${esc(item.source.id)}"> Tornar nova Padrão vigente; manter a anterior no histórico</label></section>`).join("")}
      ${conflicts.map(levelingConflict).join("")}
      <section class="card"><p><strong>Duplicidades exatas:</strong> ${plan.f43Plans.filter((item) => item.status === "duplicate").length + plan.levelingPlans.filter((item) => item.status === "duplicate").length}. Elas não serão gravadas novamente.</p></section><button class="primary wide" data-v2-action="apply-base">CONFIRMAR IMPORTAÇÃO</button>`);
  }

  function diffList(differences) {
    return `<ul class="v2-diffs">${differences.slice(0, 30).map((item) => `<li><strong>${esc(item.path)}</strong><small>Atual: ${esc(JSON.stringify(item.current))}</small><small>Recebido: ${esc(JSON.stringify(item.incoming))}</small></li>`).join("") || "<li>Sem diferenças estruturais relevantes.</li>"}</ul>`;
  }

  function levelingConflict(item) {
    const resolution = state.baseResolutions.levelings[item.source.id];
    return `<section class="card notice warning"><strong>Conflito: ${esc(formatDate(item.source.dateKey || item.source.date))}</strong><p class="subtle">O mesmo nivelamento/data possui dados divergentes.</p><select data-base-leveling="${esc(item.source.id)}"><option value="">Selecione</option><option value="replace" ${resolution.action === "replace" ? "selected" : ""}>Substituir</option><option value="correct" ${resolution.action === "correct" ? "selected" : ""}>Corrigir</option><option value="keep-both" ${resolution.action === "keep-both" ? "selected" : ""}>Manter os dois</option></select><details><summary>Diferenças e correção manual</summary>${diffList(item.differences)}${item.differences.map((difference) => `<div class="field"><label>${esc(difference.path)}</label><input data-base-correct-record="${esc(item.source.id)}" data-base-correct-path="${esc(difference.path)}" value="${esc(difference.incoming == null ? "" : typeof difference.incoming === "object" ? JSON.stringify(difference.incoming) : difference.incoming)}"></div>`).join("")}</details></section>`;
  }

  async function applyBase() {
    const result = await root.C32Base.applyPlan(state.basePlan, state.baseResolutions);
    toast(`Base importada: ${result.applied.stations} estação(ões), ${result.applied.f43} F-43 e ${result.applied.levelings} histórico(s).`);
    state.basePlan = null;
    open("bank", "menu");
    await bank();
  }

  async function exportView() {
    const stations = await db.searchStations("", "name");
    frame("Exportar Base", `<section class="card notice"><strong>Backup antes de desinstalar</strong><p class="subtle">A atualização normal preserva os dados. A desinstalação pode apagá-los; exporte a base e os projetos antes.</p></section><button class="primary wide" data-v2-action="export-all">EXPORTAR BASE INTEIRA</button><details class="card"><summary>Exportar uma estação</summary><div class="stack">${stations.map((station) => `<button class="secondary wide" data-v2-action="export-station" data-id="${esc(station.id)}">${esc(station.name)}</button>`).join("") || `<p class="subtle">Banco vazio.</p>`}</div></details>`);
  }

  async function exportSelection(type, id) {
    const snapshot = await db.getSnapshot({ type, id });
    const text = root.C32Base.serialize(snapshot, { selection: type, sourceId: id || "" });
    const suffix = type === "all" ? "BASE_COMPLETA" : type === "station" ? normal(snapshot.stations[0] && snapshot.stations[0].name).replace(/[^A-Z0-9]+/g, "_") : `NIVELAMENTO_${id}`;
    root.C32Native.saveFile(`C32_${suffix || "ESTACAO"}.c32base`, "application/octet-stream", text);
    toast("Integridade calculada. Escolha onde salvar a base.");
  }

  function manual() {
    frame("Manual", `<section class="card"><h2>Uso rápido</h2><ol class="v2-steps"><li>Use o nivelamento manual normalmente ou escolha uma estação no Banco.</li><li>Importe F-43 em PDF; confira verdes, revise amarelos e corrija vermelhos essenciais.</li><li>Ao usar um nivelamento anterior como referência, o check continua comparando com a F-43 Padrão vigente.</li><li>No final, escolha não salvar, salvar como Nivelamento ou salvar como Proposta.</li><li>Exporte uma .c32base para backup ou intercâmbio com o C32 Gabinete.</li></ol></section><section class="card"><h3>Regras importantes</h3><ul><li>Projeto e Banco de Estações são estruturas diferentes.</li><li>O PDF original e imagens não são armazenados.</li><li>RN-01 e RN 01 não são associadas automaticamente.</li><li>Uma F-43 Padrão nunca é substituída silenciosamente.</li><li>O aplicativo funciona sem internet.</li></ul></section><section class="card"><h3>Cores da interpretação</h3><p><span class="confidence-green">Verde</span> leitura clara. <span class="confidence-yellow">Amarelo</span> merece revisão. <span class="confidence-red">Vermelho</span> não lido ou conflitante; quando essencial, bloqueia a importação.</p></section>`);
  }

  function backupInfo() {
    frame("Backup e informações", `<section class="card notice warning"><strong>Antes de desinstalar</strong><p>Exporte a Base .c32base e salve os arquivos .project importantes. A desinstalação pode apagar o banco, rascunhos e configurações locais.</p></section><section class="card"><h3>Atualizações 2.x</h3><p>A instalação de uma atualização com o mesmo pacote e assinatura preserva banco, projetos locais e configurações. Não desinstale para atualizar.</p></section><section class="card"><h3>Armazenamento</h3><p>Não há login, nuvem, telemetria ou servidor. O Banco de Estações usa o armazenamento privado normal do aplicativo e exportação com SHA-256.</p></section><button class="primary wide" data-v2-action="export-all">FAZER BACKUP DA BASE AGORA</button>`);
  }

  async function referenceChoice() {
    const current = state.f43.find((item) => item.kind === "standard" && item.current === true);
    const recent = state.levelings.filter((item) => item.kind !== "proposal")[0];
    frame("Novo nivelamento", `<section class="card"><h2>${esc(state.station.name)}</h2><p class="subtle">Escolha a referência de execução. O check, quando possível, usa sempre a F-43 Padrão vigente.</p></section><div class="stack"><button class="choice-card" data-v2-action="reference-none"><strong>SEM REFERÊNCIA</strong><small>Inicia como no C32 anterior.</small></button><button class="choice-card" data-v2-action="reference-f43" data-id="${current ? esc(current.id) : ""}" ${current ? "" : "disabled"}><strong>F-43 PADRÃO</strong><small>${current ? esc(current.sourceFileName || current.code || "Padrão vigente") : "Nenhuma Padrão vigente"}</small></button><button class="choice-card" data-v2-action="reference-leveling" data-id="${recent ? esc(recent.id) : ""}" ${recent ? "" : "disabled"}><strong>NIVELAMENTO ANTERIOR</strong><small>${recent ? `Mais recente: ${esc(formatDate(recent.dateKey || recent.date))}` : "Nenhum nivelamento anterior"}</small></button></div>`);
  }

  async function prepareReference(type, id) {
    let record = null;
    if (type === "f43") record = await db.getF43(id);
    if (type === "leveling") record = await db.getLeveling(id);
    const references = record && Array.isArray(record.references) ? record.references : [];
    state.preparation = {
      station: state.station,
      sourceType: type,
      sourceId: id || "",
      sourceRecord: record,
      entries: references.map((item, index) => ({ id: root.C32Model.id("prep"), name: item.name, originalName: item.name, status: "normal", order: index })),
      relationships: record && Array.isArray(record.relationships) ? record.relationships : (record && record.diagram && record.diagram.relationships) || []
    };
    open("preparation", "station-detail");
  }

  function preparation() {
    const prep = state.preparation;
    frame("Preparar referências", `<section class="card notice"><strong>Somente antes de iniciar</strong><p class="subtle">Depois do início, nomes, ordem, situações e composição ficam travados para esta execução.</p></section><div class="stack">${prep.entries.map((entry, index) => `<article class="card v2-prep"><div class="field"><label>Referência</label><input data-prep-name="${index}" value="${esc(entry.name)}"></div><div class="field"><label>Situação</label><select data-prep-status="${index}">${[["normal", "Normal"], ["new", "Nova"], ["not-found", "Não encontrada"], ["destroyed", "Destruída"], ["inaccessible", "Inacessível"]].map(([value, label]) => `<option value="${value}" ${entry.status === value ? "selected" : ""}>${label}</option>`).join("")}</select></div><div class="v2-row-actions"><button class="mini-btn" data-v2-action="move-prep" data-index="${index}" data-direction="-1">↑</button><button class="mini-btn" data-v2-action="move-prep" data-index="${index}" data-direction="1">↓</button><button class="mini-btn" data-v2-action="delete-prep" data-index="${index}">×</button></div></article>`).join("") || `<section class="card"><p class="subtle">Sem referências pré-carregadas. Adicione se necessário.</p></section>`}</div><button class="secondary wide" data-v2-action="add-prep">+ ADICIONAR REFERÊNCIA NOVA</button><button class="primary wide" data-v2-action="start-prepared">CONTINUAR PARA DADOS INICIAIS</button>`, "A ordem pode ser alterada");
  }

  async function startPrepared() {
    const prep = state.preparation;
    const project = root.C32Model.createProject(prep.station.name, false);
    project.station.bankStationId = prep.station.id;
    project.station.executionSource = prep.sourceType;
    project.station.preparation = prep.entries.map((item) => ({ name: item.name, originalName: item.originalName, status: item.status }));
    const active = prep.entries.filter((item) => activeStatuses.has(item.status));
    const nameMap = new Map(active.map((item) => [normal(item.originalName), item.name]));
    const relations = [];
    for (const relation of prep.relationships || []) {
      const high = nameMap.get(normal(relation.high));
      const low = nameMap.get(normal(relation.low));
      const differenceCm = root.C32Calc.parseNumber(relation.differenceCm);
      const differenceM = root.C32Calc.parseNumber(relation.differenceM);
      if (high && low && !root.C32Calc.sameName(high, low)) relations.push(root.C32Model.createReference(high, low, differenceM !== null ? String(differenceM).replace(".", ",") : differenceCm !== null ? String(differenceCm / 100).replace(".", ",") : "", prep.sourceType));
    }
    project.station.references = relations;
    project.station.existing = relations.length > 0;
    const current = (await db.listF43(prep.station.id)).find((item) => item.kind === "standard" && item.current === true);
    project.station.checkReferences = current ? (current.relationships || (current.diagram && current.diagram.relationships) || []).map((relation) => root.C32Model.createReference(relation.high, relation.low, relation.differenceM != null ? relation.differenceM : Number(relation.differenceCm) / 100, "current-standard")) : [];
    project.metadata.leveling = `Estação Fluviométrica de ${prep.station.name}`;
    root.C32App.state.project = project;
    root.C32Storage.saveDraft(project);
    root.C32App.state.screen = "setup";
    root.C32App.render();
    close();
  }

  function currentRecord(kind) {
    const project = root.C32App.state.project;
    const calculation = root.C32App.recalculate();
    if (!project || !calculation || !calculation.scheme.valid) throw new Error("Conclua e valide o esquema antes de salvar no Banco.");
    const scheme = calculation.scheme;
    const stationSchemeNodes = scheme.levels.map((point, index) => ({
      key: point.isRuler ? "ruler-top" : `rn:${normal(point.name)}:${index}`,
      type: point.isRuler ? "ruler" : "rn",
      name: point.isRuler ? "Topo da régua" : point.name,
      elevationM: point.elevationM,
      rulerTopM: point.isRuler ? scheme.rulerTopM : undefined
    }));
    const stationSchemeLinks = scheme.relationships.map((relationship, index) => ({
      from: stationSchemeNodes[index].key,
      to: stationSchemeNodes[index + 1].key,
      differenceCm: relationship.differenceCm
    }));
    const record = {
      id: root.C32Model.id(kind === "proposal" ? "proposal" : "leveling"), stationId: project.station.bankStationId, kind,
      date: project.station.date, dateKey: project.station.date, year: String(project.station.date || "").slice(0, 4),
      references: scheme.points.filter((point) => !point.isRuler).map((point, index) => ({ name: point.name, order: index, elevationM: point.elevationM, situation: (project.station.preparation.find((item) => normal(item.name) === normal(point.name)) || {}).status || "normal" })),
      relationships: scheme.relationships,
      stationScheme: { nodes: stationSchemeNodes, links: stationSchemeLinks, relationships: scheme.relationships, rulerTopM: scheme.rulerTopM },
      rulerTopM: scheme.rulerTopM,
      principalRn: scheme.principal, principalToNrCm: scheme.principalToNrCm,
      nrToZeroCm: scheme.nrToZeroCm, principalToZeroCm: scheme.principalToZeroCm,
      closure: calculation.closure, patternOk: calculation.patternOk, patternErrors: calculation.patternErrors,
      currentF43Id: "", team: project.metadata.observer || "", chiefCommission: project.metadata.chief || project.metadata.commission || "",
      observations: project.scheme.rulerObservation || project.metadata.otherInformation || "", projectFileName: `${project.station.name}_${project.station.date}.project`,
      sourceProjectId: project.id
    };
    record.fingerprint = root.C32Base.fingerprint("leveling", record);
    return record;
  }

  async function saveCurrent(kind) {
    const record = currentRecord(kind);
    if (!record.stationId) throw new Error("Este nivelamento não foi iniciado por uma estação do Banco. Selecione a estação no Banco antes de salvar o histórico.");
    const duplicates = await db.findLevelingByFingerprint(record.fingerprint);
    if (duplicates.length) return toast("Este nivelamento já existe no Banco de Estações.");
    const existing = (await db.listLevelings(record.stationId)).filter((item) => String(item.dateKey || item.date) === String(record.dateKey));
    if (existing.length) {
      state.pendingCurrentRecord = { record, existing };
      return open("current-conflict", "");
    }
    await db.putLeveling(record);
    root.C32App.state.project.bankSaveChoice = kind;
    root.C32App.saveDraft();
    toast(kind === "proposal" ? "Salvo como Proposta de Atualização." : "Nivelamento salvo no Banco de Estações.");
    refreshExportPanels();
  }

  function currentConflict() {
    const pending = state.pendingCurrentRecord;
    frame("Conflito no histórico", `<section class="card notice warning"><strong>Mesmo nivelamento/data com dados divergentes</strong><p>${esc(formatDate(pending.record.dateKey))}</p></section>${diffList(root.C32Base.diffValues(pending.existing[0], pending.record))}<div class="stack"><button class="primary wide" data-v2-action="current-replace">SUBSTITUIR PELO ATUAL</button><button class="secondary wide" data-v2-action="current-correct">CORRIGIR USANDO OS VALORES ATUAIS</button><button class="secondary wide" data-v2-action="current-keep">MANTER OS DOIS (A/B/C)</button></div>`);
  }

  async function resolveCurrent(action) {
    const pending = state.pendingCurrentRecord;
    const record = pending.record;
    if (action === "replace" || action === "correct") record.id = pending.existing[0].id;
    else {
      const all = await db.listLevelings(record.stationId);
      if (!pending.existing[0].displaySuffix) {
        pending.existing[0].displaySuffix = "A";
        await db.putLeveling(pending.existing[0]);
      }
      record.displaySuffix = root.C32Base.nextSuffix(all, record.dateKey);
    }
    record.fingerprint = root.C32Base.fingerprint("leveling", record);
    await db.putLeveling(record);
    state.pendingCurrentRecord = null;
    close();
    toast("Histórico salvo conforme a decisão técnica.");
    refreshExportPanels();
  }

  async function refreshExportPanels() {
    const project = root.C32App && root.C32App.state.project;
    const finalize = document.getElementById("v2-bank-finalize");
    const history = document.getElementById("v2-export-history");
    if (!finalize || !history || !project) return;
    finalize.innerHTML = `<section class="card stack"><h3>Salvar no Banco de Estações</h3><p class="subtle">Escolha uma opção. O Banco guarda somente o esquema e metadados, nunca as leituras FS/FI/Central.</p><button class="secondary wide" data-v2-global="no-save">NÃO SALVAR NO BANCO</button><button class="primary wide" data-v2-global="save-leveling">SALVAR COMO NIVELAMENTO</button><button class="secondary wide" data-v2-global="save-proposal">SALVAR COMO PROPOSTA DE ATUALIZAÇÃO</button></section>`;
    if (!project.station.bankStationId) {
      history.innerHTML = `<section class="card"><h3>Histórico da estação</h3><p class="subtle">Este projeto foi iniciado sem uma estação do Banco.</p></section>`;
      return;
    }
    const levelings = (await db.listLevelings(project.station.bankStationId)).filter((item) => item.kind !== "proposal");
    const f43 = await db.listF43(project.station.bankStationId);
    const current = f43.find((item) => item.kind === "standard" && item.current === true);
    let recurrent = false;
    if (current && levelings.length >= 2) {
      const standard = Number(current.diagram && (current.diagram.principalToZeroConfirmedCm || current.diagram.principalToZeroCalculatedCm));
      const diffs = levelings.slice(0, 2).map((item) => Number(item.principalToZeroCm) - standard).filter(Number.isFinite);
      recurrent = diffs.length === 2 && Math.sign(diffs[0]) === Math.sign(diffs[1]) && Math.abs(diffs[0]) > 0.2 && Math.abs(diffs[1]) > 0.2 && Math.abs(diffs[0] - diffs[1]) <= Math.max(1, Math.abs(diffs[0]) * 0.25);
    }
    history.innerHTML = `<details class="card"><summary>HISTÓRICO DA ESTAÇÃO (${levelings.length})</summary><div class="v2-details-body">${recurrent ? `<div class="notice warning"><strong>Divergência recorrente em relação à F-43 Padrão</strong></div>` : ""}${levelings.slice(0, 12).map((item) => `<p><strong>${esc(formatDate(item.dateKey || item.date))}${item.displaySuffix ? ` ${esc(item.displaySuffix)}` : ""}</strong> · RN Principal → Zero: ${item.principalToZeroCm == null ? "--" : esc(String(item.principalToZeroCm).replace(".", ",")) + " cm"}</p>`).join("") || `<p class="subtle">Sem nivelamentos anteriores.</p>`}</div></details>`;
  }

  async function render() {
    if (state.view === "menu") return menu();
    if (state.view === "bank") return bank();
    if (state.view === "new-station") return stationForm();
    if (state.view === "station-detail") return stationDetail();
    if (state.view === "progress") return progressView();
    if (state.view === "f43-review") return f43Review();
    if (state.view === "f43-station-match") return f43StationMatch();
    if (state.view === "base-review") return baseReview();
    if (state.view === "export-base") return exportView();
    if (state.view === "manual") return manual();
    if (state.view === "backup-info") return backupInfo();
    if (state.view === "reference-choice") return referenceChoice();
    if (state.view === "preparation") return preparation();
    if (state.view === "current-conflict") return currentConflict();
    return menu();
  }

  function move(array, index, direction) {
    const target = index + direction;
    if (index < 0 || target < 0 || index >= array.length || target >= array.length) return;
    [array[index], array[target]] = [array[target], array[index]];
  }

  overlay.addEventListener("input", async (event) => {
    if (event.target.id === "v2-station-query") {
      state.query = event.target.value;
      await loadStations();
      const list = event.target.closest(".v2-content").querySelector(".stack:last-child");
      if (list) list.innerHTML = state.stations.map((station) => `<button class="card v2-result" data-v2-action="station" data-id="${esc(station.id)}"><strong>${esc(station.name)}</strong><span>${esc([station.river, station.locality, station.state].filter(Boolean).join(" · "))}</span></button>`).join("") || `<section class="card"><p class="subtle">Nenhum resultado.</p></section>`;
      return;
    }
    const fieldPath = event.target.dataset.f43Field;
    if (fieldPath) {
      const field = getPath(state.interpretation, fieldPath);
      field.value = event.target.value; field.confidence = "green"; field.source = "user";
      state.interpretation.corrections.push({ field: fieldPath, value: event.target.value, at: new Date().toISOString() });
      root.C32F43Parser.validate(state.interpretation);
      return;
    }
    const numberPath = event.target.dataset.f43Number;
    if (numberPath) {
      setPath(state.interpretation, numberPath, root.C32F43Parser.decimal(event.target.value));
      root.C32F43Parser.recalculate(state.interpretation);
      return;
    }
    if (event.target.dataset.f43Relationship != null) {
      const index = Number(event.target.dataset.f43Relationship);
      const draft = state.interpretation.diagram.relationshipDrafts[index];
      if (draft) {
        draft.differenceCm = root.C32F43Parser.decimal(event.target.value);
        draft.source = "manual"; draft.confidence = draft.differenceCm === null ? "missing" : "manual";
        state.interpretation.corrections.push({ field: `diagram.relationshipDrafts.${index}.differenceCm`, value: event.target.value, at: new Date().toISOString() });
        root.C32F43Parser.recalculate(state.interpretation);
      }
      return;
    }
    if (event.target.dataset.rnName != null) {
      const item = state.interpretation.references[Number(event.target.dataset.rnName)];
      item.name = event.target.value; item.confidence = "green";
      if (item.isPrincipal) state.interpretation.principalRn.value = item.name;
      root.C32F43Parser.recalculate(state.interpretation);
    }
    if (event.target.dataset.rnDescription != null) state.interpretation.references[Number(event.target.dataset.rnDescription)].description = event.target.value;
    if (event.target.dataset.prepName != null) state.preparation.entries[Number(event.target.dataset.prepName)].name = event.target.value;
    if (event.target.dataset.baseCorrectRecord) {
      const resolution = state.baseResolutions.levelings[event.target.dataset.baseCorrectRecord];
      let value = event.target.value;
      try { value = JSON.parse(value); } catch (_) { /* texto manual */ }
      setPath(resolution.corrected, event.target.dataset.baseCorrectPath, value);
    }
  });

  overlay.addEventListener("change", (event) => {
    if (event.target.matches("[data-f43-classification]")) {
      state.interpretation.classification.value = event.target.value;
      state.interpretation.classification.confidence = event.target.value === "unknown" ? "red" : "green";
      root.C32F43Parser.validate(state.interpretation); render();
    }
    if (event.target.dataset.prepStatus != null) state.preparation.entries[Number(event.target.dataset.prepStatus)].status = event.target.value;
    if (event.target.dataset.baseStation) state.baseResolutions.stations[event.target.dataset.baseStation] = event.target.value;
    if (event.target.dataset.baseCurrentF43) state.baseResolutions.f43[event.target.dataset.baseCurrentF43].makeCurrent = event.target.checked;
    if (event.target.dataset.baseLeveling) state.baseResolutions.levelings[event.target.dataset.baseLeveling].action = event.target.value;
  });

  overlay.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-v2-action]");
    if (!button || button.disabled) return;
    const action = button.dataset.v2Action;
    try {
      if (action === "close") return close();
      if (action === "back") return open(state.back || "menu");
      if (action === "bank") return open("bank", "menu");
      if (action === "import-f43") { close(); return chooseFile("f43"); }
      if (action === "import-base") { close(); return chooseFile("base"); }
      if (action === "export-base") return open("export-base", "menu");
      if (action === "manual") return open("manual", "menu");
      if (action === "backup-info") return open("backup-info", "menu");
      if (action === "search-mode") { state.searchMode = button.dataset.mode; return open("bank", "menu"); }
      if (action === "new-station") return open("new-station", "bank");
      if (action === "save-new-station") {
        const record = {};
        overlay.querySelectorAll("[data-new-station]").forEach((input) => { record[input.dataset.newStation] = input.value; });
        if (!record.name.trim()) throw new Error("Informe o nome da estação.");
        const station = await db.putStation(record); state.back = "bank"; return stationDetail(station.id);
      }
      if (action === "station") { state.back = "bank"; return stationDetail(button.dataset.id); }
      if (action === "delete-station") { if (root.confirm("Excluir esta estação, suas F-43, nivelamentos e propostas?")) { await db.deleteStation(button.dataset.id); toast("Estação excluída."); return open("bank", "menu"); } }
      if (action === "delete-f43") { if (root.confirm("Excluir esta F-43 do Banco de Estações?")) { await db.deleteF43(button.dataset.id); return stationDetail(state.station.id); } }
      if (action === "delete-leveling") { if (root.confirm("Excluir este nivelamento/proposta do Banco?")) { await db.deleteLeveling(button.dataset.id); return stationDetail(state.station.id); } }
      if (action === "edit-f43-record") {
        const recordType = button.dataset.recordType || "f43";
        const stored = recordType === "leveling" ? await db.getLeveling(button.dataset.id) : await db.getF43(button.dataset.id);
        if (!stored) throw new Error("Ficha não encontrada.");
        const source = stored.f43Source || stored;
        if (!source.station && state.station) source.station = { name: state.station.name, river: state.station.river, locality: state.station.locality, municipality: state.station.municipality, state: state.station.state, stationCode: state.station.stationCode, anaCode: state.station.anaCode };
        state.interpretation = root.C32F43Parser.fromRecord(source);
        state.editingF43Id = stored.id; state.editingF43RecordType = recordType; state.editingStationId = stored.stationId || (state.station && state.station.id);
        return open("f43-review", "station-detail");
      }
      if (action === "cancel-f43") { const wasEditing = Boolean(state.editingF43Id); state.interpretation = null; state.editingF43Id = null; state.editingF43RecordType = null; state.editingStationId = null; return wasEditing && state.station ? stationDetail(state.station.id) : open("menu"); }
      if (action === "add-rn") { state.interpretation.references.push({ id: root.C32Model.id("rn"), name: "", description: "", verticalOrder: state.interpretation.references.length, isPrincipal: false, status: "normal", confidence: "red" }); root.C32F43Parser.recalculate(state.interpretation); return render(); }
      if (action === "delete-rn") { state.interpretation.references.splice(Number(button.dataset.index), 1); root.C32F43Parser.recalculate(state.interpretation); return render(); }
      if (action === "move-rn") { move(state.interpretation.references, Number(button.dataset.index), Number(button.dataset.direction)); root.C32F43Parser.recalculate(state.interpretation); return render(); }
      if (action === "principal-rn") { state.interpretation.references.forEach((item, index) => { item.isPrincipal = index === Number(button.dataset.index); }); state.interpretation.principalRn.value = state.interpretation.references[Number(button.dataset.index)].name; state.interpretation.principalRn.confidence = "green"; root.C32F43Parser.recalculate(state.interpretation); return render(); }
      if (action === "resolve-inconsistency") { root.C32F43Parser.resolveInconsistency(state.interpretation, button.dataset.id, button.dataset.value); return render(); }
      if (action === "resolve-custom") { const input = Array.from(overlay.querySelectorAll("[data-inconsistency-custom]")).find((item) => item.dataset.inconsistencyCustom === button.dataset.id); root.C32F43Parser.resolveInconsistency(state.interpretation, button.dataset.id, input && input.value); return render(); }
      if (action === "confirm-f43") return confirmF43();
      if (action === "match-station") return saveF43ToStation(await db.getStation(button.dataset.id));
      if (action === "match-new-station") return saveF43ToStation(await db.putStation(state.pendingF43Records.station));
      if (action === "apply-base") return applyBase();
      if (action === "export-all") return exportSelection("all");
      if (action === "export-station") return exportSelection("station", button.dataset.id);
      if (action === "export-leveling") return exportSelection("leveling", button.dataset.id);
      if (action === "view-bank-record") {
        state.stationViewSelection = { recordType: button.dataset.recordType, id: button.dataset.id };
        await stationDetail(state.station.id);
        const panel = overlay.querySelector(".v2-station-view");
        if (panel && typeof panel.scrollIntoView === "function") panel.scrollIntoView({ behavior: "smooth", block: "start" });
        return;
      }
      if (action === "prepare-leveling") return open("reference-choice", "station-detail");
      if (action === "start-reference-f43") return prepareReference("f43", button.dataset.id);
      if (action === "reference-none") return prepareReference("none", "");
      if (action === "reference-f43") return prepareReference("f43", button.dataset.id);
      if (action === "reference-leveling") return prepareReference("leveling", button.dataset.id);
      if (action === "move-prep") { move(state.preparation.entries, Number(button.dataset.index), Number(button.dataset.direction)); return render(); }
      if (action === "delete-prep") { state.preparation.entries.splice(Number(button.dataset.index), 1); return render(); }
      if (action === "add-prep") { state.preparation.entries.push({ id: root.C32Model.id("prep"), name: "", originalName: "", status: "new", order: state.preparation.entries.length }); return render(); }
      if (action === "start-prepared") return startPrepared();
      if (action === "current-replace") return resolveCurrent("replace");
      if (action === "current-correct") return resolveCurrent("correct");
      if (action === "current-keep") return resolveCurrent("keep");
    } catch (error) { toast(error.message || "Não foi possível concluir a ação.", "error"); }
  });

  document.addEventListener("click", async (event) => {
    const menuButton = event.target.closest("[data-v2-open-menu]");
    if (menuButton) { open("menu"); return; }
    const button = event.target.closest("[data-v2-global]");
    if (!button) return;
    try {
      if (button.dataset.v2Global === "no-save") { root.C32App.state.project.bankSaveChoice = "none"; root.C32App.saveDraft(); return toast("O nivelamento não foi salvo no Banco."); }
      if (button.dataset.v2Global === "save-leveling") return saveCurrent("leveling");
      if (button.dataset.v2Global === "save-proposal") return saveCurrent("proposal");
    } catch (error) { toast(error.message, "error"); }
  });

  fileInput.addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    const bytes = new Uint8Array(await file.arrayBuffer());
    await handleNativeFile(null, "", file.name, bytes);
    event.target.value = "";
  });

  const observer = new MutationObserver(() => {
    if (document.getElementById("v2-bank-finalize")) Promise.resolve().then(refreshExportPanels).catch(() => {});
  });
  observer.observe(document.getElementById("app"), { childList: true, subtree: false });

  root.C32V2 = { state, open, close, handleBack, applyHistoryState, refreshExportPanels, saveCurrent, exportSelection };
})(window);
