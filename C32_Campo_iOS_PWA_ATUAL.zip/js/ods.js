(function (root) {
  "use strict";

  const NS = Object.freeze({
    office: "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    table: "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    text: "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
    calcext: "urn:org:documentfoundation:names:experimental:calc:xmlns:calcext:1.0",
    draw: "urn:oasis:names:tc:opendocument:xmlns:drawing:1.0",
    svg: "urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0",
    style: "urn:oasis:names:tc:opendocument:xmlns:style:1.0",
    fo: "urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0"
  });

  function directElements(parent, localName) {
    return Array.from(parent.childNodes || []).filter((node) => {
      return node.nodeType === 1 && (!localName || (node.namespaceURI === NS.table && node.localName === localName));
    });
  }

  function rowElements(table) {
    return directElements(table, "table-row");
  }

  function cellElements(row) {
    return Array.from(row.childNodes || []).filter((node) => {
      return node.nodeType === 1 && node.namespaceURI === NS.table && (node.localName === "table-cell" || node.localName === "covered-table-cell");
    });
  }

  function attr(element, namespace, name, value) {
    if (value === undefined) return element.getAttributeNS(namespace, name);
    if (value === null) element.removeAttributeNS(namespace, name);
    else {
      const prefixes = new Map([
        [NS.table, "table"], [NS.office, "office"], [NS.calcext, "calcext"], [NS.text, "text"],
        [NS.draw, "draw"], [NS.svg, "svg"],
        [NS.style, "style"], [NS.fo, "fo"]
      ]);
      const prefix = prefixes.get(namespace) || "text";
      element.setAttributeNS(namespace, `${prefix}:${name}`, String(value));
    }
    return value;
  }

  function elementText(element) {
    return String(element.textContent || "").trim().replace(/\s+/g, " ");
  }

  function expandRows(table) {
    let rows = rowElements(table);
    for (const row of rows) {
      const repeat = Number(attr(row, NS.table, "number-rows-repeated") || 1);
      if (repeat <= 1 || repeat > 500) continue;
      for (let i = 0; i < repeat; i += 1) {
        const clone = row.cloneNode(true);
        attr(clone, NS.table, "number-rows-repeated", null);
        row.parentNode.insertBefore(clone, row);
      }
      row.parentNode.removeChild(row);
    }
    return rowElements(table);
  }

  function expandCells(row, requiredColumns) {
    let count = 0;
    const original = cellElements(row);
    for (const cell of original) {
      if (count >= requiredColumns) break;
      const repeat = Number(attr(cell, NS.table, "number-columns-repeated") || 1);
      const needed = Math.min(repeat, requiredColumns - count);
      if (repeat > 1) {
        for (let i = 0; i < needed; i += 1) {
          const clone = cell.cloneNode(true);
          attr(clone, NS.table, "number-columns-repeated", null);
          cell.parentNode.insertBefore(clone, cell);
        }
        const remaining = repeat - needed;
        if (remaining > 0) attr(cell, NS.table, "number-columns-repeated", remaining);
        else cell.parentNode.removeChild(cell);
      }
      count += repeat;
    }
    return cellElements(row);
  }

  function getCell(row, columnNumber) {
    const cells = expandCells(row, columnNumber);
    if (!cells[columnNumber - 1]) throw new Error(`Célula inexistente na coluna ${columnNumber}.`);
    return cells[columnNumber - 1];
  }

  function clearValue(cell) {
    ["value-type", "value", "date-value", "string-value"].forEach((name) => attr(cell, NS.office, name, null));
    attr(cell, NS.calcext, "value-type", null);
    attr(cell, NS.table, "formula", null);
    Array.from(cell.childNodes || []).forEach((child) => {
      if (child.nodeType === 1 && child.namespaceURI === NS.text) cell.removeChild(child);
    });
  }

  function addParagraph(cell, text) {
    const paragraph = cell.ownerDocument.createElementNS(NS.text, "text:p");
    paragraph.appendChild(cell.ownerDocument.createTextNode(String(text == null ? "" : text)));
    cell.appendChild(paragraph);
  }

  function setString(cell, value) {
    clearValue(cell);
    const text = String(value == null ? "" : value);
    if (!text) return;
    attr(cell, NS.office, "value-type", "string");
    attr(cell, NS.calcext, "value-type", "string");
    addParagraph(cell, text);
  }

  function setNumber(cell, value, display, formula) {
    clearValue(cell);
    if (value === null || value === undefined || !Number.isFinite(Number(value))) return;
    const numeric = Number(value);
    attr(cell, NS.office, "value-type", "float");
    attr(cell, NS.calcext, "value-type", "float");
    attr(cell, NS.office, "value", String(numeric));
    if (formula) attr(cell, NS.table, "formula", formula);
    addParagraph(cell, display == null ? String(numeric) : display);
  }

  function setDate(cell, isoDate) {
    clearValue(cell);
    if (!isoDate) return;
    const [year, month, day] = String(isoDate).split("-");
    attr(cell, NS.office, "value-type", "date");
    attr(cell, NS.calcext, "value-type", "date");
    attr(cell, NS.office, "date-value", isoDate);
    addParagraph(cell, `${day}-${month}-${year}`);
  }

  function setCellStyle(cell, styleName) {
    attr(cell, NS.table, "style-name", styleName || null);
  }

  function getCellStyle(cell) {
    return attr(cell, NS.table, "style-name");
  }

  function pad4(value) {
    if (value === null || value === undefined || value === "") return "";
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return "";
    if (Math.abs(numeric - Math.round(numeric)) > 1e-7) return numeric.toFixed(1).replace(".", ",");
    const sign = numeric < 0 ? "-" : "";
    return sign + String(Math.abs(Math.round(numeric))).padStart(4, "0");
  }

  function decimal(value, digits = 1) {
    if (value === null || value === undefined || !Number.isFinite(Number(value))) return "";
    return Number(value).toFixed(digits).replace(".", ",");
  }

  function findTable(document, nameOrMatcher) {
    const tables = Array.from(document.getElementsByTagNameNS(NS.table, "table"));
    if (typeof nameOrMatcher === "function") return tables.find(nameOrMatcher);
    return tables.find((table) => attr(table, NS.table, "name") === nameOrMatcher);
  }

  function findRow(rows, text) {
    return rows.findIndex((row) => elementText(row).includes(text));
  }

  function clearColumns(row, from, to) {
    for (let column = from; column <= to; column += 1) clearValue(getCell(row, column));
  }

  function insertCapacityRows(table, requiredLances) {
    let rows = expandRows(table);
    const headerIndex = rows.findIndex((row) => {
      const text = elementText(row).replace(/\s+/g, "");
      return text.includes("ARAVSUPCENINFS+I(S+I)/2S-I");
    });
    const totalIndex = findRow(rows, "Somatório");
    const sideIndex = findRow(rows, "Diferença Desnível IDA / VOLTA");
    if (headerIndex < 0 || totalIndex < 0 || sideIndex < 0) throw new Error("Estrutura da caderneta C-32 não reconhecida.");
    const dataStart = headerIndex + 1;
    const capacity = totalIndex - dataStart;
    // O painel lateral usa a coluna de observações das últimas linhas vazias
    // do modelo. Antes de escrever um lance nessa área, deslocamos o painel
    // para baixo. Assim cada lance mantém sua observação e o painel continua
    // inteiro, inclusive quando a quantidade ultrapassa 20/21 linhas.
    const rowsBeforeSidePanel = sideIndex - dataStart;
    const extra = Math.max(0, requiredLances - rowsBeforeSidePanel);
    if (extra > 0) {
      const templateRow = rows[dataStart + Math.min(1, capacity - 1)].cloneNode(true);
      clearColumns(templateRow, 1, 22);
      attr(templateRow, NS.table, "number-rows-repeated", null);
      const insertionPoint = rows[sideIndex];
      for (let i = 0; i < extra; i += 1) table.insertBefore(templateRow.cloneNode(true), insertionPoint);
    }
    rows = rowElements(table);
    return {
      rows,
      dataStart,
      capacity: capacity + extra,
      totalIndex: findRow(rows, "Somatório"),
      sideIndex: findRow(rows, "Diferença Desnível IDA / VOLTA")
    };
  }

  function rawReading(reading) {
    return {
      sup: root.C32Calc.parseNumber(reading && reading.sup),
      cen: root.C32Calc.parseNumber(reading && reading.cen),
      inf: root.C32Calc.parseNumber(reading && reading.inf)
    };
  }

  function populateLanceRow(row, rowNumber, index, lance) {
    clearColumns(row, 1, 21);
    const ar = rawReading(lance.ar);
    const av = rawReading(lance.av);
    setNumber(getCell(row, 1), index + 1, String(index + 1));
    setString(getCell(row, 2), lance.from);
    setString(getCell(row, 3), lance.to);
    [ar.sup, ar.cen, ar.inf].forEach((value, offset) => setNumber(getCell(row, 4 + offset), value, pad4(value)));
    [av.sup, av.cen, av.inf].forEach((value, offset) => setNumber(getCell(row, 10 + offset), value, pad4(value)));
    if ([ar.sup, ar.cen, ar.inf].every((value) => value !== null)) {
      const sum = ar.sup + ar.inf;
      setNumber(getCell(row, 7), sum, pad4(sum), `of:=([.D${rowNumber}]+[.F${rowNumber}])`);
      setNumber(getCell(row, 8), sum / 2, pad4(sum / 2), `of:=([.G${rowNumber}]/2)`);
      setNumber(getCell(row, 9), ar.sup - ar.inf, pad4(ar.sup - ar.inf), `of:=([.D${rowNumber}]-[.F${rowNumber}])`);
    }
    if ([av.sup, av.cen, av.inf].every((value) => value !== null)) {
      const sum = av.sup + av.inf;
      setNumber(getCell(row, 13), sum, pad4(sum), `of:=([.J${rowNumber}]+[.L${rowNumber}])`);
      setNumber(getCell(row, 14), sum / 2, pad4(sum / 2), `of:=([.M${rowNumber}]/2)`);
      setNumber(getCell(row, 15), av.sup - av.inf, pad4(av.sup - av.inf), `of:=([.J${rowNumber}]-[.L${rowNumber}])`);
    }
    if (ar.sup !== null && ar.inf !== null && av.sup !== null && av.inf !== null) {
      const distance = (Math.abs(ar.sup - ar.inf) + Math.abs(av.sup - av.inf)) / 10;
      setNumber(getCell(row, 16), distance, decimal(distance, 1), `of:=((ABS([.I${rowNumber}])+ABS([.O${rowNumber}]))/10)`);
    }
    if (ar.cen !== null && av.cen !== null) {
      const delta = ar.cen - av.cen;
      if (delta > 0) setNumber(getCell(row, 17), delta, pad4(delta), `of:=IF(([.E${rowNumber}]-[.K${rowNumber}])>0; ([.E${rowNumber}]-[.K${rowNumber}]); "")`);
      else setNumber(getCell(row, 17), 0, "", `of:=IF(([.E${rowNumber}]-[.K${rowNumber}])>0; ([.E${rowNumber}]-[.K${rowNumber}]); "")`);
      if (delta < 0) setNumber(getCell(row, 18), Math.abs(delta), pad4(Math.abs(delta)), `of:=IF(([.E${rowNumber}]-[.K${rowNumber}])<0; ABS([.E${rowNumber}]-[.K${rowNumber}]); "")`);
      else setNumber(getCell(row, 18), 0, "", `of:=IF(([.E${rowNumber}]-[.K${rowNumber}])<0; ABS([.E${rowNumber}]-[.K${rowNumber}]); "")`);
    }
    setString(getCell(row, 20), lance.visibility || "");
    setString(getCell(row, 21), lance.wind || "");
    setString(getCell(row, 22), lance.observation || "");
  }

  function populateRun(table, lances, runCalculation) {
    const layout = insertCapacityRows(table, lances.length);
    const rows = layout.rows;
    for (let i = 0; i < layout.capacity; i += 1) {
      const row = rows[layout.dataStart + i];
      if (i < lances.length) populateLanceRow(row, layout.dataStart + i + 1, i, lances[i]);
      else {
        clearColumns(row, 1, 21);
        // A coluna V só é observação enquanto a linha estiver acima do painel
        // lateral. Limpá-la evita que dados da planilha-modelo vazem para um
        // projeto com menos lances, sem apagar os rótulos do painel.
        if (layout.dataStart + i < layout.sideIndex) clearValue(getCell(row, 22));
      }
    }
    const totalRow = rows[layout.totalIndex];
    const totalRowNumber = layout.totalIndex + 1;
    const lastDataRow = layout.dataStart + layout.capacity;
    setNumber(getCell(totalRow, 16), runCalculation.distanceM, decimal(runCalculation.distanceM, 1), `of:=SUM([.P${layout.dataStart + 1}:.P${lastDataRow}])`);
    const positive = runCalculation.valid ? runCalculation.rows.reduce((sum, row) => sum + Math.max(0, row.deltaMm), 0) : null;
    const negative = runCalculation.valid ? runCalculation.rows.reduce((sum, row) => sum + Math.max(0, -row.deltaMm), 0) : null;
    setNumber(getCell(totalRow, 17), positive, pad4(positive), `of:=SUM([.Q${layout.dataStart + 1}:.Q${lastDataRow}])`);
    setNumber(getCell(totalRow, 18), negative, pad4(negative), `of:=SUM([.R${layout.dataStart + 1}:.R${lastDataRow}])`);
    setNumber(getCell(totalRow, 22), runCalculation.deltaMm, runCalculation.deltaMm == null ? "" : String(runCalculation.deltaMm), `of:=[.Q${totalRowNumber}]-[.R${totalRowNumber}]`);
    attr(table, NS.table, "print-ranges", `$${attr(table, NS.table, "name")}.$A$1:$V$${totalRowNumber + 1}`);
    return { totalRowNumber, layout };
  }

  function setByAddress(table, rowNumber, columnNumber, setter, value) {
    const rows = expandRows(table);
    const row = rows[rowNumber - 1];
    if (!row) throw new Error(`Linha ${rowNumber} não encontrada.`);
    setter(getCell(row, columnNumber), value);
  }

  function populateHeader(idaTable, voltaTable, project) {
    const metadata = project.metadata || {};
    const cells = [
      [1, 2, project.station.name], [1, 10, metadata.observer], [1, 19, metadata.annotator],
      [2, 3, "GEOMÉTRICO"], [2, 13, project.station.date], [2, 18, metadata.startTime], [2, 22, metadata.endTime],
      [3, 3, metadata.instrument], [3, 8, metadata.instrumentNumber], [3, 13, metadata.staffAv], [3, 20, metadata.staffAr]
    ];
    for (const table of [idaTable, voltaTable]) {
      for (const [row, column, value] of cells) {
        if (row === 2 && column === 13) setByAddress(table, row, column, setDate, value);
        else setByAddress(table, row, column, setString, value || "");
      }
    }
  }

  function populateCover(cover, project) {
    const metadata = project.metadata || {};
    setByAddress(cover, 3, 7, setString, metadata.documentNumber || "C-32");
    setByAddress(cover, 17, 6, setString, metadata.commission || "");
    setByAddress(cover, 19, 6, setString, metadata.surveyNumber || "");
    setByAddress(cover, 21, 6, setString, metadata.chartNumber || "");
    setByAddress(cover, 23, 6, setString, metadata.chief || "");
    setByAddress(cover, 25, 6, setString, metadata.leveling || `Estação Fluviométrica de ${project.station.name}`);
    setByAddress(cover, 25, 11, setDate, project.station.date);
    setByAddress(cover, 30, 6, setString, metadata.coverObservation || "");
  }

  function movePrincipalConnection(schemeTable, principalRow) {
    const rows = expandRows(schemeTable);
    const selectedMarker = [3, 4, 5].map((column) => getCellStyle(getCell(rows[14], column)));
    const normalMarker = [3, 4, 5].map((column) => getCellStyle(getCell(rows[5], column)));
    const selectedLine = [];
    const normalLine = [];
    for (let column = 10; column <= 23; column += 1) {
      selectedLine.push(getCellStyle(getCell(rows[14], column)));
      normalLine.push(getCellStyle(getCell(rows[5], column)));
    }
    for (const levelRow of [5, 8, 11, 14]) {
      const markerRow = rows[levelRow];
      normalMarker.forEach((style, index) => setCellStyle(getCell(markerRow, 3 + index), style));
      normalLine.forEach((style, index) => setCellStyle(getCell(markerRow, 10 + index), style));
    }
    const target = rows[principalRow];
    selectedMarker.forEach((style, index) => setCellStyle(getCell(target, 3 + index), style));
    selectedLine.forEach((style, index) => setCellStyle(getCell(target, 10 + index), style));
    const verticalStyles = {
      13: getCellStyle(getCell(rows[15], 13)),
      14: getCellStyle(getCell(rows[15], 14)),
      17: getCellStyle(getCell(rows[15], 17)),
      18: getCellStyle(getCell(rows[15], 18))
    };
    for (let rowNumber = principalRow + 1; rowNumber <= 15; rowNumber += 1) {
      for (const [column, style] of Object.entries(verticalStyles)) setCellStyle(getCell(rows[rowNumber], Number(column)), style);
    }
  }

  function compactUnusedRnSlots(schemeTable, usedRnCount) {
    const count = Math.max(0, Math.min(4, Number(usedRnCount) || 0));
    const nameRows = [5, 8, 11, 14];
    for (let slot = 3; slot >= count; slot -= 1) {
      const currentRows = expandRows(schemeTable);
      const start = nameRows[slot] - 1;
      for (let offset = 2; offset >= 0; offset -= 1) {
        const row = currentRows[start + offset];
        if (row && row.parentNode) row.parentNode.removeChild(row);
      }
    }
    const lastMeaningfulRow = 44 - ((4 - count) * 3);
    const sheetName = attr(schemeTable, NS.table, "name");
    attr(schemeTable, NS.table, "print-ranges", `$${sheetName}.$A$1:$X$${lastMeaningfulRow}`);
    return lastMeaningfulRow;
  }

  function ensureSchemeGraphicStyle(document) {
    const styleName = "C32SchemeGraphic";
    const styles = Array.from(document.getElementsByTagNameNS(NS.style, "style"));
    if (styles.some((item) => attr(item, NS.style, "name") === styleName)) return styleName;
    const automaticStyles = document.getElementsByTagNameNS(NS.office, "automatic-styles")[0];
    if (!automaticStyles) return "";
    const style = document.createElementNS(NS.style, "style:style");
    attr(style, NS.style, "name", styleName);
    attr(style, NS.style, "family", "graphic");
    attr(style, NS.style, "parent-style-name", "Graphics");
    const properties = document.createElementNS(NS.style, "style:graphic-properties");
    attr(properties, NS.style, "run-through", "foreground");
    attr(properties, NS.style, "wrap", "none");
    attr(properties, NS.style, "vertical-pos", "from-top");
    attr(properties, NS.style, "vertical-rel", "page");
    attr(properties, NS.style, "horizontal-pos", "from-left");
    attr(properties, NS.style, "horizontal-rel", "page");
    attr(properties, NS.style, "mirror", "none");
    attr(properties, NS.fo, "clip", "rect(0cm, 0cm, 0cm, 0cm)");
    attr(properties, NS.draw, "image-opacity", "100%");
    attr(properties, NS.draw, "color-mode", "standard");
    style.appendChild(properties);
    automaticStyles.appendChild(style);
    return styleName;
  }

  function bytesToBase64(data) {
    let bytes;
    if (typeof data === "string") bytes = new TextEncoder().encode(data);
    else bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    if (root.C32Native && typeof root.C32Native.bytesToBase64 === "function") {
      return root.C32Native.bytesToBase64(bytes);
    }
    if (typeof Buffer !== "undefined") return Buffer.from(bytes).toString("base64");
    let binary = "";
    const chunk = 0x8000;
    for (let index = 0; index < bytes.length; index += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(index, index + chunk));
    }
    return btoa(binary);
  }

  function schemeGraphicSize(graphic) {
    const widthCm = 18.6;
    const sourceWidth = Number(graphic && graphic.width) || 2048;
    const sourceHeight = Number(graphic && graphic.height) || 1299;
    return {
      widthCm,
      heightCm: Math.round((widthCm * sourceHeight / sourceWidth) * 100) / 100
    };
  }

  function attachSchemeGraphic(schemeTable, graphic) {
    const oldShapes = directElements(schemeTable).filter((node) => node.namespaceURI === NS.table && node.localName === "shapes");
    oldShapes.forEach((node) => node.parentNode.removeChild(node));
    const document = schemeTable.ownerDocument;
    const styleName = ensureSchemeGraphicStyle(document);
    const shapes = document.createElementNS(NS.table, "table:shapes");
    const frame = document.createElementNS(NS.draw, "draw:frame");
    attr(frame, NS.draw, "name", "Esquema de Cotas C32 Campo");
    attr(frame, NS.draw, "z-index", "100");
    if (styleName) attr(frame, NS.draw, "style-name", styleName);
    attr(frame, NS.svg, "x", "0.15cm");
    attr(frame, NS.svg, "y", "0.15cm");
    // A aba-modelo tem cerca de 19 cm úteis entre A e X. Um quadro mais
    // largo é recortado pelo intervalo de impressão, ainda que o PNG esteja
    // correto. Mantemos aqui a mesma proporção 2048:1299 dentro da área útil.
    const frameSize = schemeGraphicSize(graphic);
    attr(frame, NS.svg, "width", `${frameSize.widthCm.toFixed(2)}cm`);
    attr(frame, NS.svg, "height", `${frameSize.heightCm.toFixed(2)}cm`);
    const image = document.createElementNS(NS.draw, "draw:image");
    attr(image, NS.draw, "mime-type", graphic.mediaType || "image/png");
    // Dados inline fazem o Calc respeitar o tamanho do quadro em vez de
    // recortar a imagem pela dimensão intrínseca do PNG em alguns leitores.
    const binaryData = document.createElementNS(NS.office, "office:binary-data");
    binaryData.appendChild(document.createTextNode(bytesToBase64(graphic.data)));
    image.appendChild(binaryData);
    frame.appendChild(image);
    shapes.appendChild(frame);
    schemeTable.appendChild(shapes);
    return frameSize;
  }

  function insertExpandedSchemeRows(schemeTable, rnCount) {
    const extraRows = Math.max(0, Number(rnCount || 0) - 4) * 3;
    if (!extraRows) return 0;
    const rows = expandRows(schemeTable);
    const insertionPoint = rows[33];
    const sourceRow = rows[34] || rows[31];
    if (!insertionPoint || !sourceRow) throw new Error("Não foi possível ampliar a área do Esquema de Cotas.");
    const templateRow = sourceRow.cloneNode(true);
    attr(templateRow, NS.table, "number-rows-repeated", null);
    clearColumns(templateRow, 1, 24);
    for (let index = 0; index < extraRows; index += 1) {
      schemeTable.insertBefore(templateRow.cloneNode(true), insertionPoint);
    }
    return extraRows;
  }

  function clearLegacySchemeDrawing(schemeTable) {
    const rows = expandRows(schemeTable);
    const blankStyle = getCellStyle(getCell(rows[34], 3));
    for (let rowIndex = 0; rowIndex <= 32; rowIndex += 1) {
      for (let column = 1; column <= 24; column += 1) {
        const cell = getCell(rows[rowIndex], column);
        clearValue(cell);
        setCellStyle(cell, blankStyle);
      }
    }
  }

  function populateScheme(schemeTable, project, scheme, graphic) {
    if (!scheme.valid) throw new Error("Os dados do esquema ainda não são válidos.");
    const rnLevels = scheme.levels.filter((point) => !point.isRuler);
    const hasGraphic = Boolean(graphic && graphic.data);
    if (rnLevels.length > 4 && !hasGraphic) {
      throw new Error("O esquema ampliado exige o gerador gráfico incorporado.");
    }
    const rows = expandRows(schemeTable);
    const safeStation = String(project.station.name || "ESTAÇÃO").toUpperCase();
    setString(getCell(rows[2], 3), `ESQUEMA_DE_COTAS_(${safeStation})`);
    const nameRows = [5, 8, 11, 14];
    const differenceRows = [7, 10, 13, 16];
    const principalIndex = rnLevels.findIndex((point) => root.C32Calc.sameName(point.name, scheme.principal));
    if (principalIndex < 0) throw new Error("A RN principal não foi encontrada entre as RNs do esquema.");
    if (rnLevels.length <= 4) {
      for (let i = 0; i < 4; i += 1) {
        const point = rnLevels[i];
        setString(getCell(rows[nameRows[i] - 1], 3), point ? point.name : "");
        let difference = null;
        if (point) {
          const next = rnLevels[i + 1] || scheme.levels.find((candidate) => candidate.isRuler);
          if (next) difference = Math.abs(point.elevationM - next.elevationM) * 100;
        }
        setNumber(getCell(rows[differenceRows[i] - 1], 7), difference, difference == null ? "" : decimal(difference, 2));
        setString(getCell(rows[differenceRows[i] - 1], 9), difference == null ? "" : "cm");
      }
      movePrincipalConnection(schemeTable, nameRows[principalIndex]);
    }
    const observation = project.scheme.rulerObservation || `A mira foi colocada no topo da régua fluviométrica de ${decimal(scheme.rulerTopM, 2)} m.`;
    setString(getCell(rows[17], 10), observation);
    setNumber(getCell(rows[17], 17), scheme.principalToNrCm, decimal(scheme.principalToNrCm, 2));
    setNumber(getCell(rows[21], 13), scheme.principalToZeroCm, decimal(scheme.principalToZeroCm, 2));
    setNumber(getCell(rows[29], 19), scheme.nrToZeroCm, decimal(scheme.nrToZeroCm, 2));
    setNumber(getCell(rows[30], 10), 0, "0");
    const metadata = project.metadata || {};
    setString(getCell(rows[35], 13), metadata.schemeObservationPeriod || "");
    setString(getCell(rows[37], 7), "Seca");
    setString(getCell(rows[37], 11), "Cheia");
    const uncheckedRegimeStyle = getCellStyle(getCell(rows[37], 9));
    const checkedRegimeStyle = getCellStyle(getCell(rows[37], 13));
    const regime = root.C32Calc.normName(metadata.riverRegime || "");
    setCellStyle(getCell(rows[37], 9), regime.includes("SECA") ? checkedRegimeStyle : uncheckedRegimeStyle);
    setCellStyle(getCell(rows[37], 13), regime.includes("CHEIA") ? checkedRegimeStyle : uncheckedRegimeStyle);
    setString(getCell(rows[39], 3), metadata.bottomNature ? `Natureza do fundo no local de instalação do Linígrafo: ${metadata.bottomNature}` : "");
    setString(getCell(rows[41], 3), metadata.observerContact ? `Nome e endereço do Responsável pelas Observações: ${metadata.observerContact}` : "");
    setString(getCell(rows[43], 3), metadata.otherInformation ? `Outras Informações: ${metadata.otherInformation}` : "");
    if (hasGraphic) {
      const extraRows = insertExpandedSchemeRows(schemeTable, rnLevels.length);
      clearLegacySchemeDrawing(schemeTable);
      attachSchemeGraphic(schemeTable, graphic);
      const sheetName = attr(schemeTable, NS.table, "name");
      attr(schemeTable, NS.table, "print-ranges", `$${sheetName}.$A$1:$X$${44 + extraRows}`);
    } else compactUnusedRnSlots(schemeTable, rnLevels.length);
    const oldName = attr(schemeTable, NS.table, "name");
    const newName = `ESQUEMA_DE_COTAS_(${safeStation})`.replace(/[\\/:?*\[\]]/g, "-").slice(0, 31);
    attr(schemeTable, NS.table, "name", newName || oldName);
    const printRange = attr(schemeTable, NS.table, "print-ranges");
    if (printRange) attr(schemeTable, NS.table, "print-ranges", printRange.split(oldName).join(newName || oldName));
    return { oldName, newName: newName || oldName };
  }

  function populateFooter(table, calculatedBy, checkedBy) {
    const rows = expandRows(table);
    const totalIndex = findRow(rows, "Somatório");
    if (totalIndex < 0 || !rows[totalIndex + 1]) return;
    setString(getCell(rows[totalIndex + 1], 10), calculatedBy || "");
    setString(getCell(rows[totalIndex + 1], 19), checkedBy || "");
  }

  function updateClosureCells(idaTable, voltaTable, idaTotalRow, voltaTotalRow, calculation) {
    for (const [table, ownTotal, otherTableName, otherTotal] of [
      [idaTable, idaTotalRow, "VOLTA", voltaTotalRow],
      [voltaTable, voltaTotalRow, "IDA", idaTotalRow]
    ]) {
      const rows = expandRows(table);
      const side = findRow(rows, "Diferença Desnível IDA / VOLTA");
      if (side < 0) continue;
      const valueRow = side + 3;
      if (rows[valueRow]) {
        const formula = `of:=[.V${ownTotal}]+[${otherTableName}.V${otherTotal}]`;
        const value = calculation.closure && calculation.closure.errorMm !== undefined ? calculation.closure.errorMm : null;
        setNumber(getCell(rows[valueRow], 22), value, value == null ? "" : String(value), formula);
      }
    }
  }

  function updateMeta(zip, project) {
    const entry = zip.file("meta.xml");
    if (!entry) return Promise.resolve();
    return entry.async("string").then((xml) => {
      const parser = new DOMParser();
      const document = parser.parseFromString(xml, "application/xml");
      const titles = document.getElementsByTagNameNS("http://purl.org/dc/elements/1.1/", "title");
      if (titles.length) titles[0].textContent = `C-32 ${project.station.name}`;
      zip.file("meta.xml", new XMLSerializer().serializeToString(document));
    });
  }

  function updateSettings(zip, oldSheetName, newSheetName) {
    if (!oldSheetName || !newSheetName || oldSheetName === newSheetName) return Promise.resolve();
    const entry = zip.file("settings.xml");
    if (!entry) return Promise.resolve();
    return entry.async("string").then((xml) => {
      zip.file("settings.xml", xml.split(oldSheetName).join(newSheetName));
    });
  }

  async function createSchemeGraphic(project, scheme, options) {
    if (options && options.schemeGraphicBytes) {
      return {
        data: options.schemeGraphicBytes,
        mediaType: options.schemeGraphicMediaType || "image/png",
        width: Number(options.schemeGraphicWidth) || 2048,
        height: Number(options.schemeGraphicHeight) || 1299
      };
    }
    if (!root.C32SchemeImage) return null;
    if (typeof root.C32SchemeImage.generatePng === "function" && root.document && root.Image) {
      const built = root.C32SchemeImage.buildSvg(project, scheme);
      const width = 1047;
      const height = Math.max(1, Math.round(width * built.height / built.width));
      const bytes = await root.C32SchemeImage.generatePng(project, scheme, { width, height });
      return { data: bytes, mediaType: "image/png", width, height };
    }
    if (typeof root.C32SchemeImage.buildSvg === "function") {
      const built = root.C32SchemeImage.buildSvg(project, scheme);
      const widthCm = 18.6;
      const heightCm = widthCm * built.height / built.width;
      const svg = built.svg.replace(
        `width="${built.width}" height="${built.height}"`,
        `width="${widthCm.toFixed(2)}cm" height="${heightCm.toFixed(2)}cm"`
      );
      return { data: svg, mediaType: "image/svg+xml", width: built.width, height: built.height };
    }
    return null;
  }

  async function loadTemplate(options) {
    if (options && options.templateBytes) return options.templateBytes;
    if (root.C32_TEMPLATE_BASE64) {
      const binary = atob(root.C32_TEMPLATE_BASE64);
      const bytes = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
      return bytes;
    }
    const response = await fetch("templates/c32_template.ods");
    if (!response.ok) throw new Error("Não foi possível carregar o modelo C-32 interno.");
    return new Uint8Array(await response.arrayBuffer());
  }

  async function generate(project, calculation, options) {
    if (!root.JSZip) throw new Error("Componente de compactação indisponível.");
    const templateBytes = await loadTemplate(options || {});
    const zip = await root.JSZip.loadAsync(templateBytes);
    const contentEntry = zip.file("content.xml");
    if (!contentEntry) throw new Error("O modelo C-32 não possui content.xml.");
    const xml = await contentEntry.async("string");
    const document = new DOMParser().parseFromString(xml, "application/xml");
    if (document.getElementsByTagName("parsererror").length) throw new Error("O conteúdo XML do modelo C-32 está inválido.");
    const cover = findTable(document, "Capa");
    const ida = findTable(document, "IDA");
    const volta = findTable(document, "VOLTA");
    const schemeTable = findTable(document, (table) => String(attr(table, NS.table, "name") || "").includes("ESQUEMA"));
    if (!cover || !ida || !volta || !schemeTable) throw new Error("O modelo C-32 não contém todas as abas esperadas.");
    populateCover(cover, project);
    populateHeader(ida, volta, project);
    const idaLayout = populateRun(ida, project.ida.lances, calculation.ida);
    const voltaLayout = populateRun(volta, project.volta.lances, calculation.volta);
    populateFooter(ida, project.metadata.calculatedBy, project.metadata.checkedBy);
    populateFooter(volta, project.metadata.calculatedBy, project.metadata.checkedBy);
    updateClosureCells(ida, volta, idaLayout.totalRowNumber, voltaLayout.totalRowNumber, calculation);
    const schemeGraphic = await createSchemeGraphic(project, calculation.scheme, options || {});
    const schemeNames = populateScheme(schemeTable, project, calculation.scheme, schemeGraphic);
    zip.file("content.xml", new XMLSerializer().serializeToString(document));
    await Promise.all([
      updateMeta(zip, project),
      updateSettings(zip, schemeNames.oldName, schemeNames.newName)
    ]);
    zip.file("mimetype", "application/vnd.oasis.opendocument.spreadsheet", { compression: "STORE" });
    return zip.generateAsync({
      type: "uint8array",
      compression: "DEFLATE",
      compressionOptions: { level: 6 },
      mimeType: "application/vnd.oasis.opendocument.spreadsheet"
    });
  }

  const api = {
    NS,
    pad4,
    decimal,
    generate
  };

  root.C32Ods = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
