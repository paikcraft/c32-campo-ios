(function (root) {
  "use strict";

  let projectReceiver = null;
  let resultReceiver = null;
  let levelingWakeRequested = false;
  let screenWakeLock = null;

  async function updateScreenWakeLock() {
    const shouldHold = Boolean(levelingWakeRequested && root.document && root.document.visibilityState === "visible");
    if (!shouldHold) {
      if (screenWakeLock) { try { await screenWakeLock.release(); } catch (_) {} }
      screenWakeLock = null;
      return false;
    }
    if (screenWakeLock && !screenWakeLock.released) return true;
    if (!root.navigator || !root.navigator.wakeLock || typeof root.navigator.wakeLock.request !== "function") return false;
    try {
      screenWakeLock = await root.navigator.wakeLock.request("screen");
      if (screenWakeLock && typeof screenWakeLock.addEventListener === "function") {
        screenWakeLock.addEventListener("release", () => { screenWakeLock = null; });
      }
      return true;
    } catch (_) {
      screenWakeLock = null;
      return false;
    }
  }

  if (root.document && typeof root.document.addEventListener === "function") {
    root.document.addEventListener("visibilitychange", () => { updateScreenWakeLock(); });
  }

  function hasBridge() {
    return Boolean(root.AndroidBridge && typeof root.AndroidBridge.saveFile === "function");
  }

  function bytesToBase64(bytes) {
    let binary = "";
    const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const chunk = 0x8000;
    for (let i = 0; i < view.length; i += chunk) {
      binary += String.fromCharCode.apply(null, view.subarray(i, i + chunk));
    }
    return btoa(binary);
  }

  function base64ToBytes(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  function textToBase64(text) {
    return bytesToBase64(new TextEncoder().encode(String(text)));
  }

  function base64ToText(base64) {
    return new TextDecoder("utf-8").decode(base64ToBytes(base64));
  }

  function saveFile(name, mimeType, data) {
    const bytes = typeof data === "string" ? new TextEncoder().encode(data) : (data instanceof Uint8Array ? data : new Uint8Array(data));
    if (hasBridge()) {
      root.AndroidBridge.saveFile(name, mimeType, bytesToBase64(bytes));
      return true;
    }
    const blob = new Blob([bytes], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = name;
    anchor.rel = "noopener";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    return true;
  }

  function shareFile(name, mimeType, data) {
    const bytes = typeof data === "string" ? new TextEncoder().encode(data) : (data instanceof Uint8Array ? data : new Uint8Array(data));
    if (hasBridge() && typeof root.AndroidBridge.shareFile === "function") {
      root.AndroidBridge.shareFile(name, mimeType, bytesToBase64(bytes));
      return true;
    }
    if (typeof File === "function" && root.navigator && typeof root.navigator.share === "function") {
      const file = new File([bytes], name, { type: mimeType, lastModified: Date.now() });
      const shareData = { files: [file], title: name };
      const supported = typeof root.navigator.canShare !== "function" || root.navigator.canShare(shareData);
      if (supported) {
        root.navigator.share(shareData).catch((error) => {
          if (error && error.name === "AbortError") return;
          saveFile(name, mimeType, bytes);
          onNativeResult("share", false, "O compartilhamento não abriu; o arquivo foi preparado para download.");
        });
        return true;
      }
    }
    saveFile(name, mimeType, bytes);
    return false;
  }

  function setLevelingActive(active) {
    levelingWakeRequested = Boolean(active);
    if (hasBridge() && typeof root.AndroidBridge.setLevelingActive === "function") {
      root.AndroidBridge.setLevelingActive(levelingWakeRequested);
      return true;
    }
    // A linha 2.1.0 usa um WebView estável sem ponte de energia. O Screen Wake Lock
    // é a API nativa do navegador/WebView para impedir o apagamento por inatividade,
    // sem WAKE_LOCK permanente nem permissão sensível. É liberado no background.
    updateScreenWakeLock();
    return Boolean(root.navigator && root.navigator.wakeLock);
  }

  function openProject(receiver) {
    projectReceiver = receiver;
    if (hasBridge() && typeof root.AndroidBridge.openProject === "function") {
      root.AndroidBridge.openProject();
      return;
    }
    const input = document.getElementById("project-file-input");
    if (input) input.click();
  }

  function openFile(receiver) {
    projectReceiver = receiver;
    if (hasBridge() && typeof root.AndroidBridge.openProject === "function") {
      root.AndroidBridge.openProject();
      return;
    }
    const input = document.getElementById("v2-file-input");
    if (input) input.click();
  }

  function receiveProject(base64, encodedName) {
    try {
      const bytes = base64ToBytes(base64);
      const text = new TextDecoder("utf-8").decode(bytes);
      const name = encodedName ? base64ToText(encodedName) : "projeto.project";
      if (projectReceiver) projectReceiver(null, text, name, bytes);
    } catch (error) {
      if (projectReceiver) projectReceiver(error);
    }
  }

  function onNativeResult(action, success, message) {
    if (resultReceiver) resultReceiver(action, Boolean(success), message || "");
    document.dispatchEvent(new CustomEvent("c32-native-result", { detail: { action, success: Boolean(success), message: message || "" } }));
  }

  function setResultReceiver(receiver) {
    resultReceiver = receiver;
  }

  const api = {
    hasBridge,
    bytesToBase64,
    base64ToBytes,
    textToBase64,
    base64ToText,
    saveFile,
    shareFile,
    setLevelingActive,
    openProject,
    openFile,
    receiveProject,
    onNativeResult,
    setResultReceiver
  };

  root.C32Native = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
