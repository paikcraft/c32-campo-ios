(function (root) {
  "use strict";

  if (!("serviceWorker" in root.navigator)) return;
  if (!/^https?:$/.test(root.location.protocol)) return;

  const register = () => {
    root.navigator.serviceWorker.register("service-worker.js", { scope: "./" }).catch(() => {
      // O aplicativo continua funcional on-line se o navegador bloquear o cache offline.
    });
  };
  if (root.document.readyState === "complete") register();
  else root.addEventListener("load", register, { once: true });
})(window);
