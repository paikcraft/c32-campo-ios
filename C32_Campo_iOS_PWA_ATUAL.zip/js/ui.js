(function (root) {
  "use strict";

  const state = {
    screen: "home",
    project: null,
    calculation: null,
    activeRun: "ida",
    busy: false,
    busyAction: "",
    toastTimer: null,
    settings: null,
    undoStack: [],
    redoStack: [],
    editSession: null,
    structureDirty: false,
    referenceNamesDirty: false,
    ptTopologyDirty: false,
    pendingRenameHints: [],
    lastSyncedIdaSignature: null,
    historyLimit: 60,
    runViewport: { ida: null, volta: null }
  };

  const app = document.getElementById("app");

  function esc(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function getPath(object, path) {
    return String(path).split(".").reduce((value, key) => value == null ? undefined : value[key], object);
  }

  function setPath(object, path, value) {
    const parts = String(path).split(".");
    const last = parts.pop();
    const target = parts.reduce((current, key) => current[key], object);
    target[last] = value;
  }

  function runtimeSnapshot() {
    return {
      project: state.project ? root.C32Model.cloneProject(state.project) : null,
      structureDirty: Boolean(state.structureDirty),
      referenceNamesDirty: Boolean(state.referenceNamesDirty),
      ptTopologyDirty: Boolean(state.ptTopologyDirty),
      pendingRenameHints: JSON.parse(JSON.stringify(state.pendingRenameHints || [])),
      lastSyncedIdaSignature: state.lastSyncedIdaSignature
    };
  }

  function snapshotsEqual(a, b) {
    const clean = (snapshot) => {
      const copy = JSON.parse(JSON.stringify(snapshot));
      if (copy && copy.project) delete copy.project.updatedAt;
      return copy;
    };
    return JSON.stringify(clean(a)) === JSON.stringify(clean(b));
  }

  function restoreRuntime(snapshot) {
    if (!snapshot) return;
    state.project = snapshot.project ? root.C32Model.cloneProject(snapshot.project) : null;
    state.structureDirty = Boolean(snapshot.structureDirty);
    state.referenceNamesDirty = Boolean(snapshot.referenceNamesDirty);
    state.ptTopologyDirty = Boolean(snapshot.ptTopologyDirty);
    state.pendingRenameHints = JSON.parse(JSON.stringify(snapshot.pendingRenameHints || []));
    state.lastSyncedIdaSignature = snapshot.lastSyncedIdaSignature || null;
    state.editSession = null;
    if (state.project) saveDraft();
    recalculate();
  }

  function refreshHistoryButtons() {
    const undoButton = app && app.querySelector ? app.querySelector('[data-action="undo"]') : null;
    const redoButton = app && app.querySelector ? app.querySelector('[data-action="redo"]') : null;
    if (undoButton) undoButton.disabled = state.undoStack.length === 0;
    if (redoButton) redoButton.disabled = state.redoStack.length === 0;
  }

  function pushHistory(label, before, after, kind, meta) {
    if (!before || !after || snapshotsEqual(before, after)) return false;
    const extra = meta && typeof meta === "object" ? meta : {};
    state.undoStack.push({
      label: label || "Alteração",
      before,
      after,
      kind: kind || "edit",
      transactionId: extra.transactionId || null
    });
    if (state.undoStack.length > state.historyLimit) state.undoStack.shift();
    state.redoStack = [];
    refreshHistoryButtons();
    return true;
  }

  function performProjectAction(label, mutator, kind, meta) {
    const before = runtimeSnapshot();
    const result = mutator();
    if (result === false) return false;
    const after = runtimeSnapshot();
    pushHistory(label, before, after, kind, meta);
    return result === undefined ? true : result;
  }

  function refreshLatestStructuralHistoryAfter() {
    const latest = state.undoStack[state.undoStack.length - 1];
    if (latest && latest.kind === "structural") latest.after = runtimeSnapshot();
  }

  function undoAction() {
    const entry = state.undoStack.pop();
    if (!entry) return;
    state.redoStack.push(entry);
    restoreRuntime(entry.before);
    render();
    showToast(`Desfeito: ${entry.label}`);
  }

  function redoAction() {
    const entry = state.redoStack.pop();
    if (!entry) return;
    state.undoStack.push(entry);
    restoreRuntime(entry.after);
    render();
    showToast(`Refeito: ${entry.label}`);
  }

  function resetRuntimeStateForProject() {
    state.undoStack = [];
    state.redoStack = [];
    state.editSession = null;
    state.pendingRenameHints = [];
    state.referenceNamesDirty = false;
    state.ptTopologyDirty = false;
    state.runViewport = { ida: null, volta: null };
    if (!state.project) {
      state.structureDirty = false;
      state.lastSyncedIdaSignature = null;
      return;
    }
    const signature = root.C32Model.structureSignature(state.project.ida && state.project.ida.lances);
    const automatic = state.project.volta && state.project.volta.routeMode === "auto";
    const matches = automatic && root.C32Model.isReverseSkeleton(state.project.ida.lances, state.project.volta.lances);
    state.referenceNamesDirty = !root.C32Model.referenceSequencesMatch(state.project.ida.lances, state.project.volta.lances);
    state.ptTopologyDirty = automatic && !root.C32Model.isReversePtTopology(state.project.ida.lances, state.project.volta.lances);
    state.structureDirty = state.referenceNamesDirty || state.ptTopologyDirty;
    state.lastSyncedIdaSignature = matches ? signature : null;
  }

  function transactionId(prefix) {
    return `${prefix || "tx"}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function acquisitionStateForLance(lance) {
    return root.C32Model.acquisitionFingerprint(lance);
  }

  function queueRenameHint(oldName, newName, affectedIndexes, txId) {
    const oldNorm = root.C32Calc.normName(oldName);
    const newText = String(newName == null ? "" : newName).trim();
    const newNorm = root.C32Calc.normName(newText);
    if (!oldNorm || !newNorm || oldNorm === newNorm) return null;
    const idaLances = state.project && state.project.ida ? state.project.ida.lances : [];
    const indexes = Array.from(new Set((affectedIndexes || []).filter((index) => Number.isInteger(index) && idaLances[index])));
    const affectedLanceIds = indexes.map((index) => idaLances[index].id).filter(Boolean);
    const baselineAcquisition = {};
    for (const index of indexes) {
      const lance = idaLances[index];
      if (lance && lance.id) baselineAcquisition[lance.id] = acquisitionStateForLance(lance);
    }

    const chained = state.pendingRenameHints.find((hint) => root.C32Calc.normName(hint.newName) === oldNorm);
    if (chained) {
      chained.newName = newText;
      chained.affectedLanceIds = Array.from(new Set([...(chained.affectedLanceIds || []), ...affectedLanceIds]));
      chained.baselineAcquisition = Object.assign({}, baselineAcquisition, chained.baselineAcquisition || {});
      if (root.C32Calc.normName(chained.oldName) === newNorm) {
        state.pendingRenameHints = state.pendingRenameHints.filter((item) => item !== chained);
        return null;
      }
      return chained;
    }

    const hint = {
      oldName: String(oldName),
      newName: newText,
      affectedLanceIds,
      baselineAcquisition,
      transactionId: txId || transactionId("rename")
    };
    state.pendingRenameHints.push(hint);
    state.pendingRenameHints = state.pendingRenameHints.filter((item) => root.C32Calc.normName(item.oldName) !== root.C32Calc.normName(item.newName));
    return hint;
  }

  function renameHintHasAcquisitionChanged(hint) {
    const idaLances = state.project && state.project.ida ? state.project.ida.lances : [];
    const baseline = hint && hint.baselineAcquisition ? hint.baselineAcquisition : {};
    for (const lanceId of hint && hint.affectedLanceIds || []) {
      const lance = idaLances.find((item) => item && item.id === lanceId);
      if (!lance) continue;
      if (acquisitionStateForLance(lance) !== String(baseline[lanceId] == null ? "" : baseline[lanceId])) return true;
    }
    return false;
  }

  function effectiveRenameHints() {
    return (state.pendingRenameHints || []).map((hint) => Object.assign({}, hint, {
      physicalChange: renameHintHasAcquisitionChanged(hint)
    }));
  }

  function pendingRenameTransactionForPath(path) {
    const match = String(path || "").match(/^ida\.lances\.(\d+)\./);
    if (!match || !state.project || !state.project.ida) return null;
    const lance = state.project.ida.lances[Number(match[1])];
    if (!lance) return null;
    const hint = [...(state.pendingRenameHints || [])].reverse().find((item) => (item.affectedLanceIds || []).includes(lance.id));
    return hint ? hint.transactionId : null;
  }

  function coalesceRenameHistory(hints, label, afterSnapshot) {
    const txIds = new Set((hints || []).map((hint) => hint.transactionId).filter(Boolean));
    if (!txIds.size) return false;
    const indexes = [];
    state.undoStack.forEach((entry, index) => { if (txIds.has(entry.transactionId)) indexes.push(index); });
    if (!indexes.length) return false;
    const first = Math.min(...indexes);
    for (let index = first; index < state.undoStack.length; index += 1) {
      if (!txIds.has(state.undoStack[index].transactionId)) return false;
    }
    const before = state.undoStack[first].before;
    state.undoStack.splice(first);
    state.undoStack.push({
      label: label || "Atualizar referência",
      before,
      after: afterSnapshot,
      kind: "structural",
      transactionId: Array.from(txIds)[0] || null
    });
    state.redoStack = [];
    return true;
  }

  function markIdaStructureDirty(kind) {
    if (kind === "reference") {
      state.structureDirty = true;
      state.referenceNamesDirty = true;
      return;
    }
    // v0.1.14: PTs da IDA e da VOLTA representam caminhos de campo independentes.
    // Alterar/inserir/excluir PT na IDA não agenda reconstrução da VOLTA.
    state.ptTopologyDirty = false;
  }

  function markVoltaPtTopologyCustomized() {
    if (!state.project || !state.project.volta) return;
    state.project.volta.routeMode = "manual";
    state.lastSyncedIdaSignature = null;
  }

  function propagateAdjacentPointRename(runName, index, side, oldName, newName) {
    const run = state.project && state.project[runName];
    const lances = run && Array.isArray(run.lances) ? run.lances : [];
    const affected = [index];
    if (root.C32Calc.sameName(oldName, newName)) return affected;
    const oldClean = root.C32Calc.cleanName(oldName);
    if (side === "to" && lances[index + 1]) {
      const adjacent = lances[index + 1].from;
      if (root.C32Calc.sameName(adjacent, oldName) || (!oldClean && !root.C32Calc.cleanName(adjacent))) {
        lances[index + 1].from = newName;
        affected.push(index + 1);
      }
    }
    if (side === "from" && lances[index - 1]) {
      const adjacent = lances[index - 1].to;
      if (root.C32Calc.sameName(adjacent, oldName) || (!oldClean && !root.C32Calc.cleanName(adjacent))) {
        lances[index - 1].to = newName;
        affected.push(index - 1);
      }
    }
    return affected;
  }

  function recalculate() {
    state.calculation = state.project ? root.C32Calc.calculateProject(state.project) : null;
    return state.calculation;
  }

  function currentCriteria() {
    if (!state.settings) state.settings = root.C32Storage.loadSettings() || {};
    if (state.project) {
      state.project.criteria = root.C32Model.normalizeCriteria(state.project.criteria);
      return state.project.criteria;
    }
    state.settings.criteria = root.C32Model.normalizeCriteria(state.settings.criteria);
    return state.settings.criteria;
  }

  function saveCriteriaValue(key, value) {
    if (!state.settings) state.settings = {};
    const target = state.project ? state.project.criteria : state.settings.criteria;
    target[key] = value;
    state.settings.criteria = Object.assign({}, target);
    root.C32Storage.saveSettings(state.settings);
    if (state.project) saveDraft();
  }

  function createProject(existing) {
    const project = root.C32Model.createProject("", existing);
    project.criteria = root.C32Model.normalizeCriteria(currentCriteria());
    return project;
  }

  function saveDraft() {
    if (!state.project) return;
    root.C32Model.touch(state.project);
    root.C32Storage.saveDraft(state.project);
  }

  function showToast(message, type) {
    const toast = document.getElementById("toast");
    if (!toast) return;
    toast.textContent = message;
    toast.className = `toast show${type === "error" ? " error" : ""}`;
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => { toast.className = "toast"; }, 3300);
  }

  function askActionConfirmation(message, confirmLabel) {
    return new Promise((resolve) => {
      const backdrop = document.createElement("div");
      backdrop.className = "action-dialog-backdrop";
      backdrop.innerHTML = `<div class="action-dialog" role="dialog" aria-modal="true"><div class="action-dialog-message"></div><div class="action-dialog-buttons"><button class="secondary" data-dialog-action="cancel">CANCELAR</button><button class="danger" data-dialog-action="confirm"></button></div></div>`;
      backdrop.querySelector(".action-dialog-message").textContent = String(message || "");
      backdrop.querySelector('[data-dialog-action="confirm"]').textContent = String(confirmLabel || "ATUALIZAR E LIMPAR");
      const finish = (accepted, fromHistory) => {
        document.removeEventListener("keydown", onKey);
        backdrop.remove();
        if (!fromHistory && root.history && root.history.state && root.history.state.c32Dialog) root.history.back();
        resolve(Boolean(accepted));
      };
      backdrop._c32FinishFromHistory = () => finish(false, true);
      const onKey = (event) => { if (event.key === "Escape") finish(false); };
      backdrop.addEventListener("click", (event) => {
        const action = event.target && event.target.dataset ? event.target.dataset.dialogAction : "";
        if (action === "cancel") finish(false);
        if (action === "confirm") finish(true);
      });
      document.addEventListener("keydown", onKey);
      document.body.appendChild(backdrop);
      if (root.history && typeof root.history.pushState === "function") {
        root.history.pushState({ c32: true, c32Dialog: true, screen: state.screen, depth: Number(root.history.state?.depth || 0) + 1 }, "");
      }
      requestAnimationFrame(() => backdrop.querySelector('[data-dialog-action="cancel"]')?.focus());
    });
  }

  function renderBadge(status, detail) {
    const css = status === "OK" ? "ok" : status === "ERRO" ? "error" : "pending";
    const icon = status === "OK" ? "✓" : status === "ERRO" ? "!" : "—";
    const suffix = detail ? ` · ${esc(detail)}` : "";
    return `<b class="badge ${css}">${icon}&nbsp; ${esc(status)}${suffix}</b>`;
  }

  function renderStandardBadge(indicator) {
    const detail = indicator && Number.isFinite(indicator.differenceMm)
      ? `${root.C32Ods.decimal(indicator.differenceMm, 1)} mm`
      : "";
    return renderBadge(indicator ? indicator.status : "—", detail);
  }

  function appBar(title, subtitle, backAction, menuOnly) {
    return `<header class="appbar">
      ${backAction ? `<button class="icon-btn" data-action="navigate-back" data-back-target="${esc(backAction)}" aria-label="Voltar">‹</button>` : ""}
      <div class="appbar-title"><strong>${esc(title)}</strong><small>${esc(subtitle || "C32 Campo")}</small></div>
      <div class="project-actions">
        <button class="project-action menu-action" data-v2-open-menu="1" aria-label="Abrir menu e Banco de Estações">☰</button>
        ${!menuOnly && state.project ? `<button class="project-action history-action" data-action="undo" aria-label="Desfazer última ação" ${state.undoStack.length ? "" : "disabled"}>↶</button><button class="project-action history-action" data-action="redo" aria-label="Refazer ação" ${state.redoStack.length ? "" : "disabled"}>↷</button><button class="project-action" data-action="save-project" aria-label="Salvar projeto atual">SALVAR</button>` : ""}
        ${!menuOnly ? `<button class="project-action" data-action="open-project" aria-label="Carregar outro projeto">CARREGAR</button>` : ""}
      </div>
    </header>`;
  }

  function institutionalMarks() {
    return `<div class="institutional-marks" aria-label="Identidade institucional">
      <img class="round-mark" src="images/marca_mb.png" alt="Marca da Marinha do Brasil">
      <img src="images/brasao_ssn9.png" alt="Brasão institucional">
    </div>`;
  }

  function authorFooter() {
    return `<footer class="author-footer">
      <img src="images/bode_verde.png" alt="" aria-hidden="true">
      <span><strong>2ºSG-HN Soares</strong><small>CHN-9 / 2026</small></span>
    </footer>`;
  }

  function shell(content, bar, sticky) {
    return `<div class="shell">${bar || ""}${content}${authorFooter()}${sticky || ""}</div>`;
  }

  function field(label, path, options) {
    const config = options || {};
    const value = state.project ? getPath(state.project, path) : "";
    const tag = config.multiline ? "textarea" : "input";
    const attributes = [
      `data-path="${esc(path)}"`,
      config.type ? `type="${config.type}"` : "",
      config.inputmode ? `inputmode="${config.inputmode}"` : "",
      config.placeholder ? `placeholder="${esc(config.placeholder)}"` : "",
      config.acq ? "data-acq-input=\"1\" enterkeyhint=\"next\"" : "",
      config.point ? "data-point-input=\"1\"" : "",
      config.readonly ? "readonly aria-readonly=\"true\"" : "",
      config.maxlength ? `maxlength="${config.maxlength}"` : ""
    ].filter(Boolean).join(" ");
    const control = tag === "textarea"
      ? `<textarea ${attributes}>${esc(value || "")}</textarea>`
      : `<input ${attributes} value="${esc(value || "")}">`;
    return `<div class="field ${config.className || ""}"><label>${esc(label)}</label>${control}${config.help ? `<small class="subtle">${esc(config.help)}</small>` : ""}</div>`;
  }

  function criteriaField(label, key, help) {
    const value = currentCriteria()[key];
    return `<div class="field"><label>${esc(label)}</label><input data-criteria-key="${esc(key)}" inputmode="decimal" type="number" min="0.01" step="0.01" value="${esc(value)}">${help ? `<small class="subtle">${esc(help)}</small>` : ""}</div>`;
  }

  function filenameBase() {
    const station = root.C32Calc.normName(state.project.station.name || "ESTACAO").replace(/[^A-Z0-9_-]+/g, "_").replace(/^_+|_+$/g, "");
    return `${station || "ESTACAO"}_${state.project.station.date || root.C32Model.today()}`;
  }

  function renderHome() {
    const draft = root.C32Storage.loadDraft();
    const navigatorInfo = root.navigator || {};
    const appleMobile = /iPad|iPhone|iPod/.test(navigatorInfo.userAgent || "")
      || (navigatorInfo.platform === "MacIntel" && Number(navigatorInfo.maxTouchPoints) > 1);
    const standalone = navigatorInfo.standalone === true
      || (typeof root.matchMedia === "function" && root.matchMedia("(display-mode: standalone)").matches);
    const installHint = !root.C32Native.hasBridge() && appleMobile && !standalone
      ? `<section class="card notice"><strong>Usando iPhone ou iPad?</strong><p class="subtle">No Safari, toque em Compartilhar e depois em “Adicionar à Tela de Início” para usar o C32 Campo como aplicativo e mantê-lo disponível offline.</p></section>`
      : "";
    app.innerHTML = shell(`<main class="content">
      <section class="hero">
        <div class="hero-heading"><img class="hero-mark" src="images/app_icon.png" alt="Ícone do C32 Campo"><div><h1>C32 - Campo 2.1</h1><p>Aquisição, conferência e geração da C-32 diretamente no nivelamento.</p></div></div>
        <div class="hero-author"><strong>2ºSG-HN Soares</strong><span>CHN-9 / 2026</span></div>
        <div class="version">Versão ${root.C32Model.APP_VERSION} · funcionamento totalmente offline</div>
      </section>
      <section class="card identity-card">${institutionalMarks()}</section>
      ${installHint}
      ${draft ? `<section class="card notice stack">
        <div><h3>Nivelamento não finalizado encontrado</h3><p><strong>${esc(draft.station.name || "Estação sem nome")}</strong></p><p class="subtle">Atualizado em ${esc(formatDateTime(draft.updatedAt))}</p></div>
        <div class="button-row"><button class="primary" data-action="continue-draft">CONTINUAR</button><button class="danger" data-action="discard-draft">DESCARTAR</button></div>
      </section>` : ""}
      <div class="stack">
        <button class="primary wide" data-action="new-project">NOVO NIVELAMENTO</button>
        ${state.project ? `<button class="secondary wide" data-action="save-project">SALVAR PROJETO ATUAL</button>` : ""}
        <button class="secondary wide" data-action="open-project">CARREGAR PROJETO</button>
        <button class="secondary wide" data-action="settings">CONFIGURAÇÕES E SOBRE</button>
      </div>
    </main>`, appBar("C32 Campo", "Início", "", true));
  }

  function renderStationChoice() {
    app.innerHTML = shell(`<main class="content">
      <section class="card"><h2>Estação existente?</h2><p class="subtle">Para usar uma estação cadastrada, abra o Banco de Estações pelo menu ☰ da barra superior.</p></section>
      <section class="choice-grid stack">
        <button class="choice-card" data-action="choose-existing" data-existing="true"><strong>SIM</strong><small>Informarei as relações conhecidas entre RNs antes do nivelamento.</small></button>
        <button class="choice-card" data-action="choose-existing" data-existing="false"><strong>NÃO</strong><small>Começarei a IDA e a VOLTA livremente, sem padrão histórico.</small></button>
      </section>
    </main>`, appBar("Novo nivelamento", "Escolha o tipo de estação", "home"));
  }

  function renderSetup() {
    const existing = state.project.station.existing;
    const references = state.project.station.references || [];
    app.innerHTML = shell(`<main class="content">
      <section class="card form-grid">
        ${field("Nome da estação", "station.name", { className: "span-2", placeholder: "Ex.: HUMAITÁ-AM" })}
        ${field("Data", "station.date", { type: "date" })}
        <div class="field"><label>Estação existente</label><input value="${existing ? "SIM" : "NÃO"}" disabled></div>
      </section>
      ${existing ? `<section class="card stack"><div><h2>Relações conhecidas</h2><p class="subtle">Convenção fixa: o ponto da esquerda está acima do ponto da direita.</p></div>
        <div id="references">${references.map(renderReference).join("") || `<p class="subtle">Adicione ao menos uma referência conhecida.</p>`}</div>
        <button class="secondary wide" data-action="add-reference">+ ADICIONAR REFERÊNCIA</button>
      </section>` : `<section class="card notice"><p>Nenhuma RN ou sequência será criada automaticamente. Os nomes serão digitados conforme o nivelamento executado.</p></section>`}
      <section class="card notice warning"><strong>PADRÃO</strong><p class="subtle">A comparação usa o limite configurado de ${root.C32Ods.decimal(currentCriteria().standardToleranceMm, 2)} mm, exclusivamente nesse indicador.</p></section>
    </main>`, appBar("Dados iniciais", existing ? "Referências da estação" : "Estação nova", "station-choice"),
    `<div class="sticky-actions"><button class="primary" data-action="begin-acquisition">INICIAR NIVELAMENTO</button></div>`);
  }

  function renderReference(reference, index) {
    return `<div class="reference">
      <div class="field"><label>Mais alto</label><input data-path="station.references.${index}.high" value="${esc(reference.high || "")}" placeholder="RN2-CPRM"></div>
      <div class="arrow">→</div>
      <div class="field"><label>Mais baixo</label><input data-path="station.references.${index}.low" value="${esc(reference.low || "")}" placeholder="RN1-CPRM"></div>
      <div class="field difference"><label>Desnível (cm)</label><input data-path="station.references.${index}.differenceCm" data-reference-cm="1" inputmode="decimal" value="${esc(reference.differenceCm || root.C32Model.metersToCentimetersText(reference.differenceM, 2) || "")}" placeholder="7,95"></div>
      <div class="row-tools"><button class="mini-btn" data-action="move-reference" data-index="${index}" data-direction="-1" aria-label="Subir">↑</button><button class="mini-btn" data-action="move-reference" data-index="${index}" data-direction="1" aria-label="Descer">↓</button><button class="mini-btn" data-action="delete-reference" data-index="${index}" aria-label="Excluir">×</button></div>
    </div>`;
  }

  function rulerTopologyStatus(runName, lances) {
    const items = Array.isArray(lances) ? lances : [];
    const occurrences = [];
    items.forEach((lance, index) => {
      if (root.C32Calc.isRulerPoint(lance && lance.from)) occurrences.push({ index, side: "from" });
      if (root.C32Calc.isRulerPoint(lance && lance.to)) occurrences.push({ index, side: "to" });
    });
    if (!occurrences.length) return { valid: true, hasRuler: false, occurrences };
    const expectedIndex = runName === "ida" ? items.length - 1 : 0;
    const expectedSide = runName === "ida" ? "to" : "from";
    const valid = occurrences.length === 1
      && occurrences[0].index === expectedIndex
      && occurrences[0].side === expectedSide;
    return { valid, hasRuler: true, occurrences };
  }

  function rulerTopologyMessage(runName) {
    return runName === "ida"
      ? "A Régua deve permanecer como ponto final da IDA. Use + ADICIONAR LANCE para inserir um novo ponto antes dela, ou + PT para inserir um apoio no lance."
      : "A Régua deve permanecer como ponto inicial da VOLTA. Use + ADICIONAR LANCE para inserir um novo ponto depois dela, ou + PT para inserir um apoio no primeiro lance.";
  }

  function renderAcquisition() {
    recalculate();
    const runName = state.activeRun;
    const lances = state.project[runName].lances;
    const runCalc = state.calculation[runName];
    // v2.1.2: IDA e VOLTA são exibidas na ordem operacional real, de cima para baixo.
    // Na VOLTA, o Lance 1 (Régua -> última referência) fica no topo. A troca IDA/VOLTA
    // encontra semanticamente o lance correspondente, em vez de inverter a lista visual.
    const visualIndexes = lances.map((_, index) => index);
    const cards = visualIndexes.map((index) => renderLance(lances[index], index, runName, runCalc.rows[index])).join("");
    const runNotice = runName === "ida"
      ? `<section class="card notice"><strong>IDA</strong><p class="subtle">Preencha SUPERIOR, INFERIOR e CENTRAL em milímetros. A IDA progride de cima para baixo. Os PTs pertencem ao caminho da IDA e não são impostos à VOLTA.</p></section>`
      : `<section class="card notice"><strong>VOLTA</strong><p class="subtle">A VOLTA aparece na ordem operacional: o Lance 1 fica no topo e o preenchimento progride para baixo. Ao alternar IDA/VOLTA, o C32 procura primeiro o lance inverso exato e, se os PTs forem diferentes, o ponto/trecho correspondente mais próximo. Os PTs da VOLTA são independentes da IDA.</p></section>`;
    const rulerStatus = rulerTopologyStatus(runName, lances);
    // v0.1.19: a Régua continua terminal na IDA, mas isso não elimina a capacidade
    // de ampliar o caminhamento. Quando ela já é terminal, ADICIONAR LANCE insere
    // um novo ponto ANTES da Régua em vez de criar um trecho depois dela.
    const canAppendIda = runName === "ida" && rulerStatus.valid;
    const canAppendVolta = runName === "volta" && rulerStatus.valid;
    const appendButton = canAppendIda || canAppendVolta || !lances.length
      ? `<button class="secondary wide" data-action="add-lance">+ ADICIONAR LANCE</button>`
      : "";
    app.innerHTML = shell(`${appBar("Nivelamento", state.project.station.name || "Estação sem nome", "setup")}
      <nav class="tabs"><button class="tab ${runName === "ida" ? "active" : ""}" data-action="switch-run" data-run="ida">IDA <span class="count">${state.project.ida.lances.length}</span></button><button class="tab ${runName === "volta" ? "active" : ""}" data-action="switch-run" data-run="volta">VOLTA <span class="count">${state.project.volta.lances.length}</span></button></nav>
      <main class="content">
        ${runNotice}
        <div class="lances stack">${cards || `<section class="card"><p class="subtle">Nenhum lance nesta etapa.</p></section>`}</div>
        ${appendButton}
      </main>`, "", `<div class="sticky-actions"><button class="secondary" data-action="metadata">DADOS C-32</button><button class="primary" data-action="summary">CONFERIR</button></div>`);
  }

  function renderLance(lance, index, runName, rowCalc) {
    const base = `${runName}.lances.${index}`;
    const indicator = runName === "volta" ? state.calculation.voltaIndicators[index] : null;
    return `<article class="card lance-card" id="lance-${runName}-${index}" data-lance-id="${esc(lance.id || "")}">
      <div class="lance-head"><strong>Lance ${index + 1}</strong><button class="mini-btn pt-btn" data-action="insert-pt" data-index="${index}" title="Dividir este lance com um ponto de apoio">+ PT</button><button class="mini-btn" data-action="delete-lance" data-index="${index}" title="Excluir lance">×</button></div>
      <div class="lance-body">
        <div class="points-grid">${field("PONTO AR", `${base}.from`, { acq: true, point: true, placeholder: "RN / PT" })}<div class="arrow">→</div>${field("PONTO AV", `${base}.to`, { acq: true, point: true, placeholder: "RN / PT" })}</div>
        <div class="reading-title"><strong>MIRA AR</strong><span id="ar-status-${index}">${readingMicro(rowCalc.ar, "AR")}</span></div>
        <div class="reading-grid">${readingField("SUPERIOR", `${base}.ar.sup`)}${readingField("INFERIOR", `${base}.ar.inf`)}${readingField("CENTRAL", `${base}.ar.cen`)}</div>
        <div class="reading-title"><strong>MIRA AV</strong><span id="av-status-${index}">${readingMicro(rowCalc.av, "AV")}</span></div>
        <div class="reading-grid">${readingField("SUPERIOR", `${base}.av.sup`)}${readingField("INFERIOR", `${base}.av.inf`)}${readingField("CENTRAL", `${base}.av.cen`)}</div>
        <div class="validation-line${runName === "volta" ? " volta-progress" : ""}" id="validation-${index}">${rowValidation(rowCalc, runName, index)}</div>
        ${indicator ? `<div class="indicator-panel"><div class="indicator"><span>IDA</span><span id="indicator-ida-${index}">${renderBadge(indicator.ida.status)}</span></div><div class="indicator"><span>PADRÃO</span><span id="indicator-standard-${index}">${renderStandardBadge(indicator.standard)}</span></div></div>` : ""}
        <details class="details"><summary>Visibilidade, vento e observação</summary><div class="form-grid">${field("Vis.", `${base}.visibility`, { acq: true })}${field("Vento", `${base}.wind`, { acq: true })}${field("Observações", `${base}.observation`, { multiline: true, className: "span-2" })}</div></details>
      </div>
    </article>`;
  }

  function readingField(label, path) {
    return `<div class="field"><label>${label}</label><input data-path="${path}" data-acq-input="1" data-reading-input="1" inputmode="numeric" pattern="[0-9]*" maxlength="4" enterkeyhint="next" value="${esc(getPath(state.project, path) || "")}" placeholder="0000"></div>`;
  }

  function readingMicro(reading, label) {
    if (!reading.complete) return `<span class="micro">${label} —</span>`;
    if (!reading.valid) return `<span class="micro error">${label} ERRO</span>`;
    if (reading.warnings.length) return `<span class="micro warning">${label} ALERTA</span>`;
    return `<span class="micro ok">${label} OK</span>`;
  }

  function signedMillimetres(value) {
    if (!Number.isFinite(value)) return "—";
    const sign = value > 0 ? "+" : "";
    return `${sign}${root.C32Ods.decimal(value, 1)} mm`;
  }

  function progressMicro(progress) {
    return {
      difference: progress && Number.isFinite(progress.idaDifferenceMm) ? signedMillimetres(progress.idaDifferenceMm) : "—",
      accumulated: progress && Number.isFinite(progress.accumulatedMm) ? signedMillimetres(progress.accumulatedMm) : "—"
    };
  }

  function rowValidation(row, runName, index) {
    if (!row.complete) return `<span class="micro">Aguardando leitura completa</span>`;
    const errors = row.issues.map((issue) => `<span class="micro error">${esc(issue)}</span>`).join("");
    const warnings = row.warnings.map((warning) => `<span class="micro warning">${esc(warning)}</span>`).join("");
    if (!row.valid) return errors + warnings;
    const vrfLimit = state.calculation && state.calculation.criteria ? state.calculation.criteria.vrfToleranceMm : currentCriteria().vrfToleranceMm;
    const quality = `${warnings}<span class="micro ok">VRF dentro de ${root.C32Ods.decimal(vrfLimit, 2)} mm</span><span class="micro">Distância do lance ${root.C32Ods.decimal(row.distanceM, 1)} m</span>`;
    const delta = `<span class="micro">Δ ${root.C32Ods.decimal(row.deltaMm, 1)} mm</span>`;
    if (runName !== "volta") return `${quality}${delta}`;
    const values = progressMicro(state.calculation && state.calculation.voltaProgress ? state.calculation.voltaProgress[index] : null);
    return `<span class="validation-quality">${quality}</span><span class="validation-progress-row">${delta}<span class="micro">Dif. IDA ${values.difference}</span><span class="micro">Acum. ${values.accumulated}</span></span>`;
  }

  function refreshLiveOutputs() {
    recalculate();
    const run = state.activeRun;
    const rows = state.calculation[run].rows;
    rows.forEach((row, index) => {
      const ar = document.getElementById(`ar-status-${index}`);
      const av = document.getElementById(`av-status-${index}`);
      const validation = document.getElementById(`validation-${index}`);
      if (ar) ar.innerHTML = readingMicro(row.ar, "AR");
      if (av) av.innerHTML = readingMicro(row.av, "AV");
      if (validation) validation.innerHTML = rowValidation(row, run, index);
      if (run === "volta") {
        const indicators = state.calculation.voltaIndicators[index];
        const ida = document.getElementById(`indicator-ida-${index}`);
        const standard = document.getElementById(`indicator-standard-${index}`);
        if (ida) ida.innerHTML = renderBadge(indicators.ida.status);
        if (standard) standard.innerHTML = renderStandardBadge(indicators.standard);
      }
    });
  }

  function renderSummary() {
    recalculate();
    const closing = state.calculation.closure;
    const errors = [
      ...state.calculation.ida.issues.map((item) => `IDA: ${item}`),
      ...state.calculation.volta.issues.map((item) => `VOLTA: ${item}`)
    ];
    const warnings = [
      ...state.calculation.ida.warnings.map((item) => `IDA: ${item}`),
      ...state.calculation.volta.warnings.map((item) => `VOLTA: ${item}`)
    ];
    if (closing.status === "ERRO" && closing.reason) errors.push(closing.reason);
    app.innerHTML = shell(`<main class="content stack">
      <section class="card"><h2>Conferência final</h2><div class="summary-grid">
        <div class="stat"><strong>${renderBadge(closing.status)}</strong><small>IDA × VOLTA</small></div>
        <div class="stat"><strong>${state.calculation.patternOk}</strong><small>Padrões OK</small></div>
        <div class="stat"><strong>${state.calculation.patternErrors}</strong><small>Padrões com erro</small></div>
      </div>
      ${closing.errorMm !== undefined ? `<p class="subtle">Fechamento: ${root.C32Ods.decimal(closing.errorMm, 2)} mm · tolerância ${root.C32Ods.decimal(closing.toleranceMm, 2)} mm · distância média ${root.C32Ods.decimal(closing.meanDistanceM, 2)} m</p>` : `<p class="subtle">${esc(closing.reason || "Dados insuficientes para o fechamento.")}</p>`}</section>
      ${errors.length ? `<section class="card notice error"><h3>Pontos a conferir</h3><ul class="error-list">${errors.map((item) => `<li>${esc(item)}</li>`).join("")}</ul><button class="secondary wide" data-action="acquisition">VOLTAR ÀS LEITURAS</button></section>` : `<section class="card notice"><strong>Leituras consistentes</strong><p class="subtle">Você ainda poderá editar qualquer lance antes de gerar a C-32.</p></section>`}
      ${warnings.length ? `<section class="card notice warning"><h3>Alertas de distância</h3><p class="subtle">Visadas acima de ${root.C32Ods.decimal(state.calculation.criteria.maxSightDistanceM, 2)} m são destacadas para conferência, mas não bloqueiam os cálculos, o esquema nem a C-32.</p><ul class="warning-list">${warnings.map((item) => `<li>${esc(item)}</li>`).join("")}</ul></section>` : ""}
      <section class="card"><h3>Próxima etapa</h3><p class="subtle">Selecione a RN principal e informe a relação com o NR ou a cota da referência.</p><button class="primary wide" data-action="scheme">CONFIGURAR ESQUEMA</button></section>
    </main>`, appBar("Conferência", state.project.station.name, "acquisition"));
  }

  function permanentPointNames() {
    const names = [];
    for (const lance of state.project.ida.lances) {
      for (const name of [lance.from, lance.to]) {
        const clean = root.C32Calc.cleanName(name);
        if (clean && !root.C32Calc.isTemporaryPoint(clean) && !root.C32Calc.isRulerPoint(clean) && !names.some((item) => root.C32Calc.sameName(item, clean))) names.push(clean);
      }
    }
    return names;
  }

  function renderScheme() {
    recalculate();
    const names = permanentPointNames();
    const scheme = state.calculation.scheme;
    const mode = state.project.scheme.inputMode;
    app.innerHTML = shell(`<main class="content stack">
      <section class="card"><h2>RN principal</h2><p class="subtle">A relação do esquema com o NR partirá da RN escolhida, mesmo que ela não seja a mais alta.</p><div class="radio-list">${names.map((name) => `<label class="radio-option"><input type="radio" name="principal" data-path="scheme.principalPoint" value="${esc(name)}" ${root.C32Calc.sameName(name, state.project.scheme.principalPoint) ? "checked" : ""}><span><strong>${esc(name)}</strong></span></label>`).join("") || `<p class="subtle">Informe RNs válidas na IDA para continuar.</p>`}</div></section>
      ${names.length > 4 ? `<section class="card notice"><strong>Esquema ampliado</strong><p class="subtle">As ${names.length} RNs permanentes serão mantidas. O desenho e a aba do ODS aumentam automaticamente para preservar a leitura.</p></section>` : ""}
      <section class="card form-grid"><div class="span-2"><h2>Referência do esquema</h2></div>
        <label class="radio-option span-2"><input type="radio" name="mode" data-path="scheme.inputMode" value="principalElevation" ${mode !== "stationNr" ? "checked" : ""}><span><strong>Informar cota da RN principal</strong><small class="subtle">O aplicativo calculará o NR.</small></span></label>
        <label class="radio-option span-2"><input type="radio" name="mode" data-path="scheme.inputMode" value="stationNr" ${mode === "stationNr" ? "checked" : ""}><span><strong>Informar NR da estação</strong><small class="subtle">O aplicativo calculará a cota da RN principal.</small></span></label>
        ${mode === "stationNr" ? field("NR da estação (cm)", "scheme.stationNrCm", { inputmode: "decimal", placeholder: "983,44" }) : field("Cota da RN principal em relação ao NR (m)", "scheme.principalElevationM", { inputmode: "decimal", placeholder: "16,2381" })}
        ${field("Topo da régua adotado (m)", "scheme.rulerTopM", { inputmode: "decimal", placeholder: "22,00" })}
        ${field("Observação da mira na régua", "scheme.rulerObservation", { multiline: true, className: "span-2", placeholder: "A mira foi colocada no topo da régua..." })}
      </section>
      ${renderSchemePreview(scheme)}
      ${scheme.errors && scheme.errors.length ? `<section class="card notice error"><h3>Esquema ainda incompleto</h3><ul class="error-list">${scheme.errors.map((item) => `<li>${esc(item)}</li>`).join("")}</ul></section>` : ""}
    </main>`, appBar("Esquema de cotas", state.project.station.name, "summary"), `<div class="sticky-actions"><button class="secondary" data-action="metadata">DADOS C-32</button><button class="primary" data-action="export" ${scheme.valid ? "" : "disabled"}>CONTINUAR</button></div>`);
  }

  function renderSchemePreview(scheme) {
    if (!scheme || !scheme.valid) return "";
    const documentData = root.C32SchemeImage.buildSvg(state.project, scheme);
    const inlineSvg = documentData.svg.replace(/^<\?xml[^>]*>\s*/i, "");
    return `<section class="card scheme-preview"><h2>Prévia</h2><p class="subtle">O arquivo PNG será gerado exatamente com este desenho. A prévia é reduzida proporcionalmente para caber na tela.</p><div class="scheme-svg-frame">${inlineSvg}</div>
      <button class="secondary wide scheme-image-button" data-action="generate-scheme-image" ${state.busy ? "disabled" : ""}>SALVAR IMAGEM DO ESQUEMA</button></section>`;
  }

  function renderMetadata() {
    app.innerHTML = shell(`<main class="content stack">
      <section class="card form-grid"><div class="span-2"><h2>Capa</h2></div>
        ${field("Número da C-32", "metadata.documentNumber", { placeholder: "C-32-4744-001/2026" })}
        ${field("Navio ou Comissão", "metadata.commission")}
        ${field("Levantamento nº", "metadata.surveyNumber")}
        ${field("Carta Náutica nº", "metadata.chartNumber")}
        ${field("Chefe da Comissão", "metadata.chief")}
        ${field("Nivelamento", "metadata.leveling")}
        ${field("Observações da capa", "metadata.coverObservation", { multiline: true, className: "span-2" })}
      </section>
      <section class="card form-grid"><div class="span-2"><h2>Equipe e equipamento</h2></div>
        ${field("Observador", "metadata.observer")}${field("Anotador", "metadata.annotator")}
        ${field("Instrumento", "metadata.instrument")}${field("Nº do instrumento", "metadata.instrumentNumber")}
        ${field("Mira AV", "metadata.staffAv")}${field("Mira AR", "metadata.staffAr")}
        ${field("Hora de início", "metadata.startTime", { type: "time" })}${field("Hora de fim", "metadata.endTime", { type: "time" })}
        ${field("Calculado por", "metadata.calculatedBy")}${field("Verificado por", "metadata.checkedBy")}
      </section>
      <section class="card form-grid"><div class="span-2"><h2>Observações do esquema</h2></div>
        ${field("Período usado no cálculo do NR", "metadata.schemeObservationPeriod", { multiline: true, className: "span-2" })}
        ${field("Regime do rio", "metadata.riverRegime", { placeholder: "Seca / Cheia" })}
        ${field("Natureza do fundo", "metadata.bottomNature")}
        ${field("Responsável pelas observações", "metadata.observerContact", { multiline: true, className: "span-2" })}
        ${field("Outras informações", "metadata.otherInformation", { multiline: true, className: "span-2" })}
      </section>
    </main>`, appBar("Dados da C-32", state.project.station.name, "acquisition"), `<div class="sticky-actions"><button class="primary" data-action="acquisition">CONCLUIR</button></div>`);
  }

  function renderExport() {
    recalculate();
    const scheme = state.calculation.scheme;
    app.innerHTML = shell(`<main class="content stack">
      <section class="card"><h2>Arquivos do nivelamento</h2><p class="subtle">O projeto permanece editável. A C-32 é gerada no modelo original com abas Capa, Instruções, IDA, VOLTA e Esquema de Cotas.</p></section>
      <section class="card stack"><h3>Projeto editável</h3><button class="primary wide" data-action="save-project">SALVAR .PROJECT</button><button class="secondary wide" data-action="share-project">COMPARTILHAR .PROJECT</button></section>
      <section class="card stack"><h3>Imagem do esquema</h3><p class="subtle">Exporta em PNG o mesmo desenho técnico da aba Esquema de Cotas da C-32, sem o restante da caderneta.</p><button class="primary wide" data-action="generate-scheme-image" ${scheme.valid && !state.busy ? "" : "disabled"}>${state.busy && state.busyAction === "scheme" ? `<span class="loading"></span> GERANDO` : "SALVAR ESQUEMA .PNG"}</button><button class="secondary wide" data-action="share-scheme-image" ${scheme.valid && !state.busy ? "" : "disabled"}>COMPARTILHAR ESQUEMA .PNG</button></section>
      <section class="card stack"><h3>Caderneta C-32</h3><button class="primary wide" data-action="generate-ods" ${scheme.valid && !state.busy ? "" : "disabled"}>${state.busy && state.busyAction === "ods" ? `<span class="loading"></span> GERANDO` : "SALVAR C-32 .ODS"}</button><button class="secondary wide" data-action="share-ods" ${scheme.valid && !state.busy ? "" : "disabled"}>COMPARTILHAR C-32 .ODS</button>${!scheme.valid ? `<p class="subtle">Volte ao esquema e corrija os dados antes de gerar os arquivos.</p>` : ""}</section>
      <div id="v2-export-history"></div>
      <div id="v2-bank-finalize"></div>
      <section class="card notice"><strong>Funcionamento local e offline</strong><p class="subtle">Projetos e Banco de Estações são estruturas separadas. O banco guarda somente o esquema e metadados; o projeto completo continua no arquivo .project.</p></section>
    </main>`, appBar("Exportar", state.project.station.name, "scheme"));
  }

  function renderSettings() {
    const criteria = currentCriteria();
    app.innerHTML = shell(`<main class="content stack">
      <section class="card"><h2>C32 - Campo v${root.C32Model.APP_VERSION}</h2><p>Aplicativo offline para aquisição, conferência e geração de C-32 de nivelamento geométrico, com Banco de Estações e leitura de F-43.</p></section>
      <section class="card identity-card"><h3>Identidade e autoria</h3>${institutionalMarks()}<div class="about-author"><strong>2ºSG-HN Soares</strong><span>CHN-9 / 2026</span></div></section>
      <section class="card stack"><div><h3>Critérios técnicos</h3><p class="subtle">Os valores podem ser ajustados para um procedimento específico ou profissional. Alterações ficam salvas no projeto e serão aplicadas aos novos projetos.</p></div>
        <div class="form-grid criteria-grid">
          ${criteriaField("VRF máximo (mm)", "vrfToleranceMm", "Acima deste valor a leitura fica inválida.")}
          ${criteriaField("Distância recomendada instrumento–mira (m)", "maxSightDistanceM", "Acima deste valor o aplicativo apenas alerta.")}
          ${criteriaField("Fechamento até 1 km (mm)", "closureUpTo1KmMm", "Tolerância fixa usada até 1 km.")}
          ${criteriaField("Coeficiente acima de 1 km (mm√k)", "closureAbove1KmCoefficientMm", "Tolerância = coeficiente × √k.")}
          ${criteriaField("Indicador PADRÃO (mm)", "standardToleranceMm", "Limite da comparação com a relação conhecida.")}
        </div>
        <section class="criteria-summary"><strong>Critério em uso</strong><p>VRF ≤ ${root.C32Ods.decimal(criteria.vrfToleranceMm, 2)} mm · alerta de distância acima de ${root.C32Ods.decimal(criteria.maxSightDistanceM, 2)} m.</p><p>Fechamento: ${root.C32Ods.decimal(criteria.closureUpTo1KmMm, 2)} mm até 1 km e ${root.C32Ods.decimal(criteria.closureAbove1KmCoefficientMm, 2)}√k acima de 1 km · PADRÃO ≤ ${root.C32Ods.decimal(criteria.standardToleranceMm, 2)} mm.</p></section>
        <button class="secondary wide" data-action="reset-criteria">RESTAURAR CRITÉRIOS ORIGINAIS</button>
      </section>
      <section class="card"><h3>Dúvidas e sugestões</h3><p>Contato: <strong>gabrielpsmsn@gmail.com</strong></p></section>
      <section class="card"><h3>Privacidade</h3><p>Não há login, servidor ou sincronização em nuvem. O rascunho, os projetos e o Banco de Estações permanecem no armazenamento local do aplicativo ou navegador.</p></section>
    </main>`, appBar("Configurações e sobre", `Versão ${root.C32Model.APP_VERSION}`, "home"));
  }

  function render() {
    switch (state.screen) {
      case "home": renderHome(); break;
      case "station-choice": renderStationChoice(); break;
      case "setup": renderSetup(); break;
      case "acquisition": renderAcquisition(); break;
      case "summary": renderSummary(); break;
      case "scheme": renderScheme(); break;
      case "metadata": renderMetadata(); break;
      case "export": renderExport(); break;
      case "settings": renderSettings(); break;
      default: renderHome();
    }
    // v0.1.17: renderizações da aquisição não reposicionam mais o operador.
    // A posição é gerenciada explicitamente por aba e restaurada quando necessário.
    if (state.screen !== "acquisition") window.scrollTo(0, 0);
    syncLevelingScreenState();
  }

  function syncLevelingScreenState() {
    const overlay = document.getElementById("v2-overlay");
    const active = Boolean(state.project && state.screen === "acquisition" && (!overlay || overlay.hidden));
    if (root.C32Native && typeof root.C32Native.setLevelingActive === "function") root.C32Native.setLevelingActive(active);
    return active;
  }

  function historySnapshot(screen, extra) {
    return Object.assign({ c32: true, screen: screen || state.screen, depth: Number(root.history?.state?.depth || 0) }, extra || {});
  }

  function navigateBack(target) {
    if (!target) return false;
    if (root.history && root.history.state && root.history.state.c32 && root.history.length > 1) {
      root.history.back();
      return true;
    }
    go(target, { replaceHistory: true });
    return true;
  }

  // Mantido para wrappers futuros que chamem JS diretamente. Na 2.1.0/2.1.1 o
  // wrapper Android já chama WebView.goBack(); a pilha abaixo faz esse gesto cair
  // na mesma navegação da seta superior.
  function handleAndroidBack() {
    const dialog = document.querySelector('.action-dialog-backdrop');
    if (dialog && typeof dialog._c32FinishFromHistory === "function") { dialog._c32FinishFromHistory(); return "handled"; }
    if (root.C32V2 && typeof root.C32V2.handleBack === "function" && root.C32V2.handleBack()) return "handled";
    const backButton = app.querySelector('[data-action="navigate-back"]');
    if (backButton && navigateBack(backButton.dataset.backTarget)) return "handled";
    if (state.screen !== "home") { go("home", { replaceHistory: true }); return "handled"; }
    return "exit";
  }

  function go(screen, options) {
    const config = options || {};
    const leavingAcquisition = state.screen === "acquisition" && screen !== "acquisition";
    if (leavingAcquisition) captureRunViewport(state.activeRun);
    if (!config.fromHistory && screen === "home" && root.history && Number(root.history.state?.depth || 0) > 0) {
      root.history.go(-Number(root.history.state.depth));
      return;
    }
    state.screen = screen;
    if (!config.fromHistory && root.history && typeof root.history.pushState === "function") {
      const method = config.replaceHistory ? "replaceState" : "pushState";
      const nextDepth = method === "pushState" ? Number(root.history.state?.depth || 0) + 1 : Number(root.history.state?.depth || 0);
      root.history[method](historySnapshot(screen, { depth: nextDepth }), "");
    }
    render();
    if (screen === "acquisition") {
      requestAnimationFrame(() => restoreRunViewport(state.activeRun, { fallbackRatio: 0, behavior: "auto" }));
    }
  }

  function onHistoryPop(event) {
    const dialog = document.querySelector('.action-dialog-backdrop');
    if (dialog && typeof dialog._c32FinishFromHistory === "function") {
      dialog._c32FinishFromHistory();
      return;
    }
    if (root.C32V2 && typeof root.C32V2.applyHistoryState === "function" && root.C32V2.applyHistoryState(event.state)) {
      return;
    }
    const next = event.state && event.state.c32 && event.state.screen ? event.state.screen : "home";
    if (next !== state.screen) go(next, { fromHistory: true });
    else render();
  }


  function validateSetup() {
    if (!root.C32Calc.cleanName(state.project.station.name)) throw new Error("Informe o nome da estação.");
    if (state.project.station.existing) {
      if (!state.project.station.references.length) throw new Error("Adicione ao menos uma referência conhecida.");
      for (const ref of state.project.station.references) {
        if (!root.C32Calc.cleanName(ref.high) || !root.C32Calc.cleanName(ref.low)) throw new Error("Preencha os dois pontos de cada referência.");
        if (root.C32Calc.sameName(ref.high, ref.low)) throw new Error("Uma referência não pode relacionar o mesmo ponto consigo próprio.");
        const difference = root.C32Calc.parseNumber(ref.differenceCm);
        if (difference === null || difference < 0) throw new Error("Informe um desnível válido, em centímetros, para cada referência.");
        const storedMeters = root.C32Model.centimetersToMetersText(ref.differenceCm);
        if (storedMeters === null) throw new Error("Informe um desnível válido, em centímetros, para cada referência.");
        ref.differenceM = storedMeters;
        ref.differenceUnit = "cm";
      }
    }
  }

  function beginAcquisition() {
    validateSetup();
    if (state.project.station && Array.isArray(state.project.station.preparation) && state.project.station.preparation.length) {
      state.project.station.preparationLockedAt = root.C32Model.now();
    }
    state.project.metadata.leveling = state.project.metadata.leveling || `Estação Fluviométrica de ${state.project.station.name}`;
    if (!state.project.ida.lances.length && !state.project.volta.lances.length) {
      if (state.project.station.existing) {
        const runs = root.C32Model.suggestedRuns(state.project.station.references);
        state.project.ida.lances = runs.ida;
        state.project.volta.lances = runs.volta;
        state.project.volta.routeMode = "auto";
      } else {
        state.project.ida.lances.push(root.C32Model.emptyLance());
        state.project.volta.routeMode = "auto";
      }
    }
    if (state.project.volta.routeMode === "auto" && root.C32Model.isReverseSkeleton(state.project.ida.lances, state.project.volta.lances)) {
      state.lastSyncedIdaSignature = root.C32Model.structureSignature(state.project.ida.lances);
      state.structureDirty = false;
      state.referenceNamesDirty = false;
      state.ptTopologyDirty = false;
      state.pendingRenameHints = [];
    }
    saveDraft();
    state.activeRun = "ida";
    go("acquisition");
  }

  function nextPtName() {
    let max = 0;
    for (const run of [state.project.ida.lances, state.project.volta.lances]) {
      run.forEach((lance) => [lance.from, lance.to].forEach((name) => {
        const match = root.C32Calc.normName(name).match(/^PT[-_\s]?(\d+)$/);
        if (match) max = Math.max(max, Number(match[1]));
      }));
    }
    return `PT-${max + 1}`;
  }

  function saveProjectFile(share) {
    saveDraft();
    const text = root.C32Storage.exportProject(state.project);
    const name = `${filenameBase()}.project`;
    if (share) root.C32Native.shareFile(name, "application/json", text);
    else root.C32Native.saveFile(name, "application/json", text);
    showToast(share ? "Projeto preparado para compartilhamento." : "Escolha onde salvar o projeto.");
  }

  async function generateOds(share) {
    if (state.busy) return;
    recalculate();
    if (!state.calculation.scheme.valid) throw new Error("Corrija os dados do esquema antes de gerar a C-32.");
    state.busy = true;
    state.busyAction = "ods";
    renderExport();
    try {
      const bytes = await root.C32Ods.generate(state.project, state.calculation);
      const name = `C-32_${filenameBase()}.ods`;
      if (share) root.C32Native.shareFile(name, "application/vnd.oasis.opendocument.spreadsheet", bytes);
      else root.C32Native.saveFile(name, "application/vnd.oasis.opendocument.spreadsheet", bytes);
      showToast(share ? "C-32 preparada para compartilhamento." : "Escolha onde salvar a C-32.");
    } finally {
      state.busy = false;
      state.busyAction = "";
      renderExport();
    }
  }

  async function generateSchemeImage(share) {
    if (state.busy) return;
    recalculate();
    if (!state.calculation.scheme.valid) throw new Error("Corrija os dados do esquema antes de gerar a imagem.");
    const originScreen = state.screen;
    state.busy = true;
    state.busyAction = "scheme";
    if (originScreen === "export") renderExport();
    try {
      const bytes = await root.C32SchemeImage.generatePng(state.project, state.calculation.scheme);
      const name = `ESQUEMA_COTAS_${filenameBase()}.png`;
      if (share) root.C32Native.shareFile(name, "image/png", bytes);
      else root.C32Native.saveFile(name, "image/png", bytes);
      showToast(share ? "Imagem do esquema preparada para compartilhamento." : "Escolha onde salvar a imagem do esquema.");
    } finally {
      state.busy = false;
      state.busyAction = "";
      if (state.screen === originScreen) render();
    }
  }

  function receiveProject(error, text) {
    if (error) return showToast(error.message || "Não foi possível abrir o arquivo.", "error");
    try {
      state.project = root.C32Storage.importProject(text);
      resetRuntimeStateForProject();
      saveDraft();
      state.activeRun = "ida";
      go("acquisition");
      showToast("Projeto aberto e recalculado.");
    } catch (importError) {
      showToast(importError.message, "error");
    }
  }

  function syncAutomaticVolta(showBlockedMessage, options) {
    const mode = state.project && state.project.volta ? state.project.volta.routeMode : "manual";
    const result = root.C32Model.syncVoltaFromIda(state.project, options || {});
    if (!result.synced && mode === "auto" && (showBlockedMessage || result.reasonCode === "ambiguous-names")) {
      showToast(result.reason || "A VOLTA não pôde ser atualizada automaticamente.", "error");
    }
    return result;
  }

  function finishSuccessfulAutoSync(updateRelatedHistory = true, relatedRenameHints, historyLabel) {
    const hints = Array.isArray(relatedRenameHints) ? relatedRenameHints : [];
    const automatic = state.project && state.project.volta && state.project.volta.routeMode === "auto";
    const fullyAligned = automatic && root.C32Model.isReverseSkeleton(state.project.ida.lances, state.project.volta.lances);
    state.lastSyncedIdaSignature = fullyAligned ? root.C32Model.structureSignature(state.project.ida.lances) : null;
    state.structureDirty = false;
    state.referenceNamesDirty = false;
    state.ptTopologyDirty = false;
    state.pendingRenameHints = [];
    saveDraft();
    if (updateRelatedHistory) {
      const after = runtimeSnapshot();
      if (!coalesceRenameHistory(hints, historyLabel, after)) refreshLatestStructuralHistoryAfter();
    }
  }

  function renameHistoryLabel(hints) {
    const items = (hints || []).filter((hint) => hint.oldName && hint.newName);
    if (!items.length) return "Atualizar estrutura da VOLTA";
    if (items.some((hint) => hint.physicalChange)) {
      const first = items.find((hint) => hint.physicalChange) || items[0];
      return `Substituir ${first.oldName} por ${first.newName}`;
    }
    const first = items[0];
    return `Renomear ${first.oldName} para ${first.newName}`;
  }

  async function ensureAutomaticVoltaBeforeOpen() {
    if (!state.project || !state.project.volta) return true;
    const automatic = state.project.volta.routeMode === "auto";
    const renameHints = effectiveRenameHints();
    const referencesMatch = root.C32Model.referenceSequencesMatch(state.project.ida.lances, state.project.volta.lances);
    const idaRulerStatus = rulerTopologyStatus("ida", state.project.ida.lances);
    const voltaRulerStatus = rulerTopologyStatus("volta", state.project.volta.lances);

    // v0.1.18: se um projeto legado já chegou com Régua intermediária, nunca tentar
    // "corrigir" isso reconstruindo ou renomeando silenciosamente a VOLTA. O usuário
    // ainda pode abrir a aba e corrigir o caminhamento manualmente, sem perda de dados.
    if (!idaRulerStatus.valid || !voltaRulerStatus.valid) {
      if (state.referenceNamesDirty || renameHints.length) {
        showToast("A Régua está em posição intermediária no caminhamento. A sincronização automática foi suspensa para preservar as leituras.", "error");
      }
      return true;
    }

    // v0.1.14: diferenças de PT entre IDA e VOLTA são normais e não disparam
    // sincronização estrutural. Só referências permanentes exigem ação ao abrir a VOLTA.
    if (!state.referenceNamesDirty && !renameHints.length && referencesMatch) {
      state.ptTopologyDirty = false;
      state.structureDirty = false;
      return true;
    }

    const referenceOnly = renameHints.length > 0;
    let result = syncAutomaticVolta(false, { renameHints, referenceOnly });
    if (!result.synced && result.reasonCode === "physical-reference-replacement") {
      const affected = (result.affected || []).map((item) => `${item.from} → ${item.to}`).join("\n");
      const pairs = (result.renamedPairs || renameHints).map((item) => `${item.oldName} → ${item.newName}`).join(", ");
      const message = `Alteração física de referência detectada.${pairs ? `\n\n${pairs}` : ""}\n\nForam modificados dados de aquisição relacionados a essa referência. As leituras existentes da VOLTA${affected ? ` nos lances:\n${affected}` : " ligadas ao nome anterior"} pertencem à referência anterior.\n\nDeseja atualizar a VOLTA e limpar somente esses lances?`;
      if (!(await askActionConfirmation(message, "ATUALIZAR E LIMPAR"))) {
        showToast("Atualização cancelada; a VOLTA foi preservada.", "error");
        return false;
      }
      result = syncAutomaticVolta(false, { renameHints, referenceOnly, allowPhysicalRenameDataClear: true });
    }
    if (!result.synced && result.reasonCode === "reference-insertion-would-discard-readings") {
      const item = result.insertion || {};
      const affected = (result.affected || []).map((entry) => `${entry.from} → ${entry.to}`).join("\n");
      const message = `Nova referência permanente inserida.${item.newName ? `\n\n${item.newName} precisa participar também da VOLTA.` : ""}${affected ? `\n\nO lance ${affected} possui leituras e será dividido.` : ""}\n\nDeseja atualizar a VOLTA e limpar somente esse lance?`;
      if (!(await askActionConfirmation(message, "ATUALIZAR E LIMPAR"))) {
        showToast("Atualização cancelada; a VOLTA foi preservada.", "error");
        return false;
      }
      result = syncAutomaticVolta(false, { renameHints, referenceOnly, allowDiscardAffectedData: true, allowPhysicalRenameDataClear: true });
    }
    if (!result.synced && result.reasonCode === "would-discard-readings") {
      const affected = (result.affected || []).map((item) => `${item.from} → ${item.to}`).join("\n");
      const message = `A nova estrutura da IDA substitui lance(s) da VOLTA que já possuem dados${affected ? `:\n${affected}` : "."}\n\nEssas leituras não pertencem aos novos lances. Deseja apagar somente os dados afetados e atualizar a VOLTA?`;
      if (!(await askActionConfirmation(message, "ATUALIZAR E LIMPAR"))) {
        showToast("Sincronização cancelada; a VOLTA foi preservada.", "error");
        return false;
      }
      result = syncAutomaticVolta(false, { renameHints, referenceOnly, allowDiscardAffectedData: true, allowPhysicalRenameDataClear: true });
    }
    if (!result.synced) {
      showToast(result.reason || "Não foi possível sincronizar a VOLTA.", "error");
      return false;
    }

    const effectivePairs = (result.renamedPairs && result.renamedPairs.length) ? result.renamedPairs : renameHints;
    const simpleRenames = renameHints.filter((hint) => !hint.physicalChange);
    const physicalRenames = renameHints.filter((hint) => hint.physicalChange);
    finishSuccessfulAutoSync(renameHints.length > 0 || Boolean(result.referenceInsertionSynced), renameHints, result.referenceInsertionSynced && result.insertion ? `Incluir ${result.insertion.newName} na VOLTA` : renameHistoryLabel(renameHints));
    if (result.referenceInsertionSynced && result.insertion && result.insertion.newName) {
      showToast(`✓ ${result.insertion.newName} incluída na VOLTA`);
    } else if (physicalRenames.length) {
      const first = physicalRenames[0];
      showToast(`✓ ${first.oldName} atualizada para ${first.newName} na VOLTA; leituras incompatíveis foram limpas.`);
    } else if (simpleRenames.length) {
      const first = simpleRenames[0];
      showToast(`✓ ${first.oldName} atualizada para ${first.newName} na VOLTA`);
    } else if (result.renamed && effectivePairs.length) {
      const first = effectivePairs[0];
      showToast(`✓ ${first.oldName} atualizada para ${first.newName} na VOLTA`);
    }
    return true;
  }

  function viewportScrollMetrics() {
    const doc = document.documentElement;
    const body = document.body;
    const height = Math.max(
      doc ? doc.scrollHeight : 0,
      body ? body.scrollHeight : 0
    );
    const viewport = Math.max(1, window.innerHeight || 1);
    const max = Math.max(0, height - viewport);
    const top = Math.max(0, Math.min(max, Number(window.scrollY || window.pageYOffset || 0)));
    return { top, max, ratio: max > 0 ? top / max : 0 };
  }

  function viewportAnchorY() {
    // A linha de referência fica abaixo do cabeçalho/abas e perto do terço superior,
    // representando melhor o cartão que o operador está efetivamente conferindo.
    const viewport = Math.max(1, window.innerHeight || 1);
    return Math.min(360, Math.max(180, viewport * 0.34));
  }

  function captureRunViewport(runName) {
    if (state.screen !== "acquisition" || state.activeRun !== runName) return null;
    const metrics = viewportScrollMetrics();
    const cards = Array.from(document.querySelectorAll(`.lance-card[id^="lance-${runName}-"]`));
    const anchorY = viewportAnchorY();
    let best = null;
    let bestDistance = Infinity;
    for (const card of cards) {
      const rect = card.getBoundingClientRect();
      const distance = rect.top <= anchorY && rect.bottom >= anchorY
        ? 0
        : Math.min(Math.abs(rect.top - anchorY), Math.abs(rect.bottom - anchorY));
      if (distance < bestDistance) {
        best = { card, rect };
        bestDistance = distance;
      }
      if (distance === 0) break;
    }
    const indexMatch = best && best.card.id ? best.card.id.match(/-(\d+)$/) : null;
    const snapshot = {
      ratio: metrics.ratio,
      index: indexMatch ? Number(indexMatch[1]) : null,
      lanceId: best ? (best.card.dataset.lanceId || "") : "",
      cardTop: best ? best.rect.top : null
    };
    state.runViewport[runName] = snapshot;
    return snapshot;
  }

  function findViewportCard(runName, snapshot) {
    if (!snapshot) return null;
    if (snapshot.lanceId) {
      const cards = Array.from(document.querySelectorAll(`.lance-card[id^="lance-${runName}-"]`));
      const byId = cards.find((card) => card.dataset.lanceId === snapshot.lanceId);
      if (byId) return byId;
    }
    if (Number.isInteger(snapshot.index)) return document.getElementById(`lance-${runName}-${snapshot.index}`);
    return null;
  }

  function scrollWindowTo(top, behavior) {
    const metrics = viewportScrollMetrics();
    const bounded = Math.max(0, Math.min(metrics.max, Number.isFinite(top) ? top : 0));
    window.scrollTo({ top: bounded, behavior: behavior || "auto" });
  }

  function restoreRunViewport(runName, options) {
    const settings = options && typeof options === "object" ? options : {};
    const saved = state.runViewport[runName];
    const card = findViewportCard(runName, saved);
    if (card && Number.isFinite(saved.cardTop)) {
      const currentTop = viewportScrollMetrics().top;
      const cardTopNow = card.getBoundingClientRect().top;
      scrollWindowTo(currentTop + cardTopNow - saved.cardTop, settings.behavior || "auto");
      return "saved";
    }
    const ratio = Number.isFinite(settings.fallbackRatio)
      ? Math.max(0, Math.min(1, settings.fallbackRatio))
      : 0;
    const metrics = viewportScrollMetrics();
    scrollWindowTo(metrics.max * ratio, settings.behavior || "auto");
    return "relative";
  }

  function isPermanentNavigationPoint(name) {
    const clean = root.C32Calc.cleanName(name);
    return Boolean(clean) && !root.C32Calc.isTemporaryPoint(clean);
  }

  function expectedInverseLanceIndex(sourceRun, targetRun, sourceIndex) {
    const sources = state.project && state.project[sourceRun] ? state.project[sourceRun].lances : [];
    const targets = state.project && state.project[targetRun] ? state.project[targetRun].lances : [];
    if (!Number.isInteger(sourceIndex) || !sources.length || !targets.length) return null;
    if (sources.length === targets.length) return Math.max(0, targets.length - 1 - sourceIndex);
    if (sources.length === 1) return Math.floor((targets.length - 1) / 2);
    const progress = sourceIndex / (sources.length - 1);
    return Math.max(0, Math.min(targets.length - 1, Math.round((1 - progress) * (targets.length - 1))));
  }

  function exactInverseLanceIndex(sourceRun, targetRun, sourceIndex) {
    const source = state.project && state.project[sourceRun] && state.project[sourceRun].lances[sourceIndex];
    const targets = state.project && state.project[targetRun] ? state.project[targetRun].lances : [];
    if (!source) return null;
    const expected = expectedInverseLanceIndex(sourceRun, targetRun, sourceIndex);
    const inverse = [];
    targets.forEach((lance, index) => {
      if (root.C32Calc.sameName(source.from, lance && lance.to) && root.C32Calc.sameName(source.to, lance && lance.from)) inverse.push(index);
    });
    if (!inverse.length) return null;
    inverse.sort((a, b) => Math.abs(a - expected) - Math.abs(b - expected));
    return inverse[0];
  }

  function permanentSegmentContaining(runName, index) {
    const run = state.calculation && state.calculation[runName];
    if (!run || !Number.isInteger(index)) return null;
    return root.C32Calc.permanentSegments(run).find((segment) => index >= segment.startIndex && index <= segment.endIndex) || null;
  }

  function matchingPermanentSegment(targetRun, sourceSegment) {
    const run = state.calculation && state.calculation[targetRun];
    if (!run || !sourceSegment) return null;
    const segments = root.C32Calc.permanentSegments(run);
    const reversed = segments.filter((segment) => root.C32Calc.sameName(sourceSegment.start, segment.end) && root.C32Calc.sameName(sourceSegment.end, segment.start));
    if (reversed.length === 1) return { segment: reversed[0], reversed: true };
    const direct = segments.filter((segment) => root.C32Calc.sameName(sourceSegment.start, segment.start) && root.C32Calc.sameName(sourceSegment.end, segment.end));
    return direct.length === 1 ? { segment: direct[0], reversed: false } : null;
  }

  function blockCorrespondingLanceIndex(sourceRun, targetRun, sourceIndex) {
    const sourceSegment = permanentSegmentContaining(sourceRun, sourceIndex);
    const pair = matchingPermanentSegment(targetRun, sourceSegment);
    if (!sourceSegment || !pair) return null;
    const sourceCount = sourceSegment.endIndex - sourceSegment.startIndex + 1;
    const targetCount = pair.segment.endIndex - pair.segment.startIndex + 1;
    if (sourceCount < 1 || targetCount < 1) return null;
    const sourceOffset = Math.max(0, Math.min(sourceCount - 1, sourceIndex - sourceSegment.startIndex));
    const sourceMidpoint = (sourceOffset + 0.5) / sourceCount;
    const targetProgress = pair.reversed ? 1 - sourceMidpoint : sourceMidpoint;
    const targetOffset = Math.max(0, Math.min(targetCount - 1, Math.floor(targetProgress * targetCount)));
    return pair.segment.startIndex + targetOffset;
  }

  function closestCommonPointIndex(sourceRun, targetRun, sourceIndex) {
    const source = state.project && state.project[sourceRun] && state.project[sourceRun].lances[sourceIndex];
    const targets = state.project && state.project[targetRun] ? state.project[targetRun].lances : [];
    if (!source || !targets.length) return null;
    const expected = expectedInverseLanceIndex(sourceRun, targetRun, sourceIndex);
    const sourcePoints = [source.from, source.to].filter((value) => root.C32Calc.cleanName(value));
    const ranked = [];
    targets.forEach((lance, index) => {
      let overlap = 0;
      let inverseOrientation = 0;
      for (const point of sourcePoints) {
        if (root.C32Calc.sameName(point, lance && lance.from) || root.C32Calc.sameName(point, lance && lance.to)) overlap += 1;
      }
      if (root.C32Calc.sameName(source.from, lance && lance.to)) inverseOrientation += 1;
      if (root.C32Calc.sameName(source.to, lance && lance.from)) inverseOrientation += 1;
      if (!overlap) return;
      ranked.push({ index, overlap, inverseOrientation, distance: Math.abs(index - expected) });
    });
    ranked.sort((a, b) => b.overlap - a.overlap || b.inverseOrientation - a.inverseOrientation || a.distance - b.distance || a.index - b.index);
    return ranked.length ? ranked[0].index : null;
  }

  function semanticRunTargetIndex(sourceRun, targetRun, sourceIndex) {
    if (!Number.isInteger(sourceIndex)) return null;
    // 1) Mesmos dois pontos em sentido inverso: correspondência exata.
    const exact = exactInverseLanceIndex(sourceRun, targetRun, sourceIndex);
    if (Number.isInteger(exact)) return { index: exact, reason: "exact-inverse" };
    // 2) Se o caminho usa PTs diferentes, procurar acima/abaixo da posição inversa
    // esperada o lance mais próximo que ainda compartilha um ponto com o lance atual.
    const common = closestCommonPointIndex(sourceRun, targetRun, sourceIndex);
    if (Number.isInteger(common)) return { index: common, reason: "closest-common-point" };
    // 3) Se não há ponto nominal comum, cair no mesmo trecho delimitado pelas
    // referências permanentes, admitindo quantidades diferentes de PTs.
    const block = blockCorrespondingLanceIndex(sourceRun, targetRun, sourceIndex);
    if (Number.isInteger(block)) return { index: block, reason: "permanent-segment" };
    // 4) Último recurso: posição operacional inversa aproximada.
    const inverse = expectedInverseLanceIndex(sourceRun, targetRun, sourceIndex);
    return Number.isInteger(inverse) ? { index: inverse, reason: "inverse-position" } : null;
  }

  function scrollToSemanticLance(runName, index, desiredTop, behavior) {
    const card = document.getElementById(`lance-${runName}-${index}`);
    if (!card) return false;
    const currentTop = viewportScrollMetrics().top;
    const cardTopNow = card.getBoundingClientRect().top;
    const targetCardTop = Number.isFinite(desiredTop) ? desiredTop : viewportAnchorY();
    scrollWindowTo(currentTop + cardTopNow - targetCardTop, behavior || "auto");
    card.classList.add("semantic-target");
    setTimeout(() => card.classList.remove("semantic-target"), 1400);
    return true;
  }

  async function switchRun(runName) {
    if (runName !== "ida" && runName !== "volta") return false;
    if (runName === state.activeRun) return true;
    const sourceRun = state.activeRun;
    const sourceViewport = captureRunViewport(sourceRun);
    if (runName === "volta" && !(await ensureAutomaticVoltaBeforeOpen())) return false;
    // A sincronização nominal eventualmente feita acima pode alterar nomes, portanto
    // recalcular antes de procurar o correspondente semântico.
    recalculate();
    const semanticTarget = semanticRunTargetIndex(sourceRun, runName, sourceViewport && sourceViewport.index);
    state.activeRun = runName;
    renderAcquisition();
    requestAnimationFrame(() => {
      // v0.1.19: a troca de aba acompanha o TRECHO que o operador estava olhando.
      // A memória de viewport da v0.1.17 continua apenas como fallback quando não
      // existe correspondência estrutural segura entre IDA e VOLTA.
      if (semanticTarget && scrollToSemanticLance(runName, semanticTarget.index, sourceViewport && sourceViewport.cardTop, "auto")) return;
      restoreRunViewport(runName, {
        fallbackRatio: sourceViewport && Number.isFinite(sourceViewport.ratio) ? sourceViewport.ratio : 0,
        behavior: "auto"
      });
    });
    return true;
  }

  function readingPathInfo(path) {
    const match = String(path || "").match(/^(ida|volta)\.lances\.(\d+)\.(ar|av)\.(sup|inf|cen)$/);
    if (!match) return null;
    return { run: match[1], index: Number(match[2]), sight: match[3], wire: match[4] };
  }

  function shouldAutoAdvanceReading(input) {
    const info = readingPathInfo(input && input.dataset ? input.dataset.path : "");
    if (!info || info.sight !== "av" || info.wire !== "cen") return true;
    const run = state.calculation && state.calculation[info.run];
    const row = run && run.rows ? run.rows[info.index] : null;
    return root.C32Calc.canAutoAdvanceAfterVanteCentral(row);
  }

  function focusNextReading(current) {
    const info = readingPathInfo(current && current.dataset ? current.dataset.path : "");
    if (!info || !state.project || !state.project[info.run]) return;
    const order = [
      ["ar", "sup"], ["ar", "inf"], ["ar", "cen"],
      ["av", "sup"], ["av", "inf"], ["av", "cen"]
    ];
    const position = order.findIndex(([sight, wire]) => sight === info.sight && wire === info.wire);
    if (position < 0) return;
    let targetIndex = info.index;
    let targetPosition = position + 1;
    if (targetPosition >= order.length) {
      targetIndex += 1;
      targetPosition = 0;
    }
    const run = state.project[info.run].lances || [];
    if (targetIndex >= run.length) return;
    const [targetSight, targetWire] = order[targetPosition];
    const targetPath = `${info.run}.lances.${targetIndex}.${targetSight}.${targetWire}`;
    const target = Array.from(document.querySelectorAll("[data-reading-input]")).find((field) => field.dataset.path === targetPath);
    if (!target) return;
    target.focus();
    if (typeof target.select === "function") target.select();
    // Na VOLTA a ordem operacional também progride para baixo. O focus já
    // garante a rolagem; scrollIntoView apenas evita que a barra fixa o encubra.
    if (info.run === "volta" && targetIndex !== info.index) {
      target.closest(".lance-card")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }

  function fieldEditLabel(input) {
    const path = input && input.dataset ? input.dataset.path : "";
    const info = readingPathInfo(path);
    if (info) return `${info.run.toUpperCase()} lance ${info.index + 1} ${info.sight.toUpperCase()} ${info.wire.toUpperCase()}`;
    if (/\.(from|to)$/.test(path)) return "Alterar nome de ponto";
    if (path.includes("observation")) return "Alterar observação";
    return "Editar campo";
  }

  function removeLiveEditHistory(session) {
    if (!session || !session.historyEntry) return;
    const index = state.undoStack.indexOf(session.historyEntry);
    if (index >= 0) state.undoStack.splice(index, 1);
    session.historyEntry = null;
    refreshHistoryButtons();
  }

  function updateLiveEditHistory(input) {
    const session = state.editSession;
    if (!session || session.element !== input || !state.project) return;
    const after = runtimeSnapshot();
    if (snapshotsEqual(session.before, after)) {
      removeLiveEditHistory(session);
      return;
    }
    if (!session.historyEntry) {
      const entry = {
        label: session.label || "Editar campo",
        before: session.before,
        after,
        kind: session.pointMatch ? "structural" : "edit",
        transactionId: null,
        liveEdit: true
      };
      state.undoStack.push(entry);
      if (state.undoStack.length > state.historyLimit) state.undoStack.shift();
      state.redoStack = [];
      session.historyEntry = entry;
    } else {
      session.historyEntry.after = after;
    }
    refreshHistoryButtons();
  }

  function finalizeLiveEditHistory(session, after, kind, txId) {
    if (!session) return false;
    if (snapshotsEqual(session.before, after)) {
      removeLiveEditHistory(session);
      return false;
    }
    if (!session.historyEntry) {
      return pushHistory(session.label, session.before, after, kind, { transactionId: txId });
    }
    session.historyEntry.label = session.label || session.historyEntry.label;
    session.historyEntry.after = after;
    session.historyEntry.kind = kind || session.historyEntry.kind;
    session.historyEntry.transactionId = txId || session.historyEntry.transactionId || null;
    delete session.historyEntry.liveEdit;
    refreshHistoryButtons();
    return true;
  }

  app.addEventListener("focusin", (event) => {
    const input = event.target.closest("[data-path]");
    if (!input || !state.project || input.readOnly || input.disabled) return;
    state.editSession = {
      element: input,
      path: input.dataset.path,
      initialValue: getPath(state.project, input.dataset.path),
      before: runtimeSnapshot(),
      label: fieldEditLabel(input),
      pointMatch: input.matches("[data-point-input]") ? input.dataset.path.match(/^(ida|volta)\.lances\.(\d+)\.(from|to)$/) : null,
      historyEntry: null
    };
    if (state.editSession.pointMatch) {
      const runName = state.editSession.pointMatch[1];
      state.editSession.rulerStatusBefore = rulerTopologyStatus(runName, state.project[runName].lances);
    }
  });

  app.addEventListener("focusout", (event) => {
    const input = event.target.closest("[data-path]");
    if (!input || !state.editSession || state.editSession.element !== input || !state.project) return;
    const session = state.editSession;
    if (input.matches("[data-reference-cm]")) {
      const numeric = root.C32Calc.parseNumber(input.value);
      const meters = root.C32Model.centimetersToMetersText(input.value);
      if (numeric === null || numeric < 0 || meters === null) {
        setPath(state.project, session.path, input.value);
        setPath(state.project, session.path.replace(/\.differenceCm$/, ".differenceM"), "");
        showToast("Informe o desnível em centímetros usando vírgula ou ponto.", "error");
      } else {
        const normalizedCm = root.C32Model.metersToCentimetersText(meters, 2);
        input.value = normalizedCm;
        setPath(state.project, session.path, normalizedCm);
        setPath(state.project, session.path.replace(/\.differenceCm$/, ".differenceM"), meters);
      }
    }
    const finalValue = getPath(state.project, session.path);

    // v0.1.18: uma edição não pode transformar uma Régua terminal/inicial válida
    // em ponto intermediário. Se isso ocorrer, a edição inteira é revertida.
    if (session.pointMatch && String(session.initialValue || "") !== String(finalValue || "")) {
      const runName = session.pointMatch[1];
      const beforeStatus = session.rulerStatusBefore || { valid: true };
      const afterStatus = rulerTopologyStatus(runName, state.project[runName].lances);
      if (beforeStatus.valid && !afterStatus.valid) {
        removeLiveEditHistory(session);
        state.editSession = null;
        restoreRuntime(session.before);
        render();
        showToast(rulerTopologyMessage(runName), "error");
        return;
      }
    }

    state.editSession = null;
    let txId = pendingRenameTransactionForPath(session.path);
    if (session.pointMatch && String(session.initialValue || "") !== String(finalValue || "")) {
      const runName = session.pointMatch[1];
      const index = Number(session.pointMatch[2]);
      const side = session.pointMatch[3];
      const affectedIndexes = propagateAdjacentPointRename(runName, index, side, session.initialValue, finalValue);
      if (runName === "ida") {
        if (root.C32Model.isReferenceRename(session.initialValue, finalValue)) {
          const hint = queueRenameHint(session.initialValue, finalValue, affectedIndexes, transactionId("rename"));
          txId = hint ? hint.transactionId : txId;
          markIdaStructureDirty("reference");
        } else {
          const wasPermanent = root.C32Model.isPermanentReferenceName(session.initialValue);
          const isPermanent = root.C32Model.isPermanentReferenceName(finalValue);
          if (wasPermanent !== isPermanent) markIdaStructureDirty("reference");
          else markIdaStructureDirty("pt-topology");
        }
      } else if (!root.C32Model.isReferenceRename(session.initialValue, finalValue)) {
        markVoltaPtTopologyCustomized();
      }
    }
    saveDraft();
    const after = runtimeSnapshot();
    const kind = session.pointMatch ? "structural" : "edit";
    finalizeLiveEditHistory(session, after, kind, txId);
    if (state.screen === "acquisition") refreshLiveOutputs();
  });

  app.addEventListener("input", (event) => {
    const criteriaInput = event.target.closest("[data-criteria-key]");
    if (criteriaInput) {
      saveCriteriaValue(criteriaInput.dataset.criteriaKey, criteriaInput.value);
      return;
    }
    const input = event.target.closest("[data-path]");
    if (!input || !state.project || input.readOnly) return;
    if (input.type === "radio" && !input.checked) return;
    if (input.matches("[data-reading-input]")) input.value = input.value.replace(/\D/g, "").slice(0, 4);
    setPath(state.project, input.dataset.path, input.value);
    if (input.matches("[data-reference-cm]")) {
      const meters = root.C32Model.centimetersToMetersText(input.value);
      setPath(state.project, input.dataset.path.replace(/\.differenceCm$/, ".differenceM"), meters === null ? "" : meters);
      const reference = getPath(state.project, input.dataset.path.replace(/\.differenceCm$/, ""));
      if (reference && typeof reference === "object") reference.differenceUnit = "cm";
    }
    saveDraft();
    // v0.1.18: apagar/substituir já habilita Desfazer enquanto o foco continua
    // no próprio campo. Várias teclas da mesma edição continuam uma única ação.
    updateLiveEditHistory(input);
    if (state.screen === "acquisition") refreshLiveOutputs();
    if (input.matches("[data-reading-input]") && input.value.length === 4 && shouldAutoAdvanceReading(input)) {
      requestAnimationFrame(() => focusNextReading(input));
    }
  });

  app.addEventListener("change", (event) => {
    const criteriaInput = event.target.closest("[data-criteria-key]");
    if (criteriaInput) {
      const key = criteriaInput.dataset.criteriaKey;
      const numeric = root.C32Calc.parseNumber(criteriaInput.value);
      if (numeric === null || numeric <= 0) {
        saveCriteriaValue(key, root.C32Model.DEFAULT_CRITERIA[key]);
        showToast("Informe um critério maior que zero.", "error");
      } else saveCriteriaValue(key, numeric);
      if (state.project) state.project.criteria = root.C32Model.normalizeCriteria(state.project.criteria);
      state.settings.criteria = root.C32Model.normalizeCriteria(state.settings.criteria);
      return renderSettings();
    }
    const input = event.target.closest("[data-path]");
    if (!input || !state.project || input.readOnly) return;
    if (input.type === "radio" && !input.checked) return;
    setPath(state.project, input.dataset.path, input.value);
    if (input.matches("[data-reference-cm]")) {
      const meters = root.C32Model.centimetersToMetersText(input.value);
      setPath(state.project, input.dataset.path.replace(/\.differenceCm$/, ".differenceM"), meters === null ? "" : meters);
    }
    saveDraft();
    if (state.screen === "scheme") renderScheme();
  });

  app.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" || !event.target.matches("[data-acq-input]")) return;
    event.preventDefault();
    const fields = Array.from(document.querySelectorAll("[data-acq-input]:not([readonly])"));
    const index = fields.indexOf(event.target);
    if (index >= 0 && fields[index + 1]) {
      fields[index + 1].focus();
      if (typeof fields[index + 1].select === "function") fields[index + 1].select();
    }
  });

  app.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-action]");
    if (!button || button.disabled) return;
    const action = button.dataset.action;
    try {
      if (action === "undo") return undoAction();
      if (action === "redo") return redoAction();
      if (action === "navigate-back") return navigateBack(button.dataset.backTarget);
      if (action === "home") return go("home");
      if (action === "station-choice") return go("station-choice");
      if (action === "setup") return go("setup");
      if (action === "acquisition") return go("acquisition");
      if (action === "summary") return go("summary");
      if (action === "scheme") return go("scheme");
      if (action === "metadata") return go("metadata");
      if (action === "export") return go("export");
      if (action === "settings") return go("settings");
      if (action === "new-project") return go("station-choice");
      if (action === "choose-existing") {
        state.project = createProject(button.dataset.existing === "true");
        if (state.project.station.existing) state.project.station.references.push(root.C32Model.createReference());
        resetRuntimeStateForProject();
        saveDraft();
        return go("setup");
      }
      if (action === "continue-draft") {
        state.project = root.C32Storage.loadDraft();
        resetRuntimeStateForProject();
        state.activeRun = "ida";
        return go("acquisition");
      }
      if (action === "discard-draft") {
        if (confirm("Descartar definitivamente o rascunho atual?")) {
          root.C32Storage.discardDraft();
          state.project = null;
          resetRuntimeStateForProject();
          renderHome();
        }
        return;
      }
      if (action === "reset-criteria") {
        const defaults = root.C32Model.defaultCriteria();
        state.settings.criteria = Object.assign({}, defaults);
        root.C32Storage.saveSettings(state.settings);
        if (state.project) {
          performProjectAction("Restaurar critérios", () => { state.project.criteria = Object.assign({}, defaults); });
          saveDraft();
        }
        showToast("Critérios originais restaurados.");
        return renderSettings();
      }
      if (action === "open-project") return root.C32Native.openProject(receiveProject);
      if (action === "add-reference") {
        performProjectAction("Adicionar referência", () => state.project.station.references.push(root.C32Model.createReference()));
        saveDraft(); return renderSetup();
      }
      if (action === "delete-reference") {
        performProjectAction("Excluir referência", () => state.project.station.references.splice(Number(button.dataset.index), 1));
        saveDraft(); return renderSetup();
      }
      if (action === "move-reference") {
        performProjectAction("Reordenar referência", () => moveItem(state.project.station.references, Number(button.dataset.index), Number(button.dataset.direction)));
        saveDraft(); return renderSetup();
      }
      if (action === "begin-acquisition") return beginAcquisition();
      if (action === "switch-run") return await switchRun(button.dataset.run);
      if (action === "add-lance") {
        const run = state.project[state.activeRun].lances;
        const rulerStatus = rulerTopologyStatus(state.activeRun, run);
        if (state.activeRun === "ida" && !rulerStatus.valid) {
          showToast(rulerTopologyMessage("ida"), "error");
          return;
        }

        // v0.1.20: na VOLTA manual, ADICIONAR LANCE atua no início operacional.
        // Como a Régua é a âncora inicial, o primeiro lance A=Régua → B é dividido
        // em Régua → novo ponto → B. A ordem visual invertida não altera o array.
        if (state.activeRun === "volta" && rulerStatus.hasRuler && run.length) {
          const splitIndex = 0;
          const current = run[splitIndex];
          const oldTo = current.to;
          const hasData = root.C32Model.lanceHasAcquisitionData(current);
          if (hasData) {
            const message = `O lance ${current.from || "Régua"} → ${oldTo || "?"} possui leituras.\n\nAo adicionar um novo lance depois da Régua, essas leituras serão limpas e deverão ser refeitas.\n\nDeseja continuar?`;
            if (!confirm(message)) return;
          }
          performProjectAction("Adicionar lance depois da Régua na VOLTA", () => {
            current.to = "";
            if (hasData) root.C32Model.clearLanceAcquisitionData(current);
            run.splice(1, 0, root.C32Model.emptyLance("", oldTo));
            markVoltaPtTopologyCustomized();
          }, "structural");
          saveDraft(); renderAcquisition();
          requestAnimationFrame(() => {
            const card = document.getElementById(`lance-volta-${splitIndex}`);
            card?.scrollIntoView({ behavior: "smooth", block: "start" });
            const input = app.querySelector(`[data-path="volta.lances.${splitIndex}.to"]`);
            if (input) input.focus({ preventScroll: true });
          });
          return;
        }

        // v0.1.19: se a IDA já termina na Régua, ampliar o caminhamento significa
        // inserir um novo ponto ANTES dela. A Régua nunca deixa de ser terminal.
        if (state.activeRun === "ida" && rulerStatus.hasRuler && run.length) {
          const splitIndex = run.length - 1;
          const current = run[splitIndex];
          const oldTo = current.to;
          const hasData = root.C32Model.lanceHasAcquisitionData(current);
          if (hasData) {
            const message = `O lance ${current.from || "?"} → ${oldTo || "Régua"} possui leituras.\n\nAo adicionar um novo lance antes da Régua, essas leituras pertencentes ao lance atual serão limpas e deverão ser refeitas.\n\nDeseja continuar?`;
            if (!confirm(message)) return;
          }
          performProjectAction("Adicionar lance antes da Régua", () => {
            current.to = "";
            if (hasData) root.C32Model.clearLanceAcquisitionData(current);
            run.push(root.C32Model.emptyLance("", oldTo));
            markIdaStructureDirty("pt-topology");
          }, "structural");
          saveDraft(); renderAcquisition();
          requestAnimationFrame(() => {
            const card = document.getElementById(`lance-ida-${splitIndex}`);
            card?.scrollIntoView({ behavior: "smooth", block: "start" });
            const input = app.querySelector(`[data-path="ida.lances.${splitIndex}.to"]`);
            if (input) input.focus({ preventScroll: true });
          });
          return;
        }

        const addedIndex = run.length;
        performProjectAction("Adicionar lance", () => {
          const from = run.length ? run[run.length - 1].to : "";
          run.push(root.C32Model.emptyLance(from, ""));
          if (state.activeRun === "ida") markIdaStructureDirty("pt-topology");
          else markVoltaPtTopologyCustomized();
        }, "structural");
        saveDraft(); renderAcquisition();
        requestAnimationFrame(() => document.getElementById(`lance-${state.activeRun}-${addedIndex}`)?.scrollIntoView({ behavior: "smooth", block: "start" }));
        return;
      }
      if (action === "delete-lance") {
        const run = state.project[state.activeRun].lances;
        const index = Number(button.dataset.index);
        const current = run[index];
        if (!current) return;
        if (root.C32Model.lanceHasAcquisitionData(current)) {
          if (!confirm(`O lance ${current.from || "?"} → ${current.to || "?"} possui dados.\n\nDeseja excluir o lance e apagar essas leituras?`)) return;
        }
        performProjectAction("Excluir lance", () => {
          run.splice(index, 1);
          if (state.activeRun === "ida") markIdaStructureDirty("pt-topology");
          else markVoltaPtTopologyCustomized();
        }, "structural");
        saveDraft(); return renderAcquisition();
      }
      if (action === "insert-pt") {
        const run = state.project[state.activeRun].lances;
        const index = Number(button.dataset.index);
        const current = run[index];
        if (!current) return;
        const oldTo = current.to;
        const pt = nextPtName();
        if (root.C32Model.lanceHasAcquisitionData(current)) {
          if (!confirm(`O lance ${current.from || "?"} → ${oldTo || "?"} possui leituras.\nAo inserir ${pt}, essas leituras serão apagadas porque pertencem ao lance anterior.\n\nDeseja continuar?`)) return;
        }
        performProjectAction(`Inserir ${pt}`, () => {
          current.to = pt;
          root.C32Model.clearLanceAcquisitionData(current);
          run.splice(index + 1, 0, root.C32Model.emptyLance(pt, oldTo));
          if (state.activeRun === "ida") markIdaStructureDirty("pt-topology");
          else markVoltaPtTopologyCustomized();
        }, "structural");
        saveDraft();
        renderAcquisition();
        if (state.activeRun === "volta") {
          requestAnimationFrame(() => document.getElementById(`lance-volta-${index}`)?.scrollIntoView({ behavior: "smooth", block: "start" }));
        }
        return;
      }
      if (action === "save-project") return saveProjectFile(false);
      if (action === "share-project") return saveProjectFile(true);
      if (action === "generate-scheme-image") return await generateSchemeImage(false);
      if (action === "share-scheme-image") return await generateSchemeImage(true);
      if (action === "generate-ods") return await generateOds(false);
      if (action === "share-ods") return await generateOds(true);
    } catch (error) {
      state.busy = false;
      state.busyAction = "";
      showToast(error.message || "Não foi possível concluir a ação.", "error");
    }
  });

  function moveItem(array, index, direction) {
    const target = index + direction;
    if (index < 0 || target < 0 || index >= array.length || target >= array.length) return;
    [array[index], array[target]] = [array[target], array[index]];
  }

  function formatDateTime(iso) {
    if (!iso) return "data desconhecida";
    try { return new Date(iso).toLocaleString("pt-BR"); } catch (_) { return iso; }
  }

  document.getElementById("project-file-input").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try { receiveProject(null, await file.text(), file.name); }
    catch (error) { receiveProject(error); }
    event.target.value = "";
  });

  root.C32Native.setResultReceiver((action, success, message) => {
    if (!success) showToast(message || `Falha ao ${action}.`, "error");
  });

  root.C32App = { state, render, receiveProject, recalculate, go, saveDraft, showToast, navigateBack, handleAndroidBack, syncLevelingScreenState };
  state.settings = root.C32Storage.loadSettings() || {};
  state.settings.criteria = root.C32Model.normalizeCriteria(state.settings.criteria);
  if (root.history && typeof root.history.replaceState === "function") {
    root.history.replaceState(historySnapshot("home", { depth: 0 }), "");
    root.addEventListener("popstate", onHistoryPop);
  }
  renderHome();
})(window);
