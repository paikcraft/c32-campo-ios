(function (root) {
  "use strict";

  const DB_NAME = "c32-campo-v2";
  const DB_VERSION = 1;
  const STORES = Object.freeze({ stations: "stations", f43: "f43", levelings: "levelings" });
  const memory = { stations: new Map(), f43: new Map(), levelings: new Map() };
  let databasePromise = null;

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function normalize(value) {
    return String(value == null ? "" : value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim()
      .replace(/\s+/g, " ")
      .toUpperCase();
  }

  function stationIdentity(record) {
    const source = record || {};
    const parts = [source.stationCode, source.anaCode, source.name, source.river, source.locality, source.state]
      .map(normalize);
    return parts.join("|");
  }

  function prepareStation(record) {
    const output = Object.assign({}, clone(record));
    output.id = String(output.id || (root.C32Model && root.C32Model.id ? root.C32Model.id("station") : `station-${Date.now()}`));
    output.name = String(output.name || "").trim();
    output.river = String(output.river || "").trim();
    output.locality = String(output.locality || "").trim();
    output.municipality = String(output.municipality || "").trim();
    output.state = String(output.state || "").trim();
    output.nameNorm = normalize(output.name);
    output.riverNorm = normalize(output.river);
    output.localityNorm = normalize(output.locality);
    output.identityKey = stationIdentity(output);
    output.updatedAt = new Date().toISOString();
    if (!output.createdAt) output.createdAt = output.updatedAt;
    return output;
  }

  function prepareChild(record, storeName) {
    const output = Object.assign({}, clone(record));
    const prefix = storeName === STORES.f43 ? "f43" : "leveling";
    output.id = String(output.id || (root.C32Model && root.C32Model.id ? root.C32Model.id(prefix) : `${prefix}-${Date.now()}`));
    output.stationId = String(output.stationId || "");
    output.kind = String(output.kind || (storeName === STORES.f43 ? "standard" : "leveling"));
    output.dateKey = String(output.dateKey || output.updateDate || output.date || output.year || "");
    output.updatedAt = new Date().toISOString();
    if (!output.createdAt) output.createdAt = output.updatedAt;
    return output;
  }

  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("Falha no banco local."));
    });
  }

  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onabort = () => reject(transaction.error || new Error("Transação cancelada."));
      transaction.onerror = () => reject(transaction.error || new Error("Falha na transação local."));
    });
  }

  async function open() {
    if (!root.indexedDB) return null;
    if (databasePromise) return databasePromise;
    databasePromise = new Promise((resolve, reject) => {
      const request = root.indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        const stations = db.createObjectStore(STORES.stations, { keyPath: "id" });
        stations.createIndex("nameNorm", "nameNorm", { unique: false });
        stations.createIndex("riverNorm", "riverNorm", { unique: false });
        stations.createIndex("localityNorm", "localityNorm", { unique: false });
        stations.createIndex("identityKey", "identityKey", { unique: false });

        const f43 = db.createObjectStore(STORES.f43, { keyPath: "id" });
        f43.createIndex("stationId", "stationId", { unique: false });
        f43.createIndex("fingerprint", "fingerprint", { unique: false });
        f43.createIndex("stationKind", ["stationId", "kind"], { unique: false });

        const levelings = db.createObjectStore(STORES.levelings, { keyPath: "id" });
        levelings.createIndex("stationId", "stationId", { unique: false });
        levelings.createIndex("fingerprint", "fingerprint", { unique: false });
        levelings.createIndex("stationDate", ["stationId", "dateKey"], { unique: false });
      };
      request.onsuccess = () => {
        const db = request.result;
        db.onversionchange = () => db.close();
        resolve(db);
      };
      request.onerror = () => {
        databasePromise = null;
        reject(request.error || new Error("Não foi possível abrir o Banco de Estações."));
      };
    });
    return databasePromise;
  }

  async function put(storeName, value) {
    const prepared = storeName === STORES.stations ? prepareStation(value) : prepareChild(value, storeName);
    const db = await open();
    if (!db) {
      memory[storeName].set(prepared.id, clone(prepared));
      return clone(prepared);
    }
    const transaction = db.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).put(prepared);
    await transactionDone(transaction);
    return clone(prepared);
  }

  async function get(storeName, id) {
    const db = await open();
    if (!db) return clone(memory[storeName].get(String(id)) || null);
    const transaction = db.transaction(storeName, "readonly");
    return clone(await requestResult(transaction.objectStore(storeName).get(String(id))) || null);
  }

  async function remove(storeName, id) {
    const db = await open();
    if (!db) return memory[storeName].delete(String(id));
    const transaction = db.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).delete(String(id));
    await transactionDone(transaction);
    return true;
  }

  async function collect(storeName, predicate, limit) {
    const maximum = Number.isFinite(limit) ? limit : 1000;
    const db = await open();
    if (!db) {
      const values = [];
      for (const value of memory[storeName].values()) {
        if (!predicate || predicate(value)) values.push(clone(value));
        if (values.length >= maximum) break;
      }
      return values;
    }
    const transaction = db.transaction(storeName, "readonly");
    const store = transaction.objectStore(storeName);
    return new Promise((resolve, reject) => {
      const values = [];
      const request = store.openCursor();
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor || values.length >= maximum) return resolve(values);
        if (!predicate || predicate(cursor.value)) values.push(clone(cursor.value));
        cursor.continue();
      };
      request.onerror = () => reject(request.error || new Error("Falha ao consultar o Banco de Estações."));
    });
  }

  async function byIndex(storeName, indexName, key) {
    const db = await open();
    if (!db) return collect(storeName, (item) => {
      if (indexName === "stationId") return item.stationId === key;
      if (indexName === "fingerprint") return item.fingerprint === key;
      if (indexName === "identityKey") return item.identityKey === key;
      return false;
    });
    const transaction = db.transaction(storeName, "readonly");
    const result = await requestResult(transaction.objectStore(storeName).index(indexName).getAll(key));
    return clone(result || []);
  }

  async function searchStations(query, mode) {
    const term = normalize(query);
    const field = mode === "river" ? "riverNorm" : mode === "locality" ? "localityNorm" : "nameNorm";
    const values = await collect(STORES.stations, (station) => !term || String(station[field] || "").includes(term), 250);
    return values.sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
  }

  async function identifyStation(candidate) {
    const identity = stationIdentity(candidate);
    const exact = (await byIndex(STORES.stations, "identityKey", identity))[0];
    if (exact) return { status: "exact", candidates: [exact] };
    const all = await collect(STORES.stations, (station) => {
      const pairs = [
        [candidate.stationCode, station.stationCode],
        [candidate.anaCode, station.anaCode],
        [candidate.name, station.name],
        [candidate.river, station.river],
        [candidate.locality, station.locality],
        [candidate.state, station.state]
      ].filter((pair) => normalize(pair[0]) && normalize(pair[1]));
      const matches = pairs.filter((pair) => normalize(pair[0]) === normalize(pair[1])).length;
      return matches >= 2 || (matches === 1 && pairs.length === 1);
    }, 20);
    return { status: all.length ? "ambiguous" : "new", candidates: all };
  }

  async function deleteStation(id) {
    const stationId = String(id);
    const db = await open();
    if (!db) {
      memory.stations.delete(stationId);
      for (const [key, item] of memory.f43) if (item.stationId === stationId) memory.f43.delete(key);
      for (const [key, item] of memory.levelings) if (item.stationId === stationId) memory.levelings.delete(key);
      return true;
    }
    const transaction = db.transaction([STORES.stations, STORES.f43, STORES.levelings], "readwrite");
    transaction.objectStore(STORES.stations).delete(stationId);
    for (const storeName of [STORES.f43, STORES.levelings]) {
      const store = transaction.objectStore(storeName);
      const request = store.index("stationId").openKeyCursor(root.IDBKeyRange.only(stationId));
      request.onsuccess = () => {
        const cursor = request.result;
        if (cursor) {
          store.delete(cursor.primaryKey);
          cursor.continue();
        }
      };
    }
    await transactionDone(transaction);
    return true;
  }

  async function getSnapshot(selection) {
    const config = selection || { type: "all" };
    let stations = [];
    let f43 = [];
    let levelings = [];
    if (config.type === "leveling") {
      const item = await get(STORES.levelings, config.id);
      if (!item) throw new Error("Nivelamento não encontrado.");
      const station = await get(STORES.stations, item.stationId);
      stations = station ? [station] : [];
      levelings = [item];
    } else if (config.type === "station") {
      const station = await get(STORES.stations, config.id);
      if (!station) throw new Error("Estação não encontrada.");
      stations = [station];
      f43 = await byIndex(STORES.f43, "stationId", station.id);
      levelings = await byIndex(STORES.levelings, "stationId", station.id);
    } else {
      stations = await collect(STORES.stations, null, Number.MAX_SAFE_INTEGER);
      f43 = await collect(STORES.f43, null, Number.MAX_SAFE_INTEGER);
      levelings = await collect(STORES.levelings, null, Number.MAX_SAFE_INTEGER);
    }
    return { stations, f43, levelings };
  }

  async function applyBatch(batch) {
    const input = batch || {};
    const stations = (input.stations || []).map(prepareStation);
    const f43 = (input.f43 || []).map((item) => prepareChild(item, STORES.f43));
    const levelings = (input.levelings || []).map((item) => prepareChild(item, STORES.levelings));
    const db = await open();
    if (!db) {
      stations.forEach((item) => memory.stations.set(item.id, clone(item)));
      f43.forEach((item) => memory.f43.set(item.id, clone(item)));
      levelings.forEach((item) => memory.levelings.set(item.id, clone(item)));
      return { stations: stations.length, f43: f43.length, levelings: levelings.length };
    }
    const transaction = db.transaction([STORES.stations, STORES.f43, STORES.levelings], "readwrite");
    stations.forEach((item) => transaction.objectStore(STORES.stations).put(item));
    f43.forEach((item) => transaction.objectStore(STORES.f43).put(item));
    levelings.forEach((item) => transaction.objectStore(STORES.levelings).put(item));
    await transactionDone(transaction);
    return { stations: stations.length, f43: f43.length, levelings: levelings.length };
  }

  async function resetForTests() {
    memory.stations.clear(); memory.f43.clear(); memory.levelings.clear();
    if (!root.indexedDB) return;
    const db = await open();
    db.close();
    databasePromise = null;
    await requestResult(root.indexedDB.deleteDatabase(DB_NAME));
  }

  const api = {
    DB_NAME,
    DB_VERSION,
    STORES,
    normalize,
    stationIdentity,
    prepareStation,
    open,
    putStation: (record) => put(STORES.stations, record),
    getStation: (id) => get(STORES.stations, id),
    deleteStation,
    searchStations,
    identifyStation,
    putF43: (record) => put(STORES.f43, record),
    getF43: (id) => get(STORES.f43, id),
    deleteF43: (id) => remove(STORES.f43, id),
    listF43: (stationId) => byIndex(STORES.f43, "stationId", String(stationId)),
    findF43ByFingerprint: (fingerprint) => byIndex(STORES.f43, "fingerprint", fingerprint),
    putLeveling: (record) => put(STORES.levelings, record),
    getLeveling: (id) => get(STORES.levelings, id),
    deleteLeveling: (id) => remove(STORES.levelings, id),
    listLevelings: (stationId) => byIndex(STORES.levelings, "stationId", String(stationId)),
    findLevelingByFingerprint: (fingerprint) => byIndex(STORES.levelings, "fingerprint", fingerprint),
    getSnapshot,
    applyBatch,
    resetForTests,
    isPersistent: () => Boolean(root.indexedDB)
  };

  root.C32StationDb = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
