(function () {
  "use strict";
  if (!Promise.withResolvers) {
    Promise.withResolvers = function () {
      let resolve; let reject;
      const promise = new Promise((ok, fail) => { resolve = ok; reject = fail; });
      return { promise, resolve, reject };
    };
  }
  if (!Uint8Array.prototype.toHex) {
    Object.defineProperty(Uint8Array.prototype, "toHex", {
      value: function () {
        let output = "";
        for (let index = 0; index < this.length; index += 1) output += this[index].toString(16).padStart(2, "0");
        return output;
      }
    });
  }
  if (!Map.prototype.getOrInsertComputed) {
    Object.defineProperty(Map.prototype, "getOrInsertComputed", {
      value: function (key, callback) {
        if (!this.has(key)) this.set(key, callback(key));
        return this.get(key);
      }
    });
  }
})();
