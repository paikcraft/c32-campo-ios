(function (root) {
  "use strict";

  const APP_VERSION = "2.1.2";
  const FORMAT_VERSION = 4;
  const PROJECT_FORMAT = "c32-campo-project";
  const DEFAULT_CRITERIA = Object.freeze({
    vrfToleranceMm: 2,
    maxSightDistanceM: 50,
    closureUpTo1KmMm: 8,
    closureAbove1KmCoefficientMm: 8,
    standardToleranceMm: 2
  });

  function id(prefix) {
    const random = Math.random().toString(36).slice(2, 10);
    return `${prefix}-${Date.now().toString(36)}-${random}`;
  }

  function today() {
    return new Date().toISOString().slice(0, 10);
  }

  function now() {
    return new Date().toISOString();
  }

  function emptyReading() {
    return { sup: "", cen: "", inf: "" };
  }

  function emptyLance(from = "", to = "") {
    return {
      id: id("lance"),
      from,
      to,
      ar: emptyReading(),
      av: emptyReading(),
      visibility: "",
      wind: "",
      observation: ""
    };
  }

  function emptyMetadata(stationName = "") {
    return {
      documentNumber: "",
      commission: "",
      surveyNumber: "",
      chartNumber: "",
      chief: "",
      leveling: stationName ? `Estação Fluviométrica de ${stationName}` : "",
      coverObservation: "",
      observer: "",
      annotator: "",
      instrument: "",
      instrumentNumber: "",
      staffAv: "",
      staffAr: "",
      startTime: "",
      endTime: "",
      calculatedBy: "",
      checkedBy: "",
      schemeObservationPeriod: "",
      riverRegime: "",
      bottomNature: "",
      observerContact: "",
      otherInformation: ""
    };
  }

  function defaultCriteria() {
    return Object.assign({}, DEFAULT_CRITERIA);
  }

  function normalizeCriteria(source) {
    const input = source && typeof source === "object" ? source : {};
    const output = defaultCriteria();
    for (const key of Object.keys(output)) {
      const numeric = parseStoredNumber(input[key]);
      if (numeric !== null && numeric > 0) output[key] = numeric;
    }
    return output;
  }

  function createProject(stationName, existing) {
    const stamp = now();
    return {
      format: PROJECT_FORMAT,
      formatVersion: FORMAT_VERSION,
      appVersion: APP_VERSION,
      id: id("project"),
      createdAt: stamp,
      updatedAt: stamp,
      status: "draft",
      station: {
        name: String(stationName || "").trim(),
        date: today(),
        existing: Boolean(existing),
        references: [],
        checkReferences: null,
        bankStationId: "",
        executionSource: "manual",
        preparation: [],
        preparationLockedAt: "",
        referenceInputUnit: "cm",
        referenceStorageUnit: "m"
      },
      ida: { lances: [] },
      volta: { lances: [], routeMode: "auto" },
      criteria: defaultCriteria(),
      units: { referenceDifferenceInput: "cm", referenceDifferenceStorage: "m" },
      scheme: {
        principalPoint: "",
        inputMode: "principalElevation",
        principalElevationM: "",
        stationNrCm: "",
        rulerTopM: "",
        rulerObservation: ""
      },
      metadata: emptyMetadata(stationName),
      history: [{ at: stamp, action: "created" }]
    };
  }

  function decimalText(value) {
    const text = String(value == null ? "" : value).trim();
    if (!text) return null;
    if (text.includes(",") && text.includes(".")) return null;
    const normalized = text.replace(",", ".");
    if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(normalized)) return null;
    const negative = normalized.startsWith("-");
    const unsigned = normalized.replace(/^[+-]/, "");
    const parts = unsigned.split(".");
    return { negative, integer: parts[0] || "0", fraction: parts[1] || "" };
  }

  function scaleDecimalText(value, decimalPlaces, minimumFractionDigits) {
    const parsed = decimalText(value);
    if (!parsed) return null;
    const digits = parsed.integer + parsed.fraction;
    const sourcePoint = parsed.integer.length;
    const targetPoint = sourcePoint + Number(decimalPlaces || 0);
    let integer;
    let fraction;
    if (targetPoint <= 0) {
      integer = "0";
      fraction = "0".repeat(-targetPoint) + digits;
    } else if (targetPoint >= digits.length) {
      integer = digits + "0".repeat(targetPoint - digits.length);
      fraction = "";
    } else {
      integer = digits.slice(0, targetPoint);
      fraction = digits.slice(targetPoint);
    }
    integer = integer.replace(/^0+(?=\d)/, "") || "0";
    fraction = fraction.replace(/0+$/, "");
    const min = Math.max(0, Number(minimumFractionDigits || 0));
    if (fraction.length < min) fraction += "0".repeat(min - fraction.length);
    const sign = parsed.negative && (integer !== "0" || /[1-9]/.test(fraction)) ? "-" : "";
    return `${sign}${integer}${fraction ? "," + fraction : ""}`;
  }

  function centimetersToMetersText(value) {
    return scaleDecimalText(value, -2, 0);
  }

  function metersToCentimetersText(value, minimumFractionDigits = 2) {
    return scaleDecimalText(value, 2, minimumFractionDigits);
  }

  function createReference(high = "", low = "", differenceM = "", source) {
    const storedM = String(differenceM == null ? "" : differenceM);
    const differenceCm = storedM.trim() ? (metersToCentimetersText(storedM, 2) || "") : "";
    return { id: id("ref"), high, low, differenceM: storedM, differenceCm, differenceUnit: "cm", source: source || "manual" };
  }

  function suggestedRuns(references) {
    const valid = (references || []).filter((r) => r.high && r.low);
    return {
      ida: valid.map((r) => emptyLance(r.high, r.low)),
      volta: [...valid].reverse().map((r) => emptyLance(r.low, r.high))
    };
  }

  function hasText(value) {
    return String(value == null ? "" : value).trim() !== "";
  }

  function lanceHasAcquisitionData(lance) {
    if (!lance) return false;
    const readings = [
      lance.ar && lance.ar.sup,
      lance.ar && lance.ar.cen,
      lance.ar && lance.ar.inf,
      lance.av && lance.av.sup,
      lance.av && lance.av.cen,
      lance.av && lance.av.inf
    ];
    return readings.some(hasText) || [lance.visibility, lance.wind, lance.observation].some(hasText);
  }

  function runHasAcquisitionData(lances) {
    return (lances || []).some(lanceHasAcquisitionData);
  }

  function acquisitionFingerprint(lance) {
    if (!lance) return "";
    return JSON.stringify({
      ar: {
        sup: String(lance.ar && lance.ar.sup || ""),
        cen: String(lance.ar && lance.ar.cen || ""),
        inf: String(lance.ar && lance.ar.inf || "")
      },
      av: {
        sup: String(lance.av && lance.av.sup || ""),
        cen: String(lance.av && lance.av.cen || ""),
        inf: String(lance.av && lance.av.inf || "")
      },
      visibility: String(lance.visibility || ""),
      wind: String(lance.wind || ""),
      observation: String(lance.observation || "")
    });
  }

  function clearLanceAcquisitionData(lance) {
    if (!lance) return lance;
    lance.ar = emptyReading();
    lance.av = emptyReading();
    lance.visibility = "";
    lance.wind = "";
    lance.observation = "";
    return lance;
  }

  function cloneProject(project) {
    return JSON.parse(JSON.stringify(project));
  }

  function reverseRunSkeleton(lances) {
    return [...(lances || [])].reverse().map((lance) => emptyLance(lance && lance.to, lance && lance.from));
  }

  function normalizedPoint(value) {
    return String(value == null ? "" : value).trim().replace(/\s+/g, " ").toUpperCase();
  }

  function isTemporarySupportPoint(value) {
    const point = normalizedPoint(value);
    return /^PT(?:$|[-_\s]|\d)/.test(point);
  }

  function isPermanentReferenceName(value) {
    return hasText(value) && !isTemporarySupportPoint(value);
  }

  function isReferenceRename(oldName, newName) {
    const oldPoint = normalizedPoint(oldName);
    const newPoint = normalizedPoint(newName);
    return Boolean(oldPoint && newPoint && oldPoint !== newPoint
      && isPermanentReferenceName(oldName) && isPermanentReferenceName(newName));
  }

  function structureSignature(lances) {
    return (lances || []).map((lance) => `${normalizedPoint(lance && lance.from)}→${normalizedPoint(lance && lance.to)}`).join("¦");
  }

  function ptTopologySignature(lances) {
    const token = (value) => isTemporarySupportPoint(value) ? normalizedPoint(value) : (hasText(value) ? "REF" : "");
    return (lances || []).map((lance) => `${token(lance && lance.from)}→${token(lance && lance.to)}`).join("¦");
  }

  function isReverseSkeleton(idaLances, voltaLances) {
    const expected = [...(idaLances || [])].reverse();
    const actual = voltaLances || [];
    if (expected.length !== actual.length) return false;
    return expected.every((lance, index) => {
      return normalizedPoint(lance && lance.to) === normalizedPoint(actual[index] && actual[index].from)
        && normalizedPoint(lance && lance.from) === normalizedPoint(actual[index] && actual[index].to);
    });
  }

  function isReversePtTopology(idaLances, voltaLances) {
    const expected = [...(idaLances || [])].reverse();
    const actual = voltaLances || [];
    if (expected.length !== actual.length) return false;
    const token = (value) => isTemporarySupportPoint(value) ? normalizedPoint(value) : (hasText(value) ? "REF" : "");
    return expected.every((lance, index) => {
      return token(lance && lance.to) === token(actual[index] && actual[index].from)
        && token(lance && lance.from) === token(actual[index] && actual[index].to);
    });
  }

  function routePointSequence(lances) {
    const sequence = [];
    for (const lance of lances || []) {
      const from = String(lance && lance.from != null ? lance.from : "").trim();
      const to = String(lance && lance.to != null ? lance.to : "").trim();
      if (!sequence.length) {
        if (from) sequence.push(from);
        if (to) sequence.push(to);
        continue;
      }
      if (from && normalizedPoint(sequence[sequence.length - 1]) !== normalizedPoint(from)) sequence.push(from);
      if (to) sequence.push(to);
    }
    return sequence;
  }

  function permanentReferenceSequence(lances) {
    return routePointSequence(lances).filter(isPermanentReferenceName);
  }

  function referenceSequencesMatch(idaLances, voltaLances) {
    const expected = permanentReferenceSequence(idaLances).reverse().map(normalizedPoint);
    const actual = permanentReferenceSequence(voltaLances).map(normalizedPoint);
    return expected.length === actual.length && expected.every((value, index) => value === actual[index]);
  }


  // v0.1.20: uma referência permanente nova pode ser refletida na VOLTA sem
  // confundir isso com sincronização de PT. A inferência automática é aceita
  // somente quando a topologia inteira da VOLTA já coincide com o inverso da
  // IDA e a única diferença é exatamente UM ponto permanente novo. Assim é
  // seguro dividir o lance inverso existente sem adivinhar a posição de PTs.
  function inferPermanentReferenceInsertion(idaLances, voltaLances) {
    const idaPoints = routePointSequence(idaLances);
    const actual = routePointSequence(voltaLances);
    const expected = [...idaPoints].reverse();
    if (expected.length !== actual.length + 1) return null;
    const actualNorm = actual.map(normalizedPoint);
    for (let index = 1; index < expected.length - 1; index += 1) {
      const candidate = expected[index];
      if (!isPermanentReferenceName(candidate)) continue;
      const without = expected.slice(0, index).concat(expected.slice(index + 1)).map(normalizedPoint);
      if (without.length !== actualNorm.length || !without.every((value, i) => value === actualNorm[i])) continue;
      const from = expected[index - 1];
      const to = expected[index + 1];
      const matches = (voltaLances || []).filter((lance) => lanceKey(lance && lance.from, lance && lance.to) === lanceKey(from, to));
      if (matches.length !== 1) return null;
      return { newName: candidate, from, to, targetId: matches[0].id || null };
    }
    return null;
  }

  function applyPermanentReferenceInsertion(voltaLances, insertion, options) {
    if (!insertion) return { applied: false };
    const config = options || {};
    const targetIndex = (voltaLances || []).findIndex((lance) => {
      if (insertion.targetId && lance && lance.id === insertion.targetId) return true;
      return lanceKey(lance && lance.from, lance && lance.to) === lanceKey(insertion.from, insertion.to);
    });
    if (targetIndex < 0) return { applied: false, ambiguous: true };
    const target = voltaLances[targetIndex];
    const hasData = lanceHasAcquisitionData(target);
    if (hasData && !config.allowDiscardAffectedData) {
      return {
        applied: false,
        blockedByData: true,
        affected: [{ from: target.from, to: target.to, id: target.id }]
      };
    }
    const oldTo = target.to;
    target.to = String(insertion.newName || '');
    if (hasData) clearLanceAcquisitionData(target);
    const second = emptyLance(String(insertion.newName || ''), oldTo);
    voltaLances.splice(targetIndex + 1, 0, second);
    return {
      applied: true,
      targetIndex,
      created: 1,
      cleared: hasData ? 1 : 0,
      insertion: Object.assign({}, insertion)
    };
  }

  function inferReferenceRenameHints(idaLances, voltaLances) {
    const expectedRaw = permanentReferenceSequence(idaLances).reverse();
    const actualRaw = permanentReferenceSequence(voltaLances);
    if (expectedRaw.length !== actualRaw.length) return { hints: [], ambiguous: true, reason: "reference-count-mismatch" };

    const expected = expectedRaw.map(normalizedPoint);
    const actual = actualRaw.map(normalizedPoint);
    const expectedCounts = new Map();
    const actualCounts = new Map();
    expected.forEach((value) => expectedCounts.set(value, (expectedCounts.get(value) || 0) + 1));
    actual.forEach((value) => actualCounts.set(value, (actualCounts.get(value) || 0) + 1));

    const hints = [];
    const oldTargets = new Map();
    const newSources = new Map();
    for (let index = 0; index < expected.length; index += 1) {
      if (expected[index] === actual[index]) continue;
      const oldName = actualRaw[index];
      const newName = expectedRaw[index];
      const oldNorm = actual[index];
      const newNorm = expected[index];
      if (!oldNorm || !newNorm || !isReferenceRename(oldName, newName)) return { hints: [], ambiguous: true, reason: "non-reference-mismatch" };
      if ((actualCounts.get(oldNorm) || 0) !== 1 || (expectedCounts.get(newNorm) || 0) !== 1) {
        return { hints: [], ambiguous: true, reason: "duplicate-reference" };
      }
      if ((oldTargets.has(oldNorm) && oldTargets.get(oldNorm) !== newNorm) || (newSources.has(newNorm) && newSources.get(newNorm) !== oldNorm)) {
        return { hints: [], ambiguous: true, reason: "conflicting-reference-map" };
      }
      oldTargets.set(oldNorm, newNorm);
      newSources.set(newNorm, oldNorm);
      hints.push({ oldName, newName, physicalChange: false, inferred: true });
    }
    return { hints, ambiguous: false };
  }

  function lanceKey(from, to) {
    return `${normalizedPoint(from)}\u0000${normalizedPoint(to)}`;
  }

  function normalizeSyncOptions(forceOrOptions) {
    if (typeof forceOrOptions === "boolean") return { force: forceOrOptions };
    return forceOrOptions && typeof forceOrOptions === "object" ? forceOrOptions : {};
  }

  function applyEditedLanceHint(existing, hint) {
    if (!hint || typeof hint !== "object") return { applied: false };
    const oldKey = lanceKey(hint.oldTo, hint.oldFrom);
    const matches = [];
    for (let index = 0; index < existing.length; index += 1) {
      if (lanceKey(existing[index] && existing[index].from, existing[index] && existing[index].to) === oldKey) matches.push(index);
    }
    if (matches.length !== 1) return { applied: false, ambiguous: matches.length > 1 };
    const item = existing[matches[0]];
    item.from = String(hint.newTo == null ? "" : hint.newTo);
    item.to = String(hint.newFrom == null ? "" : hint.newFrom);
    return { applied: true };
  }

  function mergeReferenceRenameHints(provided, inferred) {
    const merged = [];
    const seenOld = new Set();
    for (const source of [Array.isArray(provided) ? provided : [], Array.isArray(inferred) ? inferred : []]) {
      for (const hint of source) {
        if (!hint || !isReferenceRename(hint.oldName, hint.newName)) continue;
        const oldNorm = normalizedPoint(hint.oldName);
        if (seenOld.has(oldNorm)) continue;
        seenOld.add(oldNorm);
        merged.push(Object.assign({}, hint));
      }
    }
    return merged;
  }

  function inspectPointRenameHints(existing, hints) {
    const physicalAffected = [];
    const renamedPairs = [];
    const affectedIds = new Set();
    for (const hint of Array.isArray(hints) ? hints : []) {
      const oldName = normalizedPoint(hint && hint.oldName);
      const newName = String(hint && hint.newName == null ? "" : hint.newName).trim();
      if (!oldName || !newName || oldName === normalizedPoint(newName) || !isReferenceRename(hint.oldName, newName)) continue;
      let pairApplied = false;
      for (const lance of existing || []) {
        const touchesOld = normalizedPoint(lance && lance.from) === oldName || normalizedPoint(lance && lance.to) === oldName;
        if (!touchesOld) continue;
        pairApplied = true;
        if (hint.physicalChange && !affectedIds.has(lance.id)) {
          affectedIds.add(lance.id);
          if (lanceHasAcquisitionData(lance)) physicalAffected.push({ from: lance.from, to: lance.to, id: lance.id });
        }
      }
      if (pairApplied) renamedPairs.push({ oldName: String(hint.oldName || ""), newName });
    }
    return { physicalAffected, renamedPairs };
  }

  function applyPointRenameHints(existing, hints, options) {
    const config = options || {};
    let applied = 0;
    const renamedPairs = [];
    const clearedIds = new Set();
    for (const hint of Array.isArray(hints) ? hints : []) {
      const oldName = normalizedPoint(hint && hint.oldName);
      const newName = String(hint && hint.newName == null ? "" : hint.newName).trim();
      if (!oldName || !newName || oldName === normalizedPoint(newName) || !isReferenceRename(hint.oldName, newName)) continue;
      let pairApplied = false;
      for (const lance of existing || []) {
        const fromMatches = normalizedPoint(lance && lance.from) === oldName;
        const toMatches = normalizedPoint(lance && lance.to) === oldName;
        if (!fromMatches && !toMatches) continue;
        pairApplied = true;
        if (hint.physicalChange && config.allowPhysicalRenameDataClear && !clearedIds.has(lance.id)) {
          clearedIds.add(lance.id);
          clearLanceAcquisitionData(lance);
        }
        if (fromMatches) { lance.from = newName; applied += 1; }
        if (toMatches) { lance.to = newName; applied += 1; }
      }
      if (pairApplied) renamedPairs.push({ oldName: String(hint.oldName || ""), newName });
    }
    return { applied, renamedPairs, cleared: clearedIds.size };
  }

  function cloneLances(lances) {
    return JSON.parse(JSON.stringify(lances || []));
  }

  function syncVoltaFromIda(project, forceOrOptions) {
    if (!project || !project.ida || !project.volta) return { synced: false, reason: "Projeto inválido", reasonCode: "invalid-project" };
    const options = normalizeSyncOptions(forceOrOptions);
    const routeMode = project.volta.routeMode === "manual" ? "manual" : "auto";
    const providedHints = Array.isArray(options.renameHints) ? options.renameHints : [];
    const inferred = inferReferenceRenameHints(project.ida.lances, project.volta.lances);
    const renameHints = mergeReferenceRenameHints(providedHints, inferred.ambiguous ? [] : inferred.hints);
    const inspection = inspectPointRenameHints(project.volta.lances, renameHints);
    const referenceInsertion = inferPermanentReferenceInsertion(project.ida.lances, project.volta.lances);

    if (inspection.physicalAffected.length && !options.allowPhysicalRenameDataClear) {
      return {
        synced: false,
        reason: "A referência foi substituída fisicamente e há leituras da VOLTA ligadas ao nome anterior.",
        reasonCode: "physical-reference-replacement",
        affected: inspection.physicalAffected,
        renamedPairs: inspection.renamedPairs
      };
    }

    // v0.1.20: inserção inequívoca de referência permanente tem prioridade sobre
    // routeMode=manual. Ela divide somente o lance inverso correspondente e preserva
    // todos os demais PTs/lances da VOLTA. Se o lance possui aquisição, exige autorização.
    if (referenceInsertion) {
      const insertionResult = applyPermanentReferenceInsertion(project.volta.lances, referenceInsertion, {
        allowDiscardAffectedData: Boolean(options.allowDiscardAffectedData)
      });
      if (insertionResult.blockedByData) {
        return {
          synced: false,
          reason: "A nova referência permanente divide um lance da VOLTA que já possui leituras.",
          reasonCode: "reference-insertion-would-discard-readings",
          affected: insertionResult.affected || [],
          insertion: referenceInsertion
        };
      }
      if (insertionResult.applied) {
        const renameResult = applyPointRenameHints(project.volta.lances, renameHints, {
          allowPhysicalRenameDataClear: Boolean(options.allowPhysicalRenameDataClear)
        });
        return {
          synced: true,
          topologySynced: false,
          referenceInsertionSynced: true,
          manualTopologyPreserved: routeMode === "manual",
          preserved: Math.max(0, project.volta.lances.length - 1),
          created: 1,
          removed: 0,
          removedWithData: 0,
          physicalCleared: renameResult.cleared + insertionResult.cleared,
          renamed: Boolean(renameResult.applied),
          renamedPairs: renameResult.renamedPairs,
          insertion: referenceInsertion
        };
      }
    }

    // v0.1.14: sincronização nominal pode ser explicitamente limitada às referências.
    // Isso impede que uma renomeação de RN reconstrua PTs quando IDA e VOLTA seguem
    // caminhos diferentes, mesmo se um projeto legado ainda estiver com routeMode=auto.
    if (options.referenceOnly) {
      const renameResult = applyPointRenameHints(project.volta.lances, renameHints, {
        allowPhysicalRenameDataClear: Boolean(options.allowPhysicalRenameDataClear)
      });
      return {
        synced: true,
        topologySynced: false,
        referenceOnly: true,
        preserved: project.volta.lances.length,
        created: 0,
        removed: 0,
        removedWithData: 0,
        physicalCleared: renameResult.cleared,
        renamed: Boolean(renameResult.applied),
        renamedPairs: renameResult.renamedPairs,
        inferredReferenceSync: renameHints.some((hint) => hint.inferred)
      };
    }

    // routeMode=manual controla somente a topologia dos PTs. Referências permanentes
    // continuam sincronizando no próprio objeto de lance, sem reconstruir a VOLTA.
    if (routeMode === "manual" && !options.force) {
      const renameResult = applyPointRenameHints(project.volta.lances, renameHints, {
        allowPhysicalRenameDataClear: Boolean(options.allowPhysicalRenameDataClear)
      });
      return {
        synced: true,
        topologySynced: false,
        manualTopologyPreserved: true,
        preserved: project.volta.lances.length,
        created: 0,
        removed: 0,
        removedWithData: 0,
        physicalCleared: renameResult.cleared,
        renamed: Boolean(renameResult.applied),
        renamedPairs: renameResult.renamedPairs,
        inferredReferenceSync: renameHints.some((hint) => hint.inferred)
      };
    }

    // Caminho rápido para renomeação pura em VOLTA automática: se após trocar apenas
    // from/to a topologia já coincide com a IDA, altera os objetos existentes in-place.
    if (!options.editedIdaLance) {
      const preview = cloneLances(project.volta.lances);
      applyPointRenameHints(preview, renameHints, {
        allowPhysicalRenameDataClear: Boolean(options.allowPhysicalRenameDataClear)
      });
      if (isReverseSkeleton(project.ida.lances, preview)) {
        const renameResult = applyPointRenameHints(project.volta.lances, renameHints, {
          allowPhysicalRenameDataClear: Boolean(options.allowPhysicalRenameDataClear)
        });
        return {
          synced: true,
          topologySynced: false,
          directReferenceSync: true,
          preserved: project.volta.lances.length,
          created: 0,
          removed: 0,
          removedWithData: 0,
          physicalCleared: renameResult.cleared,
          renamed: Boolean(renameResult.applied),
          renamedPairs: renameResult.renamedPairs,
          inferredReferenceSync: renameHints.some((hint) => hint.inferred)
        };
      }
    }

    const expected = reverseRunSkeleton(project.ida.lances);
    const existing = cloneLances(project.volta.lances);
    const hintResult = applyEditedLanceHint(existing, options.editedIdaLance);
    const renameResult = applyPointRenameHints(existing, renameHints, {
      allowPhysicalRenameDataClear: Boolean(options.allowPhysicalRenameDataClear)
    });
    if (hintResult.ambiguous) {
      return {
        synced: false,
        reason: "Correspondência ambígua na VOLTA; os dados foram preservados.",
        reasonCode: "ambiguous-names"
      };
    }

    const buckets = new Map();
    for (const lance of existing) {
      const key = lanceKey(lance && lance.from, lance && lance.to);
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(lance);
    }

    const expectedCounts = new Map();
    for (const lance of expected) {
      const key = lanceKey(lance && lance.from, lance && lance.to);
      expectedCounts.set(key, (expectedCounts.get(key) || 0) + 1);
    }
    for (const [key, items] of buckets.entries()) {
      if ((items.length > 1 || (expectedCounts.get(key) || 0) > 1) && items.some(lanceHasAcquisitionData)) {
        return {
          synced: false,
          reason: "Há lances com nomes repetidos e leituras na VOLTA; não é seguro decidir a correspondência automaticamente.",
          reasonCode: "ambiguous-names"
        };
      }
    }

    const used = new Set();
    const next = [];
    let preserved = 0;
    let created = 0;
    for (const skeleton of expected) {
      const key = lanceKey(skeleton.from, skeleton.to);
      const candidates = buckets.get(key) || [];
      const match = candidates.find((item) => !used.has(item));
      if (match) {
        used.add(match);
        match.from = skeleton.from;
        match.to = skeleton.to;
        next.push(match);
        preserved += 1;
      } else {
        next.push(skeleton);
        created += 1;
      }
    }

    const removed = existing.filter((item) => !used.has(item));
    const removedWithData = removed.filter(lanceHasAcquisitionData);
    if (removedWithData.length && !options.allowDiscardAffectedData) {
      return {
        synced: false,
        reason: "A alteração atingiria lance(s) já lido(s) na VOLTA. A sincronização foi cancelada para não apagar leituras.",
        reasonCode: "would-discard-readings",
        affected: removedWithData.map((item) => ({ from: item.from, to: item.to, id: item.id }))
      };
    }

    project.volta.routeMode = "auto";
    project.volta.lances = next;
    return {
      synced: true,
      topologySynced: true,
      preserved,
      created,
      removed: removed.length,
      removedWithData: removedWithData.length,
      physicalCleared: renameResult.cleared,
      renamed: Boolean(hintResult.applied || renameResult.applied),
      renamedPairs: renameResult.renamedPairs,
      inferredReferenceSync: renameHints.some((hint) => hint.inferred)
    };
  }

  function parseStoredNumber(value) {
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    const text = String(value == null ? "" : value).trim();
    if (!text) return null;
    const normalized = text.includes(",") && text.includes(".")
      ? text.replace(/\./g, "").replace(",", ".")
      : text.replace(",", ".");
    const number = Number(normalized);
    return Number.isFinite(number) ? number : null;
  }

  function storedDecimal(value) {
    return String(Math.round(value * 1000000) / 1000000).replace(".", ",");
  }

  function migrateProject(raw) {
    if (!raw || typeof raw !== "object") throw new Error("Arquivo de projeto vazio ou inválido.");
    if (raw.format !== PROJECT_FORMAT) throw new Error("O arquivo não é um projeto do C32 Campo.");
    if (Number(raw.formatVersion) > FORMAT_VERSION) {
      throw new Error("Este projeto foi criado por uma versão mais nova do aplicativo.");
    }
    const project = JSON.parse(JSON.stringify(raw));
    project.appVersion = APP_VERSION;
    project.formatVersion = FORMAT_VERSION;
    project.station = project.station || { name: "", date: today(), existing: false, references: [] };
    project.station.references = Array.isArray(project.station.references) ? project.station.references : [];
    project.station.checkReferences = Array.isArray(project.station.checkReferences) ? project.station.checkReferences : null;
    project.station.bankStationId = String(project.station.bankStationId || "");
    project.station.executionSource = String(project.station.executionSource || "manual");
    project.station.preparation = Array.isArray(project.station.preparation) ? project.station.preparation : [];
    project.station.preparationLockedAt = String(project.station.preparationLockedAt || "");

    // v2.1.1: projetos até o formato 3 gravavam a relação conhecida em differenceM.
    // A migração usa versão/estrutura conhecida, nunca a magnitude do número.
    const sourceFormatVersion = Number(raw.formatVersion || 0);
    const sourceUnits = raw.units && typeof raw.units === "object" ? raw.units : {};
    const sourceInputUnit = String((raw.station && raw.station.referenceInputUnit) || sourceUnits.referenceDifferenceInput || "").toLowerCase();
    project.station.references = project.station.references.map((reference) => {
      const item = reference && typeof reference === "object" ? reference : {};
      const hasCm = Object.prototype.hasOwnProperty.call(item, "differenceCm") && hasText(item.differenceCm);
      const legacyMeters = sourceFormatVersion <= 3 || sourceInputUnit === "" || sourceInputUnit === "m";
      if (!hasCm && legacyMeters && hasText(item.differenceM)) {
        item.differenceCm = metersToCentimetersText(item.differenceM, 2) || "";
      } else if (hasCm) {
        const meters = centimetersToMetersText(item.differenceCm);
        if (meters !== null) item.differenceM = meters;
      }
      item.differenceUnit = "cm";
      return item;
    });
    if (Array.isArray(project.station.checkReferences)) {
      project.station.checkReferences = project.station.checkReferences.map((reference) => {
        const item = reference && typeof reference === "object" ? reference : {};
        if (!hasText(item.differenceCm) && hasText(item.differenceM)) item.differenceCm = metersToCentimetersText(item.differenceM, 2) || "";
        else if (hasText(item.differenceCm)) {
          const meters = centimetersToMetersText(item.differenceCm);
          if (meters !== null) item.differenceM = meters;
        }
        item.differenceUnit = "cm";
        return item;
      });
    }
    project.station.referenceInputUnit = "cm";
    project.station.referenceStorageUnit = "m";
    project.units = Object.assign({}, project.units || {}, { referenceDifferenceInput: "cm", referenceDifferenceStorage: "m" });
    project.ida = project.ida || { lances: [] };
    project.volta = project.volta || { lances: [], routeMode: "auto" };
    project.ida.lances = Array.isArray(project.ida.lances) ? project.ida.lances : [];
    project.volta.lances = Array.isArray(project.volta.lances) ? project.volta.lances : [];
    if (project.volta.routeMode !== "auto" && project.volta.routeMode !== "manual") {
      project.volta.routeMode = isReverseSkeleton(project.ida.lances, project.volta.lances) ? "auto" : "manual";
    }
    project.scheme = Object.assign({
      principalPoint: "",
      inputMode: "principalElevation",
      principalElevationM: "",
      stationNrCm: "",
      rulerTopM: "",
      rulerObservation: ""
    }, project.scheme || {});
    if (!hasText(project.scheme.stationNrCm) && hasText(project.scheme.stationNrM)) {
      const oldStationNrM = parseStoredNumber(project.scheme.stationNrM);
      if (oldStationNrM !== null) project.scheme.stationNrCm = storedDecimal(oldStationNrM * 100);
    }
    delete project.scheme.stationNrM;
    project.criteria = normalizeCriteria(project.criteria);
    project.metadata = Object.assign(emptyMetadata(project.station.name), project.metadata || {});
    project.history = Array.isArray(project.history) ? project.history : [];
    project.updatedAt = now();
    return project;
  }

  function touch(project, action) {
    project.updatedAt = now();
    if (!Array.isArray(project.history)) project.history = [];
    if (action) project.history.push({ at: project.updatedAt, action });
    if (project.history.length > 200) project.history = project.history.slice(-200);
    return project;
  }

  const api = {
    APP_VERSION,
    FORMAT_VERSION,
    PROJECT_FORMAT,
    DEFAULT_CRITERIA,
    id,
    today,
    now,
    emptyReading,
    emptyLance,
    emptyMetadata,
    defaultCriteria,
    normalizeCriteria,
    decimalText,
    scaleDecimalText,
    centimetersToMetersText,
    metersToCentimetersText,
    createProject,
    createReference,
    suggestedRuns,
    lanceHasAcquisitionData,
    runHasAcquisitionData,
    acquisitionFingerprint,
    clearLanceAcquisitionData,
    cloneProject,
    reverseRunSkeleton,
    normalizedPoint,
    isTemporarySupportPoint,
    isPermanentReferenceName,
    isReferenceRename,
    structureSignature,
    ptTopologySignature,
    isReverseSkeleton,
    isReversePtTopology,
    permanentReferenceSequence,
    referenceSequencesMatch,
    inferReferenceRenameHints,
    inferPermanentReferenceInsertion,
    applyPermanentReferenceInsertion,
    syncVoltaFromIda,
    migrateProject,
    touch
  };

  root.C32Model = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
