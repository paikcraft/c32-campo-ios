(function (root) {
  "use strict";

  let ocrWorker = null;

  function progress(callback, stage, detail, percent) {
    if (typeof callback === "function") callback({ stage, detail: detail || "", percent: percent == null ? null : percent });
  }

  async function waitForPdf() {
    if (root.pdfjsLib) return root.pdfjsLib;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("Leitor PDF offline não carregou.")), 15000);
      root.addEventListener("c32-pdf-ready", () => {
        clearTimeout(timer);
        resolve(root.pdfjsLib);
      }, { once: true });
    });
  }

  function groupItems(items, pageNumber) {
    const rows = [];
    for (const item of items || []) {
      const text = String(item.str || "").trim();
      if (!text) continue;
      const x = Number(item.transform && item.transform[4]) || 0;
      const y = Number(item.transform && item.transform[5]) || 0;
      const width = Math.abs(Number(item.width) || 0);
      const height = Math.abs(Number(item.height) || Number(item.transform && item.transform[3]) || 0);
      let row = rows.find((candidate) => Math.abs(candidate.y - y) <= Math.max(2.2, height * 0.25));
      if (!row) {
        row = { page: pageNumber, y, parts: [] };
        rows.push(row);
      }
      row.parts.push({ x, y, width, height, text });
    }
    return rows.sort((a, b) => b.y - a.y).map((row) => {
      const parts = row.parts.sort((a, b) => a.x - b.x);
      const x = Math.min(...parts.map((part) => part.x));
      const right = Math.max(...parts.map((part) => part.x + part.width));
      const height = Math.max(0, ...parts.map((part) => part.height));
      return {
        page: row.page,
        y: row.y,
        x,
        width: Math.max(0, right - x),
        height,
        mode: "layout",
        parts,
        text: parts.map((part) => part.text).join(" ").replace(/\s+/g, " ").trim()
      };
    });
  }

  function logicalItems(items, pageNumber) {
    const lines = [];
    let parts = [];
    let first = null;
    const flush = () => {
      const text = parts.join(" ").replace(/\s+/g, " ").trim();
      if (text) lines.push({ page: pageNumber, y: first ? first.y : lines.length, x: first ? first.x : 0, width: 0, height: 0, mode: "logical", text });
      parts = [];
      first = null;
    };
    for (const item of items || []) {
      const text = String(item.str || "").trim();
      if (text) {
        if (!first) first = { x: Number(item.transform && item.transform[4]) || 0, y: Number(item.transform && item.transform[5]) || 0 };
        parts.push(text);
      }
      if (item.hasEOL) flush();
    }
    flush();
    return lines;
  }

  async function createOcrWorker(callback) {
    if (ocrWorker) return ocrWorker;
    if (!root.Tesseract || typeof root.Tesseract.createWorker !== "function") throw new Error("Módulo OCR offline indisponível.");
    progress(callback, "Lendo PDF…", "Inicializando OCR local", 0);
    const asset = (path) => new URL(path, root.location.href).href;
    ocrWorker = await root.Tesseract.createWorker("por+eng", 1, {
      workerPath: asset("js/vendor/tesseract/worker.min.js"),
      corePath: asset("js/vendor/tesseract-core/tesseract-core-lstm.wasm.js"),
      langPath: asset("tessdata"),
      gzip: false,
      workerBlobURL: true,
      logger: (message) => {
        if (!message || typeof callback !== "function") return;
        const percent = Number.isFinite(message.progress) ? Math.round(message.progress * 100) : null;
        callback({ stage: "Interpretando campos…", detail: message.status || "OCR local", percent });
      }
    });
    await ocrWorker.setParameters({ preserve_interword_spaces: "1", user_defined_dpi: "220" });
    return ocrWorker;
  }

  async function ocrPage(page, pageNumber, callback) {
    const baseViewport = page.getViewport({ scale: 1 });
    const scale = Math.min(2.6, Math.max(1.7, 2200 / Math.max(baseViewport.width, 1)));
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement("canvas");
    canvas.width = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    const context = canvas.getContext("2d", { alpha: false, willReadFrequently: true });
    context.fillStyle = "#fff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: context, viewport }).promise;
    const worker = await createOcrWorker(callback);
    const result = await worker.recognize(canvas, {}, { text: true, blocks: true });
    const data = result.data || {};
    const spatial = [];
    for (const block of data.blocks || []) {
      for (const paragraph of block.paragraphs || []) {
        for (const line of paragraph.lines || []) {
          const bbox = line.bbox || {};
          const parts = (line.words || []).map((word) => {
            const box = word.bbox || {};
            return {
              x: Number(box.x0) || 0,
              y: canvas.height - (Number(box.y0) || 0),
              width: Math.max(0, (Number(box.x1) || 0) - (Number(box.x0) || 0)),
              height: Math.max(0, (Number(box.y1) || 0) - (Number(box.y0) || 0)),
              text: String(word.text || "").trim()
            };
          }).filter((part) => part.text);
          const text = String(line.text || parts.map((part) => part.text).join(" ")).replace(/\s+/g, " ").trim();
          if (!text) continue;
          spatial.push({
            page: pageNumber,
            y: canvas.height - (Number(bbox.y0) || 0),
            x: Number(bbox.x0) || 0,
            width: Math.max(0, (Number(bbox.x1) || 0) - (Number(bbox.x0) || 0)),
            height: Math.max(0, (Number(bbox.y1) || 0) - (Number(bbox.y0) || 0)),
            mode: "ocr-layout",
            parts,
            text
          });
        }
      }
    }
    const text = String(data.text || "");
    const lines = spatial.length ? spatial : text.split(/\r?\n/).map((value) => value.trim()).filter(Boolean).map((value, index, all) => ({
      page: pageNumber,
      y: all.length - index,
      x: 0,
      width: 0,
      height: 0,
      mode: "ocr-text",
      text: value
    }));
    return { lines, confidence: Number(data.confidence) || 0 };
  }

  function needsOcr(lines) {
    const text = lines.map((line) => line.text).join(" ");
    return text.length < 100;
  }

  async function shouldOcrPage(page, lines, pdfjs) {
    if (!needsOcr(lines)) return false;
    const text = lines.map((line) => line.text).join(" ").trim();
    if (text) return true;
    const operators = await page.getOperatorList();
    const imageOperations = new Set([
      pdfjs.OPS && pdfjs.OPS.paintImageXObject,
      pdfjs.OPS && pdfjs.OPS.paintInlineImageXObject,
      pdfjs.OPS && pdfjs.OPS.paintImageMaskXObject,
      pdfjs.OPS && pdfjs.OPS.paintSolidColorImageMask
    ].filter(Number.isFinite));
    if (operators.fnArray.some((operation) => imageOperations.has(operation))) return true;
    const drawingOperations = new Set([
      pdfjs.OPS && pdfjs.OPS.constructPath,
      pdfjs.OPS && pdfjs.OPS.fill,
      pdfjs.OPS && pdfjs.OPS.eoFill,
      pdfjs.OPS && pdfjs.OPS.stroke,
      pdfjs.OPS && pdfjs.OPS.fillStroke,
      pdfjs.OPS && pdfjs.OPS.eoFillStroke
    ].filter(Number.isFinite));
    return operators.fnArray.filter((operation) => drawingOperations.has(operation)).length > 20;
  }

  async function interpret(bytes, sourceFileName, callback) {
    const data = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
    if (data.length < 20 || String.fromCharCode(...data.slice(0, 5)) !== "%PDF-") throw new Error("Selecione um PDF válido de F-43.");
    progress(callback, "Lendo PDF…", sourceFileName, 2);
    const pdfjs = await waitForPdf();
    const loading = pdfjs.getDocument({
      data,
      isEvalSupported: false,
      useSystemFonts: true,
      standardFontDataUrl: new URL("standard_fonts/", root.location.href).href
    });
    const pdf = await loading.promise;
    try {
      const pages = [];
      const confidence = [];
      let usedOcr = false;
      for (let index = 1; index <= pdf.numPages; index += 1) {
        progress(callback, "Lendo PDF…", `Página ${index} de ${pdf.numPages}`, Math.round((index - 1) / pdf.numPages * 35));
        const page = await pdf.getPage(index);
        try {
          const content = await page.getTextContent({ includeMarkedContent: false, disableNormalization: false });
          const layoutLines = groupItems(content.items, index);
          const logicalLines = logicalItems(content.items, index);
          let lines = logicalLines.concat(layoutLines);
          if (await shouldOcrPage(page, lines, pdfjs)) {
            usedOcr = true;
            const recognized = await ocrPage(page, index, callback);
            lines = recognized.lines;
            confidence.push(recognized.confidence);
          }
          pages.push({ page: index, lines });
        } finally {
          page.cleanup();
        }
      }
      progress(callback, "Interpretando campos…", "Reconstruindo identificação, RN e cotas", 78);
      const interpretation = root.C32F43Parser.parse({
        pages,
        sourceFileName,
        extractionMode: usedOcr ? "ocr-offline" : "pdf-text",
        averageConfidence: confidence.length ? confidence.reduce((sum, value) => sum + value, 0) / confidence.length : null
      });
      progress(callback, "Validando cotas…", "Conferindo relações matemáticas", 90);
      root.C32F43Parser.validate(interpretation);
      progress(callback, "Preparando conferência…", "Pronto para revisão técnica", 100);
      return interpretation;
    } finally {
      await pdf.destroy();
    }
  }

  async function terminateOcr() {
    if (ocrWorker) await ocrWorker.terminate();
    ocrWorker = null;
  }

  const api = { interpret, groupItems, logicalItems, needsOcr, shouldOcrPage, terminateOcr };
  root.C32F43Pdf = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
