(function (root) {
  "use strict";

  const FORMAT = "c32base";
  const SCHEMA_VERSION = "1.0";
  const GENERATOR = "C32 - Campo 2.1";
  const volatileKeys = new Set(["id", "createdAt", "updatedAt", "fingerprint", "displaySuffix", "importedAt"]);

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function canonicalize(value) {
    if (Array.isArray(value)) return value.map(canonicalize);
    if (value && typeof value === "object") {
      const output = {};
      Object.keys(value).sort().forEach((key) => {
        if (value[key] !== undefined) output[key] = canonicalize(value[key]);
      });
      return output;
    }
    return value;
  }

  function stableStringify(value) {
    return JSON.stringify(canonicalize(value));
  }

  function rightRotate(value, amount) {
    return (value >>> amount) | (value << (32 - amount));
  }

  function sha256Ascii(ascii) {
    const maxWord = 2 ** 32;
    const words = [];
    const hash = [];
    const constants = [];
    let primeCounter = 0;
    const isComposite = {};
    for (let candidate = 2; primeCounter < 64; candidate += 1) {
      if (!isComposite[candidate]) {
        for (let multiple = 0; multiple < 313; multiple += candidate) isComposite[multiple] = candidate;
        if (primeCounter < 8) hash[primeCounter] = (candidate ** 0.5 * maxWord) | 0;
        constants[primeCounter] = (candidate ** (1 / 3) * maxWord) | 0;
        primeCounter += 1;
      }
    }
    const bytes = unescape(encodeURIComponent(ascii));
    const bitLength = bytes.length * 8;
    let message = bytes + "\x80";
    while ((message.length % 64) !== 56) message += "\x00";
    for (let i = 0; i < message.length; i += 1) words[i >> 2] |= message.charCodeAt(i) << ((3 - i) % 4) * 8;
    words.push((bitLength / maxWord) | 0);
    words.push(bitLength | 0);
    for (let offset = 0; offset < words.length; offset += 16) {
      const oldHash = hash.slice(0);
      const schedule = words.slice(offset, offset + 16);
      for (let i = 0; i < 64; i += 1) {
        const w15 = schedule[i - 15];
        const w2 = schedule[i - 2];
        const a = hash[0];
        const e = hash[4];
        const word = i < 16 ? schedule[i] : (
          schedule[i - 16]
          + (rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3))
          + schedule[i - 7]
          + (rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10))
        ) | 0;
        schedule[i] = word;
        const temp1 = (hash[7]
          + (rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25))
          + ((e & hash[5]) ^ ((~e) & hash[6]))
          + constants[i]
          + word) | 0;
        const temp2 = ((rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22))
          + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]))) | 0;
        hash.pop();
        hash.unshift((temp1 + temp2) | 0);
        hash[4] = (hash[4] + temp1) | 0;
      }
      for (let i = 0; i < 8; i += 1) hash[i] = (hash[i] + oldHash[i]) | 0;
    }
    return hash.map((value) => (value >>> 0).toString(16).padStart(8, "0")).join("");
  }

  function contentForFingerprint(value) {
    if (Array.isArray(value)) return value.map(contentForFingerprint);
    if (value && typeof value === "object") {
      const output = {};
      Object.keys(value).sort().forEach((key) => {
        if (!volatileKeys.has(key) && value[key] !== undefined) output[key] = contentForFingerprint(value[key]);
      });
      return output;
    }
    return value;
  }

  function fingerprint(kind, value) {
    return sha256Ascii(`${kind}\n${stableStringify(contentForFingerprint(value))}`);
  }

  function dateRank(value) {
    const text = String(value == null ? "" : value).trim();
    let match = text.match(/^(\d{4})[-/]?(\d{2})?[-/]?(\d{2})?/);
    if (match) return Number(`${match[1]}${match[2] || "00"}${match[3] || "00"}`);
    match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (match) return Number(`${match[3]}${match[2].padStart(2, "0")}${match[1].padStart(2, "0")}`);
    const year = text.match(/(?:19|20)\d{2}/);
    return year ? Number(`${year[0]}0000`) : 0;
  }

  function preparePayload(snapshot) {
    const source = snapshot || {};
    const stations = (source.stations || []).map((item) => clone(item));
    const f43 = (source.f43 || []).map((item) => {
      const record = clone(item);
      record.fingerprint = fingerprint("f43", record);
      return record;
    });
    const levelings = (source.levelings || []).map((item) => {
      const record = clone(item);
      record.fingerprint = fingerprint("leveling", record);
      return record;
    });
    return { stations, f43, levelings };
  }

  function create(snapshot, metadata) {
    const payload = preparePayload(snapshot);
    const document = {
      format: FORMAT,
      schemaVersion: SCHEMA_VERSION,
      createdAt: new Date().toISOString(),
      generator: GENERATOR,
      metadata: Object.assign({ description: "Banco estruturado de estações C32; não contém PDFs, imagens ou projetos completos." }, clone(metadata || {})),
      payload
    };
    document.integrity = {
      algorithm: "SHA-256",
      scope: "canonical-payload",
      digest: sha256Ascii(stableStringify(payload))
    };
    return document;
  }

  function serialize(snapshot, metadata) {
    return JSON.stringify(create(snapshot, metadata), null, 2) + "\n";
  }

  function decode(input) {
    if (typeof input === "string") return input;
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input || []);
    return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  }

  function summary(payload) {
    const f43 = payload.f43 || [];
    const levelings = payload.levelings || [];
    return {
      stations: (payload.stations || []).length,
      currentStandards: f43.filter((item) => item.kind === "standard" && item.current === true).length,
      historicalStandards: f43.filter((item) => item.kind === "standard" && item.current !== true).length,
      levelings: levelings.filter((item) => item.kind !== "proposal").length,
      proposals: levelings.filter((item) => item.kind === "proposal").length
    };
  }

  function parse(input) {
    let document;
    try {
      document = JSON.parse(decode(input));
    } catch (error) {
      throw new Error("Arquivo danificado/inválido: conteúdo JSON ilegível.");
    }
    if (!document || document.format !== FORMAT || !document.payload || !document.integrity) {
      throw new Error("Arquivo danificado/inválido: não é uma base C32.");
    }
    const major = String(document.schemaVersion || "0").split(".")[0];
    if (Number(major) > Number(SCHEMA_VERSION.split(".")[0])) {
      throw new Error("Esta base foi criada por uma versão incompatível mais nova.");
    }
    const payload = {
      stations: Array.isArray(document.payload.stations) ? document.payload.stations : [],
      f43: Array.isArray(document.payload.f43) ? document.payload.f43 : [],
      levelings: Array.isArray(document.payload.levelings) ? document.payload.levelings : []
    };
    const expected = String(document.integrity.digest || "").toLowerCase();
    const actual = sha256Ascii(stableStringify(payload));
    if (!expected || expected !== actual) throw new Error("Arquivo danificado/inválido: SHA-256 não confere.");
    return { document, payload, summary: summary(payload), integrity: "OK" };
  }

  function diffValues(left, right, prefix, output) {
    const path = prefix || "";
    const differences = output || [];
    const a = left && typeof left === "object" ? left : {};
    const b = right && typeof right === "object" ? right : {};
    const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
    [...keys].sort().forEach((key) => {
      if (volatileKeys.has(key)) return;
      const next = path ? `${path}.${key}` : key;
      const av = a[key]; const bv = b[key];
      if (av && bv && typeof av === "object" && typeof bv === "object" && !Array.isArray(av) && !Array.isArray(bv)) {
        diffValues(av, bv, next, differences);
      } else if (stableStringify(av) !== stableStringify(bv)) {
        differences.push({ path: next, current: clone(av), incoming: clone(bv) });
      }
    });
    return differences;
  }

  async function planImport(parsed) {
    const db = root.C32StationDb;
    if (!db) throw new Error("Banco de Estações indisponível.");
    const payload = parsed.payload || parsed;
    const stationPlans = [];
    const stationTargets = new Map();
    for (const station of payload.stations || []) {
      const match = await db.identifyStation(station);
      const plan = { source: clone(station), sourceId: station.id, status: match.status, candidates: match.candidates || [] };
      if (match.status === "exact") {
        plan.targetId = match.candidates[0].id;
        stationTargets.set(station.id, plan.targetId);
      }
      stationPlans.push(plan);
    }

    const f43Plans = [];
    for (const incoming of payload.f43 || []) {
      const record = clone(incoming);
      const sourceStationId = record.stationId;
      const targetId = stationTargets.get(sourceStationId);
      if (targetId) record.stationId = targetId;
      record.fingerprint = fingerprint("f43", record);
      const duplicate = (await db.findF43ByFingerprint(record.fingerprint))[0];
      if (duplicate) {
        f43Plans.push({ source: record, status: "duplicate", existing: duplicate });
        continue;
      }
      const existing = targetId ? await db.listF43(targetId) : [];
      record.stationId = sourceStationId;
      const current = existing.find((item) => item.kind === "standard" && item.current === true) || null;
      const incomingDate = dateRank(record.updateDate || record.date || record.year || "");
      const currentDate = current ? dateRank(current.updateDate || current.date || current.year || "") : 0;
      let status = "new";
      if (record.kind === "standard" && current) status = incomingDate > currentDate ? "newer-standard" : "historical-standard";
      f43Plans.push({ source: record, status, current, differences: current ? diffValues(current, record) : [] });
    }

    const levelingPlans = [];
    for (const incoming of payload.levelings || []) {
      const record = clone(incoming);
      const sourceStationId = record.stationId;
      const targetId = stationTargets.get(sourceStationId);
      if (targetId) record.stationId = targetId;
      record.fingerprint = fingerprint("leveling", record);
      const duplicate = (await db.findLevelingByFingerprint(record.fingerprint))[0];
      if (duplicate) {
        levelingPlans.push({ source: record, status: "duplicate", existing: duplicate });
        continue;
      }
      const existing = targetId ? await db.listLevelings(targetId) : [];
      record.stationId = sourceStationId;
      const sameDate = existing.filter((item) => String(item.dateKey || item.date || "") === String(record.dateKey || record.date || ""));
      levelingPlans.push({ source: record, status: sameDate.length ? "conflict" : "new", existing: sameDate, differences: sameDate[0] ? diffValues(sameDate[0], record) : [] });
    }
    return { parsed, stationPlans, f43Plans, levelingPlans, stationTargets };
  }

  function nextSuffix(records, dateKey) {
    const used = new Set(records.filter((item) => String(item.dateKey || item.date || "") === String(dateKey || ""))
      .map((item) => String(item.displaySuffix || "").toUpperCase()).filter(Boolean));
    for (let code = 65; code <= 90; code += 1) if (!used.has(String.fromCharCode(code))) return String.fromCharCode(code);
    return `X${used.size + 1}`;
  }

  async function applyPlan(plan, resolutions) {
    const db = root.C32StationDb;
    const choices = resolutions || {};
    const stationMap = new Map();
    const batch = { stations: [], f43: [], levelings: [] };
    const notices = [];

    for (const item of plan.stationPlans) {
      if (item.status === "exact") {
        stationMap.set(item.sourceId, item.targetId);
      } else if (item.status === "ambiguous") {
        const targetId = choices.stations && choices.stations[item.sourceId];
        if (!targetId) throw new Error(`Confirme a identidade da estação ${item.source.name || item.sourceId}.`);
        stationMap.set(item.sourceId, targetId);
      } else {
        const station = clone(item.source);
        if (!station.id) station.id = root.C32Model.id("station");
        batch.stations.push(station);
        stationMap.set(item.sourceId, station.id);
      }
    }

    for (const item of plan.f43Plans) {
      if (item.status === "duplicate") {
        notices.push(`F-43 ${item.source.sourceFileName || item.source.id}: já existe.`);
        continue;
      }
      const record = clone(item.source);
      record.stationId = stationMap.get(record.stationId) || record.stationId;
      if (item.status === "newer-standard") {
        const makeCurrent = Boolean(choices.f43 && choices.f43[record.id] && choices.f43[record.id].makeCurrent);
        record.current = makeCurrent;
        if (makeCurrent && item.current) {
          const previous = clone(item.current);
          previous.current = false;
          previous.fingerprint = fingerprint("f43", previous);
          batch.f43.push(previous);
        }
      } else if (item.status === "historical-standard") record.current = false;
      record.fingerprint = fingerprint("f43", record);
      batch.f43.push(record);
    }

    for (const item of plan.levelingPlans) {
      if (item.status === "duplicate") {
        notices.push("Este nivelamento já existe no Banco de Estações.");
        continue;
      }
      let record = clone(item.source);
      record.stationId = stationMap.get(record.stationId) || record.stationId;
      if (item.status === "conflict") {
        const choice = choices.levelings && choices.levelings[record.id];
        if (!choice || !choice.action) throw new Error(`Resolva o conflito do nivelamento de ${record.dateKey || record.date || "data não informada"}.`);
        if (choice.action === "replace") record.id = item.existing[0].id;
        else if (choice.action === "correct") record = Object.assign(record, clone(choice.corrected || {}), { id: item.existing[0].id });
        else if (choice.action === "keep-both") {
          const all = await db.listLevelings(record.stationId);
          const existingSuffix = item.existing[0].displaySuffix;
          if (!existingSuffix) {
            const previous = clone(item.existing[0]);
            previous.displaySuffix = "A";
            batch.levelings.push(previous);
          }
          record.displaySuffix = nextSuffix(all.concat(batch.levelings), record.dateKey || record.date);
        } else throw new Error("Ação de conflito inválida.");
      }
      record.fingerprint = fingerprint("leveling", record);
      batch.levelings.push(record);
    }
    const applied = await db.applyBatch(batch);
    return { applied, notices };
  }

  const api = {
    FORMAT,
    SCHEMA_VERSION,
    GENERATOR,
    canonicalize,
    stableStringify,
    sha256: sha256Ascii,
    fingerprint,
    dateRank,
    create,
    serialize,
    parse,
    summary,
    diffValues,
    planImport,
    applyPlan,
    nextSuffix
  };

  root.C32Base = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
